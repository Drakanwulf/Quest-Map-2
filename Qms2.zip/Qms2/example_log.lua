QM_Scout =
{
    ["startTime"] = 1450735124,		-- Timestamp (unix time) when the add-on was installed (may be used in the future to display a message for reminding about uploading the data)
    ["quests"] =  					-- A list of quests and their data organized by zone/subzone
    {
        ["stormhaven/stormhaven_base"] = 		--Zone Quests
        {
            [1] = 								--Entry number (index)
            {
                ["name"] = "False Knights",  	-- Quest title
                ["giver"] = "Sir Graham",  		-- Quest giver (e.g. NPC name or name of the object that started the quest like books etc.)
                ["y"] = 0.3275171518,  			-- x coordinate where the quest was accepted
                ["x"] = 0.2861485779,  			-- y coordinate where the quest was accepted
                ["preQuest"] = 2569,  			-- Prerequisite quest, if available.  (A unique, ESO-generated, quest ID) of the 
                ["otherInfo"] = 
                {
                    ["lang"] = "en",  			-- Client language (used to find which language the name of the quest and quest giver is)
                    ["time"] = 1450736079,  	-- Timestamp (unix time) when the quest was accepted (used to find out how old and maybe outdated the data is)
                    ["api"] = 100013,  			-- ESO API version in use at the time when the quest was accepted (used to find out how old and maybe outdated the data is)
                },
            },
        },
    },
    ["subZones"] =  							-- Subzone quests
    {
        ["stormhaven/stormhaven_base"] = 		-- Zone entrance name
        {
            ["stormhaven/portdunwatch_base"] =		-- Subzone entrances list like dungeons, caves, etc.
            {
                ["x"] = 0.3236285746,				-- x coordinate of the entrance
                ["y"] = 0.3078914285,				-- y coordinate of the entrance
            },
        },
    },
    ["questsDone"] =				-- A list of completed quests organized by their (questIDs) with info about them
    {
        [1687] = 
        {
            ["repeatType"] = 0,  -- Repeat type (http://wiki.esoui.com/Globals#QuestRepeatableType)
            ["rewardTypes"] =  -- List of reward types (http://wiki.esoui.com/Globals#RewardType)
            {
                [1] = 1,
            },
        },
    },
}
