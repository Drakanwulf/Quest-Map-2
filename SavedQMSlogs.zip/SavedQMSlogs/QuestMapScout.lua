QM_Scout =
{
    ["startTime"] = 1534373026,
    ["questInfo"] = 
    {
        [6116] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 1,
            },
            ["repeatType"] = 0,
        },
    },
    ["quests"] = 
    {
        ["summerset/shimmerene_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Lanarie",
                ["y"] = 0.6190934777,
                ["otherInfo"] = 
                {
                    ["time"] = 1534447021,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["x"] = 0.6713526845,
                ["name"] = "A Tale of Two Mothers",
            },
            [1] = 
            {
                ["giver"] = "Calibar",
                ["y"] = 0.6641752124,
                ["otherInfo"] = 
                {
                    ["time"] = 1534440810,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["x"] = 0.2311630398,
                ["name"] = "The Queen's Decree",
            },
        },
    },
}
