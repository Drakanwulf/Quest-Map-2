QM_Scout =
{
    ["quests"] = 
    {
        ["glenumbra/ilessantower_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7700323462,
                ["giver"] = "Red Rook Note",
                ["x"] = 0.5450952053,
                ["name"] = "Red Rook Resources",
                ["otherInfo"] = 
                {
                    ["time"] = 1533684860,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7394628525,
                ["giver"] = "Darien Gautier",
                ["preQuest"] = 4901,
                ["x"] = 0.4597792029,
                ["name"] = "Shornhelm Divided",
                ["otherInfo"] = 
                {
                    ["time"] = 1534398094,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6906269193,
                ["giver"] = "Daribert Hurier",
                ["x"] = 0.4797356725,
                ["name"] = "Under Siege",
                ["otherInfo"] = 
                {
                    ["time"] = 1534398418,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5729492903,
                ["giver"] = "Scholar Cantier",
                ["x"] = 0.5490812063,
                ["name"] = "A Traitor's Tale",
                ["otherInfo"] = 
                {
                    ["time"] = 1534458595,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.6188712120,
                ["giver"] = "Jowan Hinault",
                ["preQuest"] = 3286,
                ["x"] = 0.4653404057,
                ["name"] = "Dearly Departed",
                ["otherInfo"] = 
                {
                    ["time"] = 1534458893,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6888028383,
                ["giver"] = "Bumnog",
                ["x"] = 0.3692457676,
                ["name"] = "Rusty Daggers",
                ["otherInfo"] = 
                {
                    ["time"] = 1534547666,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.6280971169,
                ["giver"] = "Nathalye Ervine",
                ["preQuest"] = 5012,
                ["x"] = 0.2783106267,
                ["name"] = "In the Doghouse",
                ["otherInfo"] = 
                {
                    ["time"] = 1534553708,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.6459167004,
                ["giver"] = "Michel Gette",
                ["x"] = 0.2556575239,
                ["name"] = "The Blood-Cursed Town",
                ["otherInfo"] = 
                {
                    ["time"] = 1534553764,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.4514686763,
                ["giver"] = "Count Verandis Ravenwatch",
                ["preQuest"] = 4903,
                ["x"] = 0.2930417359,
                ["name"] = "The Blood-Splattered Shield",
                ["otherInfo"] = 
                {
                    ["time"] = 1534567301,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.6468122602,
                ["giver"] = "Gwendis",
                ["preQuest"] = 465,
                ["x"] = 0.2146217972,
                ["name"] = "The Concealing Veil",
                ["otherInfo"] = 
                {
                    ["time"] = 1534627281,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.4664203823,
                ["giver"] = "Federic Seychelle",
                ["x"] = 0.6914007068,
                ["name"] = "A Change of Heart",
                ["otherInfo"] = 
                {
                    ["time"] = 1534627498,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.4809440672,
                ["giver"] = "Count Verandis Ravenwatch",
                ["preQuest"] = 4857,
                ["x"] = 0.5995568037,
                ["name"] = "Northpoint in Peril",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631512,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5149237514,
                ["giver"] = "Alvaren Garoutte",
                ["x"] = 0.5871042013,
                ["name"] = "Archaic Relics",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631587,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.6254729033,
                ["giver"] = "Marisette",
                ["x"] = 0.6284329295,
                ["name"] = "Crimes of the Past",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.6622117758,
                ["giver"] = "Adusa-daro",
                ["x"] = 0.6064910293,
                ["name"] = "Hope Lost",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634772,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.5597689748,
                ["giver"] = "Strange Sapling",
                ["x"] = 0.6333553791,
                ["name"] = "The Price of Longevity",
                ["otherInfo"] = 
                {
                    ["time"] = 1534651278,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.4603060186,
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4926,
                ["x"] = 0.2959030271,
                ["name"] = "The Assassin's List",
                ["otherInfo"] = 
                {
                    ["time"] = 1534736590,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.6350313425,
                ["giver"] = "Lieutenant Sgugh",
                ["x"] = 0.2673034668,
                ["name"] = "The Sanctifying Flames",
                ["otherInfo"] = 
                {
                    ["time"] = 1534737005,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.4686428905,
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4927,
                ["x"] = 0.2859297097,
                ["name"] = "Threat of Death",
                ["otherInfo"] = 
                {
                    ["time"] = 1534737994,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.4693705440,
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4928,
                ["x"] = 0.2863873839,
                ["name"] = "A Dagger to the Heart",
                ["otherInfo"] = 
                {
                    ["time"] = 1534738422,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.4420057237,
                ["giver"] = "Constable Agazu",
                ["preQuest"] = 4965,
                ["x"] = 0.6877788305,
                ["name"] = "Frightened Folk",
                ["otherInfo"] = 
                {
                    ["time"] = 1534742538,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.4126192331,
                ["giver"] = "Constable Agazu",
                ["preQuest"] = 4931,
                ["x"] = 0.7006397247,
                ["name"] = "Fell's Justice",
                ["otherInfo"] = 
                {
                    ["time"] = 1534810643,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["y"] = 0.6250448823,
                ["giver"] = "Beryn",
                ["preQuest"] = 5312,
                ["x"] = 0.1827658564,
                ["name"] = "The Spider's Cocoon",
                ["otherInfo"] = 
                {
                    ["time"] = 1534831726,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["y"] = 0.2306008041,
                ["giver"] = "Lothson Cold-Eye",
                ["x"] = 0.7315177917,
                ["name"] = "The Lady's Keepsake",
                ["otherInfo"] = 
                {
                    ["time"] = 1534913311,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [24] = 
            {
                ["y"] = 0.2659831345,
                ["giver"] = "Lady Clarisse Laurent",
                ["x"] = 0.6774894595,
                ["name"] = "The Emerald Chalice",
                ["otherInfo"] = 
                {
                    ["time"] = 1534983366,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [25] = 
            {
                ["y"] = 0.3771019280,
                ["giver"] = "Gwendis",
                ["preQuest"] = 4884,
                ["x"] = 0.3189841807,
                ["name"] = "The Crown of Shornhelm",
                ["otherInfo"] = 
                {
                    ["time"] = 1534999198,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/santaki_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4405688643,
                ["giver"] = "Tharayya Journal Entry: 2",
                ["preQuest"] = 4659,
                ["x"] = 0.5429641008,
                ["name"] = "Tharayya's Trail",
                ["otherInfo"] = 
                {
                    ["time"] = 1536024066,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/dreamingcave01_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5473768711,
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6109,
                ["x"] = 0.5636072755,
                ["name"] = "Lost in Translation",
                ["otherInfo"] = 
                {
                    ["time"] = 1535752808,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.3588981628,
                ["giver"] = "Oriandra",
                ["preQuest"] = 6113,
                ["x"] = 0.3942164779,
                ["name"] = "A Necessary Alliance",
                ["otherInfo"] = 
                {
                    ["time"] = 1535755815,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5018859506,
                ["giver"] = "Valsirenn",
                ["preQuest"] = 6126,
                ["x"] = 0.7556292415,
                ["name"] = "A New Alliance",
                ["otherInfo"] = 
                {
                    ["time"] = 1535778626,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/alinor_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6473568082,
                ["giver"] = "Vandoril",
                ["preQuest"] = 6097,
                ["x"] = 0.2997643054,
                ["name"] = "Checking on Cloudrest",
                ["otherInfo"] = 
                {
                    ["time"] = 1535250228,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.4404526651,
                ["giver"] = "Roguzog",
                ["x"] = 0.2337974161,
                ["name"] = "A Duelist's Dilemma",
                ["otherInfo"] = 
                {
                    ["time"] = 1535250333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5066245198,
                ["giver"] = "Battlereeve Tanerline",
                ["x"] = 0.6147393584,
                ["name"] = "The Abyssal Cabal",
                ["otherInfo"] = 
                {
                    ["time"] = 1535602223,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5052776337,
                ["giver"] = "Rigurt the Brash",
                ["x"] = 0.6475471258,
                ["name"] = "Culture Clash",
                ["otherInfo"] = 
                {
                    ["time"] = 1535602261,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.7019631863,
                ["giver"] = "Battlereeve Tanerline",
                ["preQuest"] = 6165,
                ["x"] = 0.4284041226,
                ["name"] = "Sinking Summerset",
                ["otherInfo"] = 
                {
                    ["time"] = 1535676619,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.6079903841,
                ["giver"] = "Millenith",
                ["preQuest"] = 4961,
                ["x"] = 0.5599572659,
                ["name"] = "Crafting Certification",
                ["otherInfo"] = 
                {
                    ["time"] = 1536297803,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.6079903841,
                ["giver"] = "Millenith",
                ["preQuest"] = 5259,
                ["x"] = 0.5599572659,
                ["name"] = "Blacksmith Certification",
                ["otherInfo"] = 
                {
                    ["time"] = 1536297818,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.6068924069,
                ["giver"] = "Millenith",
                ["preQuest"] = 5249,
                ["x"] = 0.5654178858,
                ["name"] = "Woodworker Certification",
                ["otherInfo"] = 
                {
                    ["time"] = 1536369985,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.5967177749,
                ["giver"] = "Justiciar Farowel",
                ["preQuest"] = 6084,
                ["x"] = 0.4304976165,
                ["name"] = "Run Aground",
                ["otherInfo"] = 
                {
                    ["time"] = 1537826615,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.5856354237,
                ["giver"] = "Justiciar Tanorian",
                ["preQuest"] = 6159,
                ["x"] = 0.4253297746,
                ["name"] = "Struck from Memory",
                ["otherInfo"] = 
                {
                    ["time"] = 1537829054,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/koeglinvillage_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3335759938,
                ["giver"] = "Dame Dabienne",
                ["preQuest"] = 3412,
                ["x"] = 0.3885127902,
                ["name"] = "False Accusations",
                ["otherInfo"] = 
                {
                    ["time"] = 1533765631,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5187935233,
                ["giver"] = "Margot Oscent",
                ["preQuest"] = 2494,
                ["x"] = 0.6060275435,
                ["name"] = "The Slavers",
                ["otherInfo"] = 
                {
                    ["time"] = 1533769172,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.3445196748,
                ["giver"] = "Dame Dabienne",
                ["preQuest"] = 2556,
                ["x"] = 0.3553662896,
                ["name"] = "To Alcaire Castle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533775980,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/aldcroft_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3413914144,
                ["giver"] = "Captain Vistra",
                ["preQuest"] = 3004,
                ["x"] = 0.5562694669,
                ["name"] = "Pride of the Lion Guard",
                ["otherInfo"] = 
                {
                    ["time"] = 1533669833,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/shimmerene_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6924549937,
                ["giver"] = "Calibar",
                ["x"] = 0.2751390040,
                ["name"] = "The Queen's Decree",
                ["otherInfo"] = 
                {
                    ["time"] = 1534970964,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6622093320,
                ["giver"] = "Calibar",
                ["preQuest"] = 5283,
                ["x"] = 0.2323507369,
                ["name"] = "The Queen's Decree",
                ["otherInfo"] = 
                {
                    ["time"] = 1535086542,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6188374758,
                ["giver"] = "Lanarie",
                ["x"] = 0.6734209061,
                ["name"] = "A Tale of Two Mothers",
                ["otherInfo"] = 
                {
                    ["time"] = 1535148723,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/kingshavenext_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4646966457,
                ["giver"] = "Mehdze",
                ["preQuest"] = 6137,
                ["x"] = 0.8305439353,
                ["name"] = "Savage Truths",
                ["otherInfo"] = 
                {
                    ["time"] = 1535322698,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/erokii_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3673306704,
                ["giver"] = "Anenya",
                ["x"] = 0.7498008013,
                ["name"] = "Ancient Power",
                ["otherInfo"] = 
                {
                    ["time"] = 1535001830,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["coldharbor/vaultsofmadness1_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.8147234321,
                ["giver"] = "Gasteau Chamrond",
                ["x"] = 0.1713191420,
                ["name"] = "Mind of Madness",
                ["otherInfo"] = 
                {
                    ["time"] = 1535399791,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/crosswych_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6053073406,
                ["giver"] = "Tamien Sellan",
                ["preQuest"] = 3337,
                ["x"] = 0.6166941524,
                ["name"] = "The Miners' Lament",
                ["otherInfo"] = 
                {
                    ["time"] = 1533595782,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6034337878,
                ["giver"] = "Tamien Sellan",
                ["preQuest"] = 3302,
                ["x"] = 0.6395968795,
                ["name"] = "Crosswych Reclaimed",
                ["otherInfo"] = 
                {
                    ["time"] = 1533596819,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5922731757,
                ["giver"] = "Alessio Guillon",
                ["x"] = 0.6025131345,
                ["name"] = "The Missing Prophecy",
                ["otherInfo"] = 
                {
                    ["time"] = 1533608597,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5522983670,
                ["giver"] = "Bera Moorsmith",
                ["x"] = 0.5974093080,
                ["name"] = "Anchors from the Harbour",
                ["otherInfo"] = 
                {
                    ["time"] = 1533608894,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6174532175,
                ["giver"] = "Adelle Montagne",
                ["x"] = 0.4721064568,
                ["name"] = "Long Lost Lore",
                ["otherInfo"] = 
                {
                    ["time"] = 1533609272,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/vvardenfell_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7837001085,
                ["giver"] = "Avo Elarven",
                ["x"] = 0.6053663492,
                ["name"] = "The Scarlet Judge",
                ["otherInfo"] = 
                {
                    ["time"] = 1536797695,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.7866915464,
                ["giver"] = "Buoyant Armiger",
                ["x"] = 0.7578663826,
                ["name"] = "An Armiger's Duty",
                ["otherInfo"] = 
                {
                    ["time"] = 1536863121,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.7889339924,
                ["giver"] = "Halinjirr",
                ["x"] = 0.3934557736,
                ["name"] = "A Hidden Harvest",
                ["otherInfo"] = 
                {
                    ["time"] = 1536963658,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.8341385722,
                ["giver"] = "Deminah Salvi",
                ["preQuest"] = 5881,
                ["x"] = 0.4003142416,
                ["name"] = "Breaking Through the Fog",
                ["otherInfo"] = 
                {
                    ["time"] = 1536966177,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6888682246,
                ["giver"] = "Ridena Devani",
                ["preQuest"] = 5864,
                ["x"] = 0.8033443689,
                ["name"] = "A Dangerous Breed",
                ["otherInfo"] = 
                {
                    ["time"] = 1537330242,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.6943665147,
                ["giver"] = "Malur Rethan",
                ["x"] = 0.3774208128,
                ["name"] = "Like Blood from a Stone",
                ["otherInfo"] = 
                {
                    ["time"] = 1537396609,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.4763798118,
                ["giver"] = "Drelyth Hleran",
                ["x"] = 0.3748249710,
                ["name"] = "Ancestral Ties",
                ["otherInfo"] = 
                {
                    ["time"] = 1537472520,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.5050449371,
                ["giver"] = "Nakhul",
                ["x"] = 0.2451094985,
                ["name"] = "A Smuggler's Last Stand",
                ["otherInfo"] = 
                {
                    ["time"] = 1537474561,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.3093760610,
                ["giver"] = "Gray-Skies",
                ["x"] = 0.6810652018,
                ["name"] = "Reclaiming Vos",
                ["otherInfo"] = 
                {
                    ["time"] = 1537589497,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.2882005572,
                ["giver"] = "Mistress Dratha",
                ["preQuest"] = 5840,
                ["x"] = 0.7347040176,
                ["name"] = "At Any Cost",
                ["otherInfo"] = 
                {
                    ["time"] = 1537743325,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.4824226499,
                ["giver"] = "Sun-in-Shadow",
                ["x"] = 0.7749658823,
                ["name"] = "The Heart of a Telvanni",
                ["otherInfo"] = 
                {
                    ["time"] = 1537753641,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.2399889827,
                ["giver"] = "Udami",
                ["preQuest"] = 5922,
                ["x"] = 0.2678785026,
                ["name"] = "Ashlander Relations",
                ["otherInfo"] = 
                {
                    ["time"] = 1537853268,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.3704912066,
                ["giver"] = "Manore Mobaner",
                ["x"] = 0.1932953149,
                ["name"] = "A Melodic Mistake",
                ["otherInfo"] = 
                {
                    ["time"] = 1537856422,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.3698467016,
                ["giver"] = "Theyo Prevette",
                ["x"] = 0.2214670777,
                ["name"] = "Haunted Grounds",
                ["otherInfo"] = 
                {
                    ["time"] = 1537930194,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.3652084470,
                ["giver"] = "Foreman Lathdar",
                ["preQuest"] = 5872,
                ["x"] = 0.1909684092,
                ["name"] = "Hatching a Plan",
                ["otherInfo"] = 
                {
                    ["time"] = 1537933312,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["grahtwood/eldenhollow_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5466459394,
                ["giver"] = "Bakkhara",
                ["preQuest"] = 4107,
                ["x"] = 0.3663927019,
                ["name"] = "Ancient Remains",
                ["otherInfo"] = 
                {
                    ["time"] = 1536199213,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/salasen_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7185712457,
                ["giver"] = "Gurlak",
                ["x"] = 0.2225854546,
                ["name"] = "The Oldest Orc",
                ["otherInfo"] = 
                {
                    ["time"] = 1536021367,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/vivechow01a_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.5169770122,
                ["giver"] = "Librarian Bradyn",
                ["x"] = 0.7569060922,
                ["name"] = "The Lost Library",
                ["otherInfo"] = 
                {
                    ["time"] = 1537857516,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.4151149988,
                ["giver"] = "Librarian Bradyn",
                ["preQuest"] = 5885,
                ["x"] = 0.7845304012,
                ["name"] = "The Ancestral Tombs",
                ["otherInfo"] = 
                {
                    ["time"] = 1537504216,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/viviccity_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4175760448,
                ["giver"] = "Edryno Giryon",
                ["preQuest"] = 6007,
                ["x"] = 0.5224552155,
                ["name"] = "A Late Delivery",
                ["otherInfo"] = 
                {
                    ["time"] = 1536777892,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/summerset_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5346723199,
                ["giver"] = "Silurie",
                ["preQuest"] = 6170,
                ["x"] = 0.2925261259,
                ["name"] = "The Taste of Fear",
                ["otherInfo"] = 
                {
                    ["time"] = 1535251241,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5206859112,
                ["giver"] = "Celinar",
                ["x"] = 0.5957511067,
                ["name"] = "The Runaway's Tale",
                ["otherInfo"] = 
                {
                    ["time"] = 1535255755,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5220580101,
                ["giver"] = "Hiranesse",
                ["preQuest"] = 6151,
                ["x"] = 0.2685208023,
                ["name"] = "Lost at Sea",
                ["otherInfo"] = 
                {
                    ["time"] = 1535261874,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.4847295582,
                ["giver"] = "Rinyde",
                ["preQuest"] = 6149,
                ["x"] = 0.3724193871,
                ["name"] = "Manor of Masques",
                ["otherInfo"] = 
                {
                    ["time"] = 1535263016,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.4649710059,
                ["giver"] = "Linwenvar",
                ["preQuest"] = 6114,
                ["x"] = 0.4583003223,
                ["name"] = "Old Wounds",
                ["otherInfo"] = 
                {
                    ["time"] = 1535317497,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.3748296201,
                ["giver"] = "Oriandra",
                ["preQuest"] = 6135,
                ["x"] = 0.5359108448,
                ["name"] = "Whispers from the Deep",
                ["otherInfo"] = 
                {
                    ["time"] = 1535320156,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.3742801845,
                ["giver"] = "Andewen",
                ["x"] = 0.3586560786,
                ["name"] = "The Ebon Sanctum",
                ["otherInfo"] = 
                {
                    ["time"] = 1535338816,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.3584633172,
                ["giver"] = "Merenfire",
                ["x"] = 0.3263515234,
                ["name"] = "Illusions of Grandeur",
                ["otherInfo"] = 
                {
                    ["time"] = 1535338862,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.2951898277,
                ["giver"] = "Amsha",
                ["x"] = 0.2576109469,
                ["name"] = "Wasting Away",
                ["otherInfo"] = 
                {
                    ["time"] = 1535339223,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.4748214185,
                ["giver"] = "Tableau",
                ["x"] = 0.3235512078,
                ["name"] = "The Hulkynd's Heart",
                ["otherInfo"] = 
                {
                    ["time"] = 1535407539,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.2113002241,
                ["giver"] = "Renzir",
                ["preQuest"] = 6146,
                ["x"] = 0.2977776527,
                ["name"] = "An Unexpected Betrayal",
                ["otherInfo"] = 
                {
                    ["time"] = 1535431714,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.6039851308,
                ["giver"] = "Talomar",
                ["x"] = 0.6750555038,
                ["name"] = "Untamed and Unleashed",
                ["otherInfo"] = 
                {
                    ["time"] = 1535505848,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.7324187160,
                ["giver"] = "Igeke Rat-Bite",
                ["preQuest"] = 6121,
                ["x"] = 0.7185612917,
                ["name"] = "Gjadil's Legacy",
                ["otherInfo"] = 
                {
                    ["time"] = 1535513267,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.5546858907,
                ["giver"] = "Manacar",
                ["x"] = 0.2794109285,
                ["name"] = "Bantering with Bandits",
                ["otherInfo"] = 
                {
                    ["time"] = 1535562876,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.3029791117,
                ["giver"] = "Bailiff Erator",
                ["preQuest"] = 6140,
                ["x"] = 0.5906194448,
                ["name"] = "Lauriel's Lament",
                ["otherInfo"] = 
                {
                    ["time"] = 1535564644,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.2825572789,
                ["giver"] = "Miranrel",
                ["x"] = 0.5512996912,
                ["name"] = "Gryphon Grievance",
                ["otherInfo"] = 
                {
                    ["time"] = 1535576284,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.7353738546,
                ["giver"] = "Kinlady Ilunsare",
                ["preQuest"] = 6179,
                ["x"] = 0.4651895463,
                ["name"] = "Obedience Issues",
                ["otherInfo"] = 
                {
                    ["time"] = 1535577799,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.4188621342,
                ["giver"] = "Pandermalion",
                ["x"] = 0.2621946633,
                ["name"] = "Storming the Walls",
                ["otherInfo"] = 
                {
                    ["time"] = 1535660442,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/sandblownmine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4986650050,
                ["giver"] = "Letter to Fadeel",
                ["x"] = 0.5561488867,
                ["name"] = "The Real Snake",
                ["otherInfo"] = 
                {
                    ["time"] = 1536431569,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/coldrockdiggings_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3042840362,
                ["giver"] = "Promissory Note",
                ["x"] = 0.6747359037,
                ["name"] = "Past Due",
                ["otherInfo"] = 
                {
                    ["time"] = 1536546333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stonefalls/fungalgrotto_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7768288851,
                ["giver"] = "Vila Theran",
                ["x"] = 0.3413615227,
                ["name"] = "Kings of the Grotto",
                ["otherInfo"] = 
                {
                    ["time"] = 1534903204,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/imperviousvault_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5337469578,
                ["giver"] = "King Fahara'jad",
                ["preQuest"] = 2998,
                ["x"] = 0.7415758967,
                ["name"] = "Kingdom in Mourning",
                ["otherInfo"] = 
                {
                    ["time"] = 1536637446,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/cryptwatchfort_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3049505055,
                ["giver"] = "Hastily Scribbled Note",
                ["preQuest"] = 4080,
                ["x"] = 0.3861386180,
                ["name"] = "Fortune in Failure",
                ["otherInfo"] = 
                {
                    ["time"] = 1533695799,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["clockwork/clockworkoutlawsrefuge_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3236269057,
                ["giver"] = "Brengolin",
                ["x"] = 0.8880208135,
                ["name"] = "Tarnished Truffles",
                ["otherInfo"] = 
                {
                    ["time"] = 1536034433,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.3177083433,
                ["giver"] = "Brengolin",
                ["preQuest"] = 6059,
                ["x"] = 0.8927556872,
                ["name"] = "Tasty Tongue Varnish",
                ["otherInfo"] = 
                {
                    ["time"] = 1536097307,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.3283617496,
                ["giver"] = "Brengolin",
                ["preQuest"] = 6060,
                ["x"] = 0.8754734993,
                ["name"] = "A Matter of Tenderness",
                ["otherInfo"] = 
                {
                    ["time"] = 1536098581,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/dreamingcave02_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4740376472,
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.4700719118,
                ["name"] = "The Psijics' Calling",
                ["otherInfo"] = 
                {
                    ["time"] = 1535410158,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6987097859,
                ["giver"] = "Josajeh",
                ["preQuest"] = 6172,
                ["x"] = 0.2159475535,
                ["name"] = "Breaches On the Bay",
                ["otherInfo"] = 
                {
                    ["time"] = 1535593687,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.4301501811,
                ["giver"] = "Valsirenn",
                ["preQuest"] = 6125,
                ["x"] = 0.4051924646,
                ["name"] = "The Crystal Tower",
                ["otherInfo"] = 
                {
                    ["time"] = 1535773627,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.6967005134,
                ["giver"] = "Josajeh",
                ["preQuest"] = 6181,
                ["x"] = 0.2083333284,
                ["name"] = "Breaches of Frost and Fire",
                ["otherInfo"] = 
                {
                    ["time"] = 1536722193,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.4353320599,
                ["giver"] = "Loremaster Celarus",
                ["preQuest"] = 6185,
                ["x"] = 0.7799809575,
                ["name"] = "The Shattered Staff",
                ["otherInfo"] = 
                {
                    ["time"] = 1536983304,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.3812923133,
                ["giver"] = "Loremaster Celarus",
                ["preQuest"] = 6197,
                ["x"] = 0.7763853669,
                ["name"] = "A Breach Amid the Trees",
                ["otherInfo"] = 
                {
                    ["time"] = 1536987133,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.8366116881,
                ["giver"] = "Josajeh",
                ["preQuest"] = 6194,
                ["x"] = 0.2544944882,
                ["name"] = "A Time for Mud and Mushrooms",
                ["otherInfo"] = 
                {
                    ["time"] = 1537064293,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.4661061764,
                ["giver"] = "Loremaster Celarus",
                ["preQuest"] = 6190,
                ["x"] = 0.8109136820,
                ["name"] = "The Towers' Remains",
                ["otherInfo"] = 
                {
                    ["time"] = 1537150686,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.4019670188,
                ["giver"] = "Loremaster Celarus",
                ["preQuest"] = 6198,
                ["x"] = 0.7952094078,
                ["name"] = "Time in Doomcrag's Shadow",
                ["otherInfo"] = 
                {
                    ["time"] = 1537156099,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.3982656598,
                ["giver"] = "Loremaster Celarus",
                ["preQuest"] = 6195,
                ["x"] = 0.8043041229,
                ["name"] = "A Breach Beyond the Crags",
                ["otherInfo"] = 
                {
                    ["time"] = 1537158261,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.3783840835,
                ["giver"] = "Loremaster Celarus",
                ["preQuest"] = 6196,
                ["x"] = 0.7910321355,
                ["name"] = "The Towers' Fall",
                ["otherInfo"] = 
                {
                    ["time"] = 1537239403,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/kozanset_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4487309158,
                ["giver"] = "Hamza",
                ["x"] = 0.5800043941,
                ["name"] = "Feathered Fiends",
                ["otherInfo"] = 
                {
                    ["time"] = 1536432173,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/tribulationcrypt_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.1962851435,
                ["giver"] = "Ancient Sword",
                ["preQuest"] = 4844,
                ["x"] = 0.2981927693,
                ["name"] = "A Past Remembered",
                ["otherInfo"] = 
                {
                    ["time"] = 1534718973,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/badmanscave_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5939509273,
                ["giver"] = "Finvir",
                ["x"] = 0.6003810167,
                ["name"] = "Can't Take It With Them",
                ["otherInfo"] = 
                {
                    ["time"] = 1533694067,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/daggerfall_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3237193525,
                ["giver"] = "Swineherd Wickton",
                ["preQuest"] = 3039,
                ["x"] = 0.4550656676,
                ["name"] = "Swine Thief",
                ["otherInfo"] = 
                {
                    ["time"] = 1533677832,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2878405750,
                ["giver"] = "Mighty Mordra",
                ["x"] = 0.5131012201,
                ["name"] = "One of the Undaunted",
                ["otherInfo"] = 
                {
                    ["time"] = 1533677886,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.2740499675,
                ["giver"] = "Felande Demarie",
                ["x"] = 0.4846858084,
                ["name"] = "Room to Spare",
                ["otherInfo"] = 
                {
                    ["time"] = 1533678341,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5736614466,
                ["giver"] = "Beggar Matthew",
                ["preQuest"] = 3011,
                ["x"] = 0.5158903599,
                ["name"] = "Back-Alley Murders",
                ["otherInfo"] = 
                {
                    ["time"] = 1533679195,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.4101165533,
                ["giver"] = "Vanus Galerion",
                ["x"] = 0.4713554382,
                ["name"] = "Through a Veil Darkly",
                ["otherInfo"] = 
                {
                    ["time"] = 1535244755,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.3904083073,
                ["giver"] = "Arch-Mage Shalidor",
                ["preQuest"] = 3916,
                ["x"] = 0.5207746625,
                ["name"] = "Simply Misplaced",
                ["otherInfo"] = 
                {
                    ["time"] = 1535850142,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.3899323344,
                ["giver"] = "Arch-Mage Shalidor",
                ["preQuest"] = 3953,
                ["x"] = 0.5224900842,
                ["name"] = "The Mad God's Bargain",
                ["otherInfo"] = 
                {
                    ["time"] = 1535871355,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/vivecthroneroom01_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6491472721,
                ["giver"] = "Vivec",
                ["preQuest"] = 5803,
                ["x"] = 0.4857364297,
                ["name"] = "Divine Inquiries",
                ["otherInfo"] = 
                {
                    ["time"] = 1536777197,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5897674561,
                ["giver"] = "Archcanon Tarvus",
                ["preQuest"] = 5880,
                ["x"] = 0.5446511507,
                ["name"] = "Divine Delusions",
                ["otherInfo"] = 
                {
                    ["time"] = 1537504564,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6257364154,
                ["giver"] = "Archcanon Tarvus",
                ["preQuest"] = 5888,
                ["x"] = 0.4765891433,
                ["name"] = "Divine Intervention",
                ["otherInfo"] = 
                {
                    ["time"] = 1537926477,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/forgottenwastesext_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.2666381299,
                ["giver"] = "Tythis Nirith",
                ["preQuest"] = 5886,
                ["x"] = 0.8313843012,
                ["name"] = "Echoes of a Fallen House",
                ["otherInfo"] = 
                {
                    ["time"] = 1537568779,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/badmansstart_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6460055113,
                ["giver"] = "Curator Nicholas",
                ["preQuest"] = 4767,
                ["x"] = 0.4435261786,
                ["name"] = "Season of Harvest",
                ["otherInfo"] = 
                {
                    ["time"] = 1533693555,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/hoarfrost_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5418079495,
                ["giver"] = "Captain Thayer",
                ["x"] = 0.4679913223,
                ["name"] = "The Wayward Son",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631769,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5901261568,
                ["giver"] = "Captain Thayer",
                ["preQuest"] = 5020,
                ["x"] = 0.3932930827,
                ["name"] = "The Bandit",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5798182487,
                ["giver"] = "Captain Thayer",
                ["preQuest"] = 5022,
                ["x"] = 0.4004475772,
                ["name"] = "The Lover",
                ["otherInfo"] = 
                {
                    ["time"] = 1534650828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/shornhelm_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.2087104321,
                ["giver"] = "High King Emeric",
                ["preQuest"] = 4902,
                ["x"] = 0.5924155712,
                ["name"] = "Dream-Walk Into Darkness",
                ["otherInfo"] = 
                {
                    ["time"] = 1534547100,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.3165285885,
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4834,
                ["x"] = 0.5225196481,
                ["name"] = "A Spy in Shornhelm",
                ["otherInfo"] = 
                {
                    ["time"] = 1534720776,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6325260401,
                ["giver"] = "Nicolene",
                ["x"] = 0.4601444602,
                ["name"] = "Children of Yokuda",
                ["otherInfo"] = 
                {
                    ["time"] = 1534724812,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.3113873005,
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4945,
                ["x"] = 0.5138304830,
                ["name"] = "Assassin Hunter",
                ["otherInfo"] = 
                {
                    ["time"] = 1534735695,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.2218610644,
                ["giver"] = "Queen Maraya",
                ["preQuest"] = 4936,
                ["x"] = 0.6035054326,
                ["name"] = "Favor for the Queen",
                ["otherInfo"] = 
                {
                    ["time"] = 1535066382,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.6464839578,
                ["giver"] = "Arch-Mage Shalidor",
                ["preQuest"] = 3918,
                ["x"] = 0.3513490558,
                ["name"] = "Chateau of the Ravenous Rodent",
                ["otherInfo"] = 
                {
                    ["time"] = 1535870022,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["reapersmarch/reapersmarch_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.2042936236,
                ["giver"] = "Ancient Scroll",
                ["x"] = 0.6639211178,
                ["name"] = "Hircine's Gift",
                ["otherInfo"] = 
                {
                    ["time"] = 1536288690,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/artaeum_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.4446600974,
                ["giver"] = "Ulliceta gra-Kogg",
                ["x"] = 0.3989331722,
                ["name"] = "Half-Formed Understandings",
                ["otherInfo"] = 
                {
                    ["time"] = 1535594843,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.2702807188,
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6096,
                ["x"] = 0.6434336305,
                ["name"] = "A Pearl of Great Price",
                ["otherInfo"] = 
                {
                    ["time"] = 1535331163,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/alikr_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4980856478,
                ["giver"] = "Herminius Sophus",
                ["x"] = 0.1420014948,
                ["name"] = "Past in Ruins",
                ["otherInfo"] = 
                {
                    ["time"] = 1535068408,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6744162440,
                ["giver"] = "Lady Clarisse Laurent",
                ["x"] = 0.2751331925,
                ["name"] = "Thwarting the Aldmeri Dominion",
                ["otherInfo"] = 
                {
                    ["time"] = 1536019893,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6599228382,
                ["giver"] = "Stibbons",
                ["x"] = 0.2463007271,
                ["name"] = "Lady Laurent's Favor",
                ["otherInfo"] = 
                {
                    ["time"] = 1536020090,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.6580856442,
                ["giver"] = "Marimah",
                ["preQuest"] = 4672,
                ["x"] = 0.2971570790,
                ["name"] = "The Initiation",
                ["otherInfo"] = 
                {
                    ["time"] = 1536178583,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6594074965,
                ["giver"] = "Talia at-Marimah",
                ["preQuest"] = 4686,
                ["x"] = 0.2966592014,
                ["name"] = "Ash'abah Rising",
                ["otherInfo"] = 
                {
                    ["time"] = 1536180217,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.6000323892,
                ["giver"] = "Anjan",
                ["x"] = 0.3212123513,
                ["name"] = "The Nature of Fate",
                ["otherInfo"] = 
                {
                    ["time"] = 1536180330,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.5750286579,
                ["giver"] = "Throne Keeper Farvad",
                ["x"] = 0.3972641230,
                ["name"] = "Tu'whacca's Breath",
                ["otherInfo"] = 
                {
                    ["time"] = 1536279743,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.5544087887,
                ["giver"] = "Ramati at-Gar",
                ["preQuest"] = 3190,
                ["x"] = 0.4091062844,
                ["name"] = "Revered Ancestors",
                ["otherInfo"] = 
                {
                    ["time"] = 1536279855,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.5306970477,
                ["giver"] = "Throne Keeper Farvad",
                ["preQuest"] = 2184,
                ["x"] = 0.4021185040,
                ["name"] = "A Reckoning with Uwafa",
                ["otherInfo"] = 
                {
                    ["time"] = 1536352135,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.5306920409,
                ["giver"] = "Throne Keeper Farvad",
                ["preQuest"] = 2192,
                ["x"] = 0.4317500591,
                ["name"] = "The Scholar of Bergama",
                ["otherInfo"] = 
                {
                    ["time"] = 1536352628,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.5347821712,
                ["giver"] = "Samsi af-Bazra",
                ["x"] = 0.3236694038,
                ["name"] = "Badwater Mine",
                ["otherInfo"] = 
                {
                    ["time"] = 1536372240,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.6404829621,
                ["giver"] = "Hayazzin",
                ["preQuest"] = 3383,
                ["x"] = 0.3955812752,
                ["name"] = "Satak was the First Serpent",
                ["otherInfo"] = 
                {
                    ["time"] = 1536372763,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.5868707895,
                ["giver"] = "Letta",
                ["x"] = 0.5881976485,
                ["name"] = "Snakes in the Sands",
                ["otherInfo"] = 
                {
                    ["time"] = 1536381303,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.5111326575,
                ["giver"] = "Darius",
                ["x"] = 0.8310804367,
                ["name"] = "Honoring the Dishonored",
                ["otherInfo"] = 
                {
                    ["time"] = 1536428264,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.6113567352,
                ["giver"] = "Onwyn",
                ["preQuest"] = 3970,
                ["x"] = 0.4959322810,
                ["name"] = "A Winner for Onwyn",
                ["otherInfo"] = 
                {
                    ["time"] = 1536447037,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.5169479847,
                ["giver"] = "Kasal",
                ["x"] = 0.5143863559,
                ["name"] = "Crawling Chaos",
                ["otherInfo"] = 
                {
                    ["time"] = 1536457310,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.5050261617,
                ["giver"] = "Leki's Disciple",
                ["preQuest"] = 2255,
                ["x"] = 0.5780732036,
                ["name"] = "Master of Leki's Blade",
                ["otherInfo"] = 
                {
                    ["time"] = 1536458167,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.5162708759,
                ["giver"] = "Musi",
                ["x"] = 0.5640453100,
                ["name"] = "Undying Loyalty",
                ["otherInfo"] = 
                {
                    ["time"] = 1536458202,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.5207567811,
                ["giver"] = "Hadoon",
                ["preQuest"] = 4754,
                ["x"] = 0.6632511616,
                ["name"] = "The Nature of Fate: Part Two",
                ["otherInfo"] = 
                {
                    ["time"] = 1536461018,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.5130893588,
                ["giver"] = "Throne Keeper Farvad",
                ["preQuest"] = 3367,
                ["x"] = 0.7338088155,
                ["name"] = "March of the Ra Gada",
                ["otherInfo"] = 
                {
                    ["time"] = 1536463157,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.5679935217,
                ["giver"] = "Throne Keeper Farvad",
                ["preQuest"] = 2356,
                ["x"] = 0.7541349530,
                ["name"] = "Trials of the Hero",
                ["otherInfo"] = 
                {
                    ["time"] = 1536467785,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["y"] = 0.4839780927,
                ["giver"] = "Uhrih",
                ["preQuest"] = 3296,
                ["x"] = 0.6972267628,
                ["name"] = "Malignant Militia",
                ["otherInfo"] = 
                {
                    ["time"] = 1536468477,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["y"] = 0.4343739152,
                ["giver"] = "Aqabi of the Ungodly",
                ["preQuest"] = 4731,
                ["x"] = 0.5570375919,
                ["name"] = "Whose Wedding?",
                ["otherInfo"] = 
                {
                    ["time"] = 1536469203,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [24] = 
            {
                ["y"] = 0.3558725417,
                ["giver"] = "Talia at-Marimah",
                ["preQuest"] = 4760,
                ["x"] = 0.5669330359,
                ["name"] = "Alasan's Plot",
                ["otherInfo"] = 
                {
                    ["time"] = 1536535974,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [25] = 
            {
                ["y"] = 0.3352153301,
                ["giver"] = "Jeromec Lemal",
                ["x"] = 0.5701867342,
                ["name"] = "Warship Designs",
                ["otherInfo"] = 
                {
                    ["time"] = 1536536153,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [26] = 
            {
                ["y"] = 0.3564052880,
                ["giver"] = "Shiri",
                ["preQuest"] = 2222,
                ["x"] = 0.5660890937,
                ["name"] = "Shiri's Research",
                ["otherInfo"] = 
                {
                    ["time"] = 1536554353,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [27] = 
            {
                ["y"] = 0.5097684860,
                ["giver"] = "Captain Rawan",
                ["preQuest"] = 2240,
                ["x"] = 0.7369155884,
                ["name"] = "The Search for Shiri",
                ["otherInfo"] = 
                {
                    ["time"] = 1536617240,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [28] = 
            {
                ["y"] = 0.3919790983,
                ["giver"] = "General Thoda",
                ["x"] = 0.8402663469,
                ["name"] = "Imperial Incursion",
                ["otherInfo"] = 
                {
                    ["time"] = 1536617590,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [29] = 
            {
                ["y"] = 0.3394672573,
                ["giver"] = "High Priest Zuladr",
                ["x"] = 0.8084615469,
                ["name"] = "Temple's Treasures",
                ["otherInfo"] = 
                {
                    ["time"] = 1536618662,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [30] = 
            {
                ["y"] = 0.3409484625,
                ["giver"] = "General Thoda",
                ["preQuest"] = 2404,
                ["x"] = 0.8407717347,
                ["name"] = "Amputating the Hand",
                ["otherInfo"] = 
                {
                    ["time"] = 1536622233,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [31] = 
            {
                ["y"] = 0.2969753444,
                ["giver"] = "Ansei Halelah",
                ["preQuest"] = 2997,
                ["x"] = 0.7744261622,
                ["name"] = "Restoring the Ansei Wards",
                ["otherInfo"] = 
                {
                    ["time"] = 1536637029,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/sunhold_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7812337875,
                ["giver"] = "Kinlady Helenaere",
                ["x"] = 0.7326334715,
                ["name"] = "Sunhold Sundered",
                ["otherInfo"] = 
                {
                    ["time"] = 1535584965,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/orcsfingerruins_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5621206164,
                ["giver"] = "Teeba-Ja",
                ["x"] = 0.6867665052,
                ["name"] = "Shedding the Past",
                ["otherInfo"] = 
                {
                    ["time"] = 1534990861,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/etonnir_01"] = 
        {
            [1] = 
            {
                ["y"] = 0.3739441335,
                ["giver"] = "Seeks-the-Dark",
                ["preQuest"] = 6174,
                ["x"] = 0.9197530746,
                ["name"] = "Looting the Light",
                ["otherInfo"] = 
                {
                    ["time"] = 1535321772,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/crestshademine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3638949394,
                ["giver"] = "Troll Socialization Research Notes",
                ["x"] = 0.4132508039,
                ["name"] = "Friend of Trolls",
                ["otherInfo"] = 
                {
                    ["time"] = 1534624071,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/bearclawmine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4829317331,
                ["giver"] = "Hubert",
                ["x"] = 0.3204819262,
                ["name"] = "Next of Kin",
                ["otherInfo"] = 
                {
                    ["time"] = 1534364051,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["bangkorai/evermore_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5988582373,
                ["giver"] = "Sergeant Antieve",
                ["x"] = 0.2374275327,
                ["name"] = "A City in Black",
                ["otherInfo"] = 
                {
                    ["time"] = 1536637763,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2207296342,
                ["giver"] = "Llotha Nelvani",
                ["x"] = 0.6538221240,
                ["name"] = "A Grave Matter",
                ["otherInfo"] = 
                {
                    ["time"] = 1536639113,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.3479261398,
                ["giver"] = "Zaag",
                ["preQuest"] = 4980,
                ["x"] = 0.5188118815,
                ["name"] = "Conflicted Emotions",
                ["otherInfo"] = 
                {
                    ["time"] = 1536712003,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/divadschagrinmine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5220297575,
                ["giver"] = "Armin",
                ["x"] = 0.1543603837,
                ["name"] = "The Search is Over",
                ["otherInfo"] = 
                {
                    ["time"] = 1536357513,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/alcairecastle_base"] = 
        {
            [4] = 
            {
                ["y"] = 0.4368499517,
                ["giver"] = "Duke Nathaniel",
                ["preQuest"] = 2567,
                ["x"] = 0.4016301334,
                ["name"] = "Tracking Sir Hughes",
                ["otherInfo"] = 
                {
                    ["time"] = 1533955857,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.3651475012,
                ["giver"] = "Sir Hughes",
                ["preQuest"] = 2552,
                ["x"] = 0.4701412022,
                ["name"] = "Two Sides to Every Coin",
                ["otherInfo"] = 
                {
                    ["time"] = 1533950269,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.4338193238,
                ["giver"] = "Duchess Lakana",
                ["preQuest"] = 2564,
                ["x"] = 0.4061531425,
                ["name"] = "Life of the Duchess",
                ["otherInfo"] = 
                {
                    ["time"] = 1533951481,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5228102207,
                ["giver"] = "Sir Hughes",
                ["preQuest"] = 2566,
                ["x"] = 0.3367925584,
                ["name"] = "The Safety of the Kingdom",
                ["otherInfo"] = 
                {
                    ["time"] = 1533955422,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/collegeofpsijicsruins_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4317321479,
                ["giver"] = "Relicmaster Glenadir",
                ["x"] = 0.5981447697,
                ["name"] = "The Vault of Moawita",
                ["otherInfo"] = 
                {
                    ["time"] = 1535331338,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/hildunessecretrefuge_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3277197778,
                ["giver"] = "Nadafa's Journal",
                ["x"] = 0.6928258538,
                ["name"] = "Love Lost",
                ["otherInfo"] = 
                {
                    ["time"] = 1534896674,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/northpoint_base"] = 
        {
            [4] = 
            {
                ["y"] = 0.5237141848,
                ["giver"] = "Blademaster Qariar",
                ["preQuest"] = 4916,
                ["x"] = 0.3138366342,
                ["name"] = "The Last of Them",
                ["otherInfo"] = 
                {
                    ["time"] = 1534915414,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.1727312952,
                ["giver"] = "Skordo the Knife",
                ["preQuest"] = 4958,
                ["x"] = 0.4576599598,
                ["name"] = "The Liberation of Northpoint",
                ["otherInfo"] = 
                {
                    ["time"] = 1534897233,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5755673051,
                ["giver"] = "Baron Alard Dorell",
                ["preQuest"] = 4972,
                ["x"] = 0.5080171227,
                ["name"] = "Puzzle of the Pass",
                ["otherInfo"] = 
                {
                    ["time"] = 1534915013,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.4246223271,
                ["giver"] = "Short-Tail",
                ["x"] = 0.6390510201,
                ["name"] = "Guar Gone",
                ["otherInfo"] = 
                {
                    ["time"] = 1534915193,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/shroudedpass_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.2501651645,
                ["giver"] = "Count Verandis Ravenwatch",
                ["preQuest"] = 5024,
                ["x"] = 0.2278132588,
                ["name"] = "The Lightless Remnant",
                ["otherInfo"] = 
                {
                    ["time"] = 1534996733,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/sadrithmora_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4552703798,
                ["giver"] = "Eoki",
                ["x"] = 0.2976600230,
                ["name"] = "A Hireling of House Telvanni",
                ["otherInfo"] = 
                {
                    ["time"] = 1536778382,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5542289615,
                ["giver"] = "Llonas Givyn",
                ["x"] = 0.3116475642,
                ["name"] = "Bound by Love",
                ["otherInfo"] = 
                {
                    ["time"] = 1536778413,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.3695585728,
                ["giver"] = "Eoki",
                ["preQuest"] = 5799,
                ["x"] = 0.3429779112,
                ["name"] = "Rising to Retainer",
                ["otherInfo"] = 
                {
                    ["time"] = 1536896431,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.3551135063,
                ["giver"] = "Eoki",
                ["preQuest"] = 5859,
                ["x"] = 0.3371606469,
                ["name"] = "Objections and Obstacles",
                ["otherInfo"] = 
                {
                    ["time"] = 1537668902,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.3918471336,
                ["giver"] = "Sun-in-Shadow",
                ["preQuest"] = 5901,
                ["x"] = 0.3435879648,
                ["name"] = "The Magister Makes a Move",
                ["otherInfo"] = 
                {
                    ["time"] = 1537744209,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/ui_map"] = 
        {
            [1] = 
            {
                ["y"] = 0.2734320164,
                ["giver"] = "Olorime",
                ["x"] = 0.4132726490,
                ["name"] = "Woe of the Welkynars",
                ["otherInfo"] = 
                {
                    ["time"] = 1534294704,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["darkbrotherhood/anvilcity_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.6872546673,
                ["giver"] = "Speaker Terenus",
                ["preQuest"] = 5538,
                ["x"] = 0.2361459881,
                ["name"] = "Signed in Blood",
                ["otherInfo"] = 
                {
                    ["time"] = 1537674191,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.4991512597,
                ["giver"] = "Amelie Crowe",
                ["x"] = 0.3620963991,
                ["name"] = "Voices in the Dark",
                ["otherInfo"] = 
                {
                    ["time"] = 1537673741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/lillandrill_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.8553342223,
                ["giver"] = "Tindoria",
                ["x"] = 0.3591848612,
                ["name"] = "The Perils of Art",
                ["otherInfo"] = 
                {
                    ["time"] = 1535503983,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.6400873661,
                ["giver"] = "Faralan",
                ["x"] = 0.5875323415,
                ["name"] = "Murder In Lillandril",
                ["otherInfo"] = 
                {
                    ["time"] = 1535493532,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/obsidianscar_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.8949609399,
                ["giver"] = "Lashgikh",
                ["preQuest"] = 4923,
                ["x"] = 0.3315152228,
                ["name"] = "Foul Deeds in the Deep",
                ["otherInfo"] = 
                {
                    ["time"] = 1534833619,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/portdunwatch_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3056835532,
                ["giver"] = "Remy Berard",
                ["x"] = 0.4718382061,
                ["name"] = "Do as I Say",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943190,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["grahtwood/eldenrootservices_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4082742929,
                ["giver"] = "Undaunted Enclave Invitation",
                ["x"] = 0.6841142774,
                ["name"] = "Taking the Undaunted Pledge",
                ["otherInfo"] = 
                {
                    ["time"] = 1534827071,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/minesofkhuras_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7706518769,
                ["giver"] = "Guifford Vinielle's Sketchbook",
                ["preQuest"] = 3440,
                ["x"] = 0.3869094849,
                ["name"] = "A Brush With Death",
                ["otherInfo"] = 
                {
                    ["time"] = 1533705261,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/sentinel_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.1584839523,
                ["giver"] = "Captain Albert Marck",
                ["preQuest"] = 4949,
                ["x"] = 0.2926796973,
                ["name"] = "Risen From the Depths",
                ["otherInfo"] = 
                {
                    ["time"] = 1535066932,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.5169557929,
                ["giver"] = "Watch Captain Zafira",
                ["x"] = 0.2063108236,
                ["name"] = "Rise of the Dead",
                ["otherInfo"] = 
                {
                    ["time"] = 1535068009,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5333856940,
                ["giver"] = "Suspicious Monkey",
                ["x"] = 0.3683007956,
                ["name"] = "Monkey Magic",
                ["otherInfo"] = 
                {
                    ["time"] = 1535919356,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5817687511,
                ["giver"] = "Ildani",
                ["preQuest"] = 3333,
                ["x"] = 0.2022365928,
                ["name"] = "Seize the Moment",
                ["otherInfo"] = 
                {
                    ["time"] = 1535922375,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6957021356,
                ["giver"] = "King Fahara'jad",
                ["preQuest"] = 2146,
                ["x"] = 0.6791270971,
                ["name"] = "In Search of the Ash'abah",
                ["otherInfo"] = 
                {
                    ["time"] = 1535930876,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.2641271353,
                ["giver"] = "Recruit Maelle",
                ["preQuest"] = 3379,
                ["x"] = 0.6233919263,
                ["name"] = "A Dangerous Dream",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506571,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2552480102,
                ["giver"] = "Garmeg the Ironfinder",
                ["x"] = 0.6356987953,
                ["name"] = "Legitimate Interests",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506619,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.2836774588,
                ["giver"] = "Provost Piper",
                ["x"] = 0.6614254117,
                ["name"] = "Vines and Villains",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506677,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.2603922486,
                ["giver"] = "Sir Marley Oris",
                ["x"] = 0.6967237592,
                ["name"] = "Cursed Treasure",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506771,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.2198418677,
                ["giver"] = "Harald Winvale",
                ["preQuest"] = 6227,
                ["x"] = 0.7467461228,
                ["name"] = "Forgotten Ancestry",
                ["otherInfo"] = 
                {
                    ["time"] = 1533526292,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.2978167236,
                ["giver"] = "Stibbons",
                ["preQuest"] = 3509,
                ["x"] = 0.7838526368,
                ["name"] = "The Jeweled Crown of Anton",
                ["otherInfo"] = 
                {
                    ["time"] = 1533528128,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.1833901852,
                ["giver"] = "King Donel Deleyn",
                ["preQuest"] = 3050,
                ["x"] = 0.7397236228,
                ["name"] = "Servants of Ancient Kings",
                ["otherInfo"] = 
                {
                    ["time"] = 1533594760,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.2773717642,
                ["giver"] = "Sir Malik Nasir",
                ["x"] = 0.5530404449,
                ["name"] = "The Corpse Horde",
                ["otherInfo"] = 
                {
                    ["time"] = 1533609896,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.7047001719,
                ["giver"] = "Daggerfall Patroller",
                ["preQuest"] = 3314,
                ["x"] = 0.4874128997,
                ["name"] = "Farlivere's Gambit",
                ["otherInfo"] = 
                {
                    ["time"] = 1533616621,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.6687227488,
                ["giver"] = "Lord Arcady Noellaume",
                ["preQuest"] = 3001,
                ["x"] = 0.5088144541,
                ["name"] = "Disorganized Crime",
                ["otherInfo"] = 
                {
                    ["time"] = 1533617294,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.6681137681,
                ["giver"] = "Lady Eloise Noellaume",
                ["x"] = 0.5077500343,
                ["name"] = "Lady Eloise's Lockbox",
                ["otherInfo"] = 
                {
                    ["time"] = 1533617404,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.4949662387,
                ["giver"] = "Erwan Castille",
                ["preQuest"] = 4335,
                ["x"] = 0.5817878842,
                ["name"] = "Wicked Trade",
                ["otherInfo"] = 
                {
                    ["time"] = 1533670237,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.5040016770,
                ["giver"] = "Guy LeBlanc",
                ["preQuest"] = 3023,
                ["x"] = 0.6777231693,
                ["name"] = "Wyrd and Coven",
                ["otherInfo"] = 
                {
                    ["time"] = 1533670926,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.4546503127,
                ["giver"] = "Mercenary",
                ["x"] = 0.6808248162,
                ["name"] = "Crocodile Bounty",
                ["otherInfo"] = 
                {
                    ["time"] = 1533671046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.7100141644,
                ["giver"] = "Athel Baelborne",
                ["preQuest"] = 3017,
                ["x"] = 0.3761095703,
                ["name"] = "Legacy of Baelborne Rock",
                ["otherInfo"] = 
                {
                    ["time"] = 1533679671,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.6140681505,
                ["giver"] = "Lord Alain Diel",
                ["preQuest"] = 3414,
                ["x"] = 0.3377877176,
                ["name"] = "The Dagger's Edge",
                ["otherInfo"] = 
                {
                    ["time"] = 1533686910,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.4058459699,
                ["giver"] = "Leon Milielle",
                ["x"] = 0.4421305656,
                ["name"] = "The Ghosts of Westtry",
                ["otherInfo"] = 
                {
                    ["time"] = 1533699922,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.4247629941,
                ["giver"] = "Leon Milielle",
                ["preQuest"] = 3019,
                ["x"] = 0.3977132440,
                ["name"] = "Memento Mori",
                ["otherInfo"] = 
                {
                    ["time"] = 1533701453,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.3811810613,
                ["giver"] = "Lieutenant Clarice",
                ["preQuest"] = 3020,
                ["x"] = 0.3257557452,
                ["name"] = "Signals of Dominion",
                ["otherInfo"] = 
                {
                    ["time"] = 1533702206,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.3935525715,
                ["giver"] = "Scout's Orders",
                ["x"] = 0.3128614426,
                ["name"] = "Wayward Scouts",
                ["otherInfo"] = 
                {
                    ["time"] = 1533702234,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["auridon/bewan_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6983050704,
                ["giver"] = "Altmeri Relic",
                ["x"] = 0.5038520694,
                ["name"] = "Lost Bet",
                ["otherInfo"] = 
                {
                    ["time"] = 1535248036,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/dreamingcave03_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7077407837,
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6112,
                ["x"] = 0.6542621255,
                ["name"] = "Buried Memories",
                ["otherInfo"] = 
                {
                    ["time"] = 1535594149,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.7504896522,
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6132,
                ["x"] = 0.6307587624,
                ["name"] = "The Tower Sentinels",
                ["otherInfo"] = 
                {
                    ["time"] = 1535601322,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6959039569,
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6142,
                ["x"] = 0.6557949185,
                ["name"] = "The Dreaming Cave",
                ["otherInfo"] = 
                {
                    ["time"] = 1535690559,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/bonesnapruinssecret_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.6375247836,
                ["giver"] = "Sir Edgard",
                ["x"] = 0.6059898734,
                ["name"] = "Lost Lions",
                ["otherInfo"] = 
                {
                    ["time"] = 1533871296,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.8454304934,
                ["giver"] = "Battlemage Gaston",
                ["preQuest"] = 1637,
                ["x"] = 0.6948909760,
                ["name"] = "Repairing the Cage",
                ["otherInfo"] = 
                {
                    ["time"] = 1533868567,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/norvulkruins_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.8044354916,
                ["giver"] = "Matys Derone",
                ["x"] = 0.5907257795,
                ["name"] = "Word from the Dead",
                ["otherInfo"] = 
                {
                    ["time"] = 1534368364,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/vivecthroneroom02_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6120930314,
                ["giver"] = "Canon Llevule",
                ["preQuest"] = 5893,
                ["x"] = 0.3975193799,
                ["name"] = "Divine Disaster",
                ["otherInfo"] = 
                {
                    ["time"] = 1538012100,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.3184496164,
                ["giver"] = "Vivec",
                ["preQuest"] = 5902,
                ["x"] = 0.4530232549,
                ["name"] = "Divine Restoration",
                ["otherInfo"] = 
                {
                    ["time"] = 1538013900,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.3364340961,
                ["giver"] = "Vivec",
                ["preQuest"] = 5905,
                ["x"] = 0.4849612415,
                ["name"] = "Divine Blessings",
                ["otherInfo"] = 
                {
                    ["time"] = 1538022047,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/bergama_base"] = 
        {
            [4] = 
            {
                ["y"] = 0.2626455426,
                ["giver"] = "Jarrod",
                ["preQuest"] = 2344,
                ["x"] = 0.7893781066,
                ["name"] = "Trapped in the Bluffs",
                ["otherInfo"] = 
                {
                    ["time"] = 1536381627,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.5567598939,
                ["giver"] = "Qadim",
                ["preQuest"] = 3344,
                ["x"] = 0.1632595807,
                ["name"] = "Gone Missing",
                ["otherInfo"] = 
                {
                    ["time"] = 1536373428,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.4496798813,
                ["giver"] = "Jagnas",
                ["x"] = 0.5938260555,
                ["name"] = "Left at the Altar",
                ["otherInfo"] = 
                {
                    ["time"] = 1536376454,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.4399827719,
                ["giver"] = "Meriq",
                ["preQuest"] = 2251,
                ["x"] = 0.5318244696,
                ["name"] = "Trouble at Tava's Blessing",
                ["otherInfo"] = 
                {
                    ["time"] = 1536378812,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["auridon/vulkhelguard_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6363090277,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6363090277,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6363090277,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033477,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5947007537,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.5947007537,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.5947007537,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.5947007537,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.6336819530,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.6336819530,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.6336819530,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196952,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.5952637196,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5952637196,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.5952637196,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.5952637196,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214704,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.6322933435,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.6322933435,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.6322933435,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214742,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.5761359334,
                ["giver"] = "Sealed Clothier Writ",
                ["preQuest"] = 6228,
                ["x"] = 0.3380454481,
                ["name"] = "Masterful Leatherwear",
                ["otherInfo"] = 
                {
                    ["time"] = 1534215666,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.5761359334,
                ["giver"] = "Sealed Alchemy Writ",
                ["x"] = 0.3380454481,
                ["name"] = "A Masterful Concoction",
                ["otherInfo"] = 
                {
                    ["time"] = 1534215692,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.5142739415,
                ["giver"] = "Battlemaster Rivyn",
                ["preQuest"] = 5952,
                ["x"] = 0.5293735266,
                ["name"] = "Test of Mettle",
                ["otherInfo"] = 
                {
                    ["time"] = 1535167121,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.5142739415,
                ["giver"] = "Battlemaster Rivyn",
                ["preQuest"] = 5954,
                ["x"] = 0.5293610096,
                ["name"] = "Let the Games Begin",
                ["otherInfo"] = 
                {
                    ["time"] = 1535169644,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["y"] = 0.5972027779,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["y"] = 0.5972027779,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [24] = 
            {
                ["y"] = 0.5972027779,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [25] = 
            {
                ["y"] = 0.5972027779,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165506,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [26] = 
            {
                ["y"] = 0.6320431232,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2808997333,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [27] = 
            {
                ["y"] = 0.6320431232,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2808997333,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [28] = 
            {
                ["y"] = 0.6320431232,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2808997333,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [29] = 
            {
                ["y"] = 0.5947132707,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276305,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [30] = 
            {
                ["y"] = 0.5947132707,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [31] = 
            {
                ["y"] = 0.5947132707,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [32] = 
            {
                ["y"] = 0.5947132707,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [33] = 
            {
                ["y"] = 0.6298664212,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2842649221,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [34] = 
            {
                ["y"] = 0.6298664212,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2842649221,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [35] = 
            {
                ["y"] = 0.6298664212,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2842649221,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [36] = 
            {
                ["y"] = 0.5956890583,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724534,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [37] = 
            {
                ["y"] = 0.5956890583,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [38] = 
            {
                ["y"] = 0.5956890583,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [39] = 
            {
                ["y"] = 0.5956890583,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [40] = 
            {
                ["y"] = 0.6317679286,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2820006013,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [41] = 
            {
                ["y"] = 0.6317679286,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2820006013,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [42] = 
            {
                ["y"] = 0.6317679286,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2820006013,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [43] = 
            {
                ["y"] = 0.5962395072,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725827,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [44] = 
            {
                ["y"] = 0.5962395072,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725827,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [45] = 
            {
                ["y"] = 0.5962395072,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [46] = 
            {
                ["y"] = 0.5962395072,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [47] = 
            {
                ["y"] = 0.6304793954,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2839646637,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725860,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [48] = 
            {
                ["y"] = 0.6304793954,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2839646637,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725861,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [49] = 
            {
                ["y"] = 0.6304793954,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2839646637,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536725861,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [50] = 
            {
                ["y"] = 0.6361964345,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2822132707,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [51] = 
            {
                ["y"] = 0.6361964345,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2822132707,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [52] = 
            {
                ["y"] = 0.6361964345,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2822132707,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [53] = 
            {
                ["y"] = 0.5950009823,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [54] = 
            {
                ["y"] = 0.5950009823,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [55] = 
            {
                ["y"] = 0.5950009823,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [56] = 
            {
                ["y"] = 0.5950009823,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/farangelsdelve_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4242919385,
                ["giver"] = "Tomb Urn",
                ["preQuest"] = 2550,
                ["x"] = 0.4327341914,
                ["name"] = "Stolen Ashes",
                ["otherInfo"] = 
                {
                    ["time"] = 1534129561,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["grahtwood/eldenrootgroundfloor_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6416119933,
                ["giver"] = "Sealed Woodworking Writ",
                ["preQuest"] = 6022,
                ["x"] = 0.7304733396,
                ["name"] = "A Masterful Shield",
                ["otherInfo"] = 
                {
                    ["time"] = 1534216349,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6416119933,
                ["giver"] = "Sealed Enchanting Writ",
                ["x"] = 0.7304733396,
                ["name"] = "A Masterful Glyph",
                ["otherInfo"] = 
                {
                    ["time"] = 1534216360,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6324936152,
                ["giver"] = "Sealed Alchemy Writ",
                ["preQuest"] = 6228,
                ["x"] = 0.7366622090,
                ["name"] = "A Masterful Concoction",
                ["otherInfo"] = 
                {
                    ["time"] = 1536277342,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.6324936152,
                ["giver"] = "Sealed Blacksmithing Writ",
                ["x"] = 0.7366622090,
                ["name"] = "A Masterful Weapon",
                ["otherInfo"] = 
                {
                    ["time"] = 1536277352,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6324936152,
                ["giver"] = "Sealed Enchanting Writ",
                ["x"] = 0.7366622090,
                ["name"] = "A Masterful Glyph",
                ["otherInfo"] = 
                {
                    ["time"] = 1536277364,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.6388408542,
                ["giver"] = "Sealed Enchanting Writ",
                ["preQuest"] = 5973,
                ["x"] = 0.7290217876,
                ["name"] = "A Masterful Glyph",
                ["otherInfo"] = 
                {
                    ["time"] = 1536278199,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/wayrest_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.1780604571,
                ["giver"] = "M'jaddha",
                ["x"] = 0.4391658008,
                ["name"] = "The Debt Collector's Debts",
                ["otherInfo"] = 
                {
                    ["time"] = 1534116513,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.1300478876,
                ["giver"] = "Sergeant Stegine",
                ["x"] = 0.2756144106,
                ["name"] = "The Dreugh Threat",
                ["otherInfo"] = 
                {
                    ["time"] = 1534125955,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.0535364039,
                ["giver"] = "Adiel Charnis",
                ["preQuest"] = 2068,
                ["x"] = 0.2342794538,
                ["name"] = "They Dragged Him Away",
                ["otherInfo"] = 
                {
                    ["time"] = 1534127126,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.2255538255,
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["x"] = 0.3749423027,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.2255538255,
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["x"] = 0.3749423027,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.2255538255,
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["x"] = 0.3749423027,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.2255538255,
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["x"] = 0.3749423027,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196577,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.2736096680,
                ["giver"] = "Janne Marolles",
                ["x"] = 1.0325227976,
                ["name"] = "Old Adventurers",
                ["otherInfo"] = 
                {
                    ["time"] = 1534283292,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.3309824765,
                ["giver"] = "Eldrasea Deras",
                ["preQuest"] = 1615,
                ["x"] = 0.6182646751,
                ["name"] = "To The Clockwork City",
                ["otherInfo"] = 
                {
                    ["time"] = 1534367222,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.4614630342,
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 521,
                ["x"] = 0.4303103685,
                ["name"] = "Vaermina's Gambit",
                ["otherInfo"] = 
                {
                    ["time"] = 1534373250,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.4613187909,
                ["giver"] = "High King Emeric",
                ["preQuest"] = 575,
                ["x"] = 0.3795575202,
                ["name"] = "The Road to Rivenspire",
                ["otherInfo"] = 
                {
                    ["time"] = 1534374724,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5017451048,
                ["giver"] = "Urgarlag Chief-bane",
                ["x"] = 0.1636523604,
                ["name"] = "Pledge: Moon Hunter Keep",
                ["otherInfo"] = 
                {
                    ["time"] = 1534387635,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.4949232638,
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1531094909,
                ["name"] = "Pledge: Fungal Grotto I",
                ["otherInfo"] = 
                {
                    ["time"] = 1534903120,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.4953559339,
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1525470167,
                ["name"] = "Pledge: Fungal Grotto I",
                ["otherInfo"] = 
                {
                    ["time"] = 1534905260,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.4776739478,
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1517682076,
                ["name"] = "Pledge: Crypt of Hearts I",
                ["otherInfo"] = 
                {
                    ["time"] = 1535077586,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.4947213531,
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1553738266,
                ["name"] = "Pledge: Darkshade Caverns I",
                ["otherInfo"] = 
                {
                    ["time"] = 1535077599,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.4767653048,
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1539315730,
                ["name"] = "Pledge: Vaults of Madness",
                ["otherInfo"] = 
                {
                    ["time"] = 1535399588,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.4954713285,
                ["giver"] = "Alvur Baren",
                ["x"] = 0.5489355922,
                ["name"] = "Madness in Reaper's March",
                ["otherInfo"] = 
                {
                    ["time"] = 1535850518,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.4661936164,
                ["giver"] = "Arch-Mage Shalidor",
                ["preQuest"] = 4435,
                ["x"] = 0.5344698429,
                ["name"] = "Circus of Cheerful Slaughter",
                ["otherInfo"] = 
                {
                    ["time"] = 1535851711,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.4758134186,
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1524027884,
                ["name"] = "Pledge: Crypt of Hearts I",
                ["otherInfo"] = 
                {
                    ["time"] = 1536110391,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.4946204126,
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1557199657,
                ["name"] = "Pledge: Darkshade Caverns I",
                ["otherInfo"] = 
                {
                    ["time"] = 1536110402,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["y"] = 0.5108312964,
                ["giver"] = "Urgarlag Chief-bane",
                ["x"] = 0.1639984995,
                ["name"] = "Pledge: White-Gold Tower",
                ["otherInfo"] = 
                {
                    ["time"] = 1536470819,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["y"] = 0.4965241849,
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1599890441,
                ["name"] = "Pledge: Fungal Grotto I",
                ["otherInfo"] = 
                {
                    ["time"] = 1537996570,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["grahtwood/eldenrootcrafting_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.8027322292,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["name"] = "Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167461,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.8027322292,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["name"] = "Blacksmith Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167461,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.8027322292,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["name"] = "Woodworker Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167462,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.8027322292,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["name"] = "Jewelry Crafting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167462,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.4062841535,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.7377595901,
                ["name"] = "Provisioner Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.4062841535,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.7377595901,
                ["name"] = "Enchanter Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.4062841535,
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.7377595901,
                ["name"] = "Alchemist Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1536167479,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["alikr/lostcity_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.5315229297,
                ["giver"] = "Letter to Tavo",
                ["x"] = 0.3969942033,
                ["name"] = "An Ill-Fated Venture",
                ["otherInfo"] = 
                {
                    ["time"] = 1536444856,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["y"] = 0.9049382806,
                ["giver"] = "Paldeen",
                ["preQuest"] = 2364,
                ["x"] = 0.4905205965,
                ["name"] = "Secrets of the Lost City",
                ["otherInfo"] = 
                {
                    ["time"] = 1536443214,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["auridon/thebanishedcells_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.8494246006,
                ["giver"] = "Keeper Cirion",
                ["preQuest"] = 4841,
                ["x"] = 0.4782767594,
                ["name"] = "Banishing the Banished",
                ["otherInfo"] = 
                {
                    ["time"] = 1536197347,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/flyleafcatacombs_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.1988012046,
                ["giver"] = "Handre's Last Will",
                ["preQuest"] = 4942,
                ["x"] = 0.3211788237,
                ["name"] = "Fadeel's Freedom",
                ["otherInfo"] = 
                {
                    ["time"] = 1534832824,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["vvardenfell/balmora_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6759822965,
                ["giver"] = "Sergeant Faldrus",
                ["preQuest"] = 5862,
                ["x"] = 0.5449072719,
                ["name"] = "Fleeing the Past",
                ["otherInfo"] = 
                {
                    ["time"] = 1537387483,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.3449721038,
                ["giver"] = "Gilan Lerano",
                ["x"] = 0.4018615782,
                ["name"] = "The Memory Stone",
                ["otherInfo"] = 
                {
                    ["time"] = 1537410326,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.4479381442,
                ["giver"] = "Councilor Eris",
                ["preQuest"] = 5887,
                ["x"] = 0.2424459904,
                ["name"] = "Of Faith and Family",
                ["otherInfo"] = 
                {
                    ["time"] = 1537414217,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.4948019087,
                ["giver"] = "Ashur",
                ["preQuest"] = 5919,
                ["x"] = 0.2891708612,
                ["name"] = "A Purposeful Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1537472082,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.4762555361,
                ["giver"] = "Veya Releth",
                ["preQuest"] = 5933,
                ["x"] = 0.3086434007,
                ["name"] = "Family Reunion",
                ["otherInfo"] = 
                {
                    ["time"] = 1537483647,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["deshaan/deshaan_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5704402328,
                ["giver"] = "Risa's Journal",
                ["x"] = 0.6753426790,
                ["name"] = "Remembering Risa",
                ["otherInfo"] = 
                {
                    ["time"] = 1536986793,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3512257040,
                ["giver"] = "Merthyval Lort",
                ["x"] = 0.1734942794,
                ["name"] = "A Family Affair",
                ["otherInfo"] = 
                {
                    ["time"] = 1533765724,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.3290571570,
                ["giver"] = "William Nurin",
                ["preQuest"] = 2561,
                ["x"] = 0.1847085655,
                ["name"] = "Scamp Invasion",
                ["otherInfo"] = 
                {
                    ["time"] = 1533766855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.4067914188,
                ["giver"] = "Phinis Vanne",
                ["preQuest"] = 2578,
                ["x"] = 0.2047742903,
                ["name"] = "Can't Leave Without Her",
                ["otherInfo"] = 
                {
                    ["time"] = 1533767983,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.3682714403,
                ["giver"] = "Brother Perry",
                ["x"] = 0.2087714225,
                ["name"] = "The Slumbering Farmer",
                ["otherInfo"] = 
                {
                    ["time"] = 1533768092,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.3650457263,
                ["giver"] = "Ingride Vanne",
                ["preQuest"] = 1678,
                ["x"] = 0.2702714205,
                ["name"] = "Rozenn's Dream",
                ["otherInfo"] = 
                {
                    ["time"] = 1533776633,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.4724285603,
                ["giver"] = "Attack Plans",
                ["preQuest"] = 1709,
                ["x"] = 0.1770542860,
                ["name"] = "Lighthouse Attack Plans",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846079,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.5024399757,
                ["giver"] = "Tyree Marence",
                ["x"] = 0.1766742915,
                ["name"] = "Repair Koeglin Lighthouse",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846248,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.5064542890,
                ["giver"] = "Tyree Marence",
                ["x"] = 0.1754028499,
                ["name"] = "Repair Koeglin Lighthouse",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846986,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.4726114273,
                ["giver"] = "Attack Plans",
                ["x"] = 0.1770028621,
                ["name"] = "Lighthouse Attack Plans",
                ["otherInfo"] = 
                {
                    ["time"] = 1533847046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.5501142740,
                ["giver"] = "Captain Albert Marck",
                ["x"] = 0.1617742926,
                ["name"] = "Captive Crewmembers",
                ["otherInfo"] = 
                {
                    ["time"] = 1533851768,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.5126199722,
                ["giver"] = "First Mate Elvira Derre",
                ["preQuest"] = 728,
                ["x"] = 0.2323114276,
                ["name"] = "Divert and Deliver",
                ["otherInfo"] = 
                {
                    ["time"] = 1533853374,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.3264142871,
                ["giver"] = "Sir Graham",
                ["x"] = 0.2869457006,
                ["name"] = "False Knights",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943284,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.3274685740,
                ["giver"] = "Sir Graham",
                ["x"] = 0.2859799862,
                ["name"] = "False Knights",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943891,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.3046999872,
                ["giver"] = "Sir Edmund",
                ["x"] = 0.2963399887,
                ["name"] = "The Flame of Dissent",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943921,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.3039971292,
                ["giver"] = "Sir Edmund",
                ["preQuest"] = 736,
                ["x"] = 0.2970771492,
                ["name"] = "Retaking Firebrand Keep",
                ["otherInfo"] = 
                {
                    ["time"] = 1533944379,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.3003971577,
                ["giver"] = "Sir Edmund",
                ["preQuest"] = 737,
                ["x"] = 0.3258914351,
                ["name"] = "Army at the Gates",
                ["otherInfo"] = 
                {
                    ["time"] = 1533944995,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.2786599994,
                ["giver"] = "Weather-Beaten Trunk",
                ["x"] = 0.2456285655,
                ["name"] = "Legacy of the Three",
                ["otherInfo"] = 
                {
                    ["time"] = 1533956133,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["y"] = 0.3008942902,
                ["giver"] = "Sir Edmund",
                ["preQuest"] = 2576,
                ["x"] = 0.3260971308,
                ["name"] = "Sir Hughes' Fate",
                ["otherInfo"] = 
                {
                    ["time"] = 1534024196,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.2973114252,
                ["giver"] = "Duke Nathaniel",
                ["preQuest"] = 467,
                ["x"] = 0.3323028684,
                ["name"] = "Unanswered Questions",
                ["otherInfo"] = 
                {
                    ["time"] = 1534032366,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.4025200009,
                ["giver"] = "Brother Zacharie",
                ["preQuest"] = 1735,
                ["x"] = 0.4674942791,
                ["name"] = "Fire in the Fields",
                ["otherInfo"] = 
                {
                    ["time"] = 1534035243,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.4018571377,
                ["giver"] = "Brother Perry",
                ["x"] = 0.4949942827,
                ["name"] = "Dreams to Nightmares",
                ["otherInfo"] = 
                {
                    ["time"] = 1534040985,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["y"] = 0.3202342987,
                ["giver"] = "Master Muzgu",
                ["preQuest"] = 2046,
                ["x"] = 0.5474256873,
                ["name"] = "The Gate to Quagmire",
                ["otherInfo"] = 
                {
                    ["time"] = 1534041930,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["y"] = 0.3711885810,
                ["giver"] = "Sister Safia",
                ["preQuest"] = 1536,
                ["x"] = 0.4313657284,
                ["name"] = "Azura's Guardian",
                ["otherInfo"] = 
                {
                    ["time"] = 1534043081,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [24] = 
            {
                ["y"] = 0.3937314153,
                ["giver"] = "Master Altien",
                ["preQuest"] = 1529,
                ["x"] = 0.4481828511,
                ["name"] = "A Prison of Sleep",
                ["otherInfo"] = 
                {
                    ["time"] = 1534110562,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [25] = 
            {
                ["y"] = 0.3914342821,
                ["giver"] = "Falice Menoit",
                ["x"] = 0.4417657256,
                ["name"] = "Injured Spirit Wardens",
                ["otherInfo"] = 
                {
                    ["time"] = 1534110585,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [26] = 
            {
                ["y"] = 0.4171828628,
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 1541,
                ["x"] = 0.4508599937,
                ["name"] = "Pursuing the Shard",
                ["otherInfo"] = 
                {
                    ["time"] = 1534115232,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [27] = 
            {
                ["y"] = 0.5928171277,
                ["giver"] = "Arcady Charnis",
                ["preQuest"] = 1485,
                ["x"] = 0.4334171414,
                ["name"] = "The Sower Reaps",
                ["otherInfo"] = 
                {
                    ["time"] = 1534127785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [28] = 
            {
                ["y"] = 0.5902314186,
                ["giver"] = "Priestess Pietine",
                ["x"] = 0.4062657058,
                ["name"] = "Abominations from Beyond",
                ["otherInfo"] = 
                {
                    ["time"] = 1534128064,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [29] = 
            {
                ["y"] = 0.6093199849,
                ["giver"] = "Cursed Skull",
                ["x"] = 0.3788971305,
                ["name"] = "Curse of Skulls",
                ["otherInfo"] = 
                {
                    ["time"] = 1534128145,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [30] = 
            {
                ["y"] = 0.6113514304,
                ["giver"] = "Hosni at-Tura",
                ["preQuest"] = 499,
                ["x"] = 0.3172799945,
                ["name"] = "The Signet Ring",
                ["otherInfo"] = 
                {
                    ["time"] = 1534132043,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [31] = 
            {
                ["y"] = 0.5777771473,
                ["giver"] = "Lady Sirali at-Tura",
                ["preQuest"] = 2495,
                ["x"] = 0.2957200110,
                ["name"] = "Evidence Against Adima",
                ["otherInfo"] = 
                {
                    ["time"] = 1534132624,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [32] = 
            {
                ["y"] = 0.5778542757,
                ["giver"] = "Lady Sirali at-Tura",
                ["preQuest"] = 2496,
                ["x"] = 0.2950657010,
                ["name"] = "Saving Hosni",
                ["otherInfo"] = 
                {
                    ["time"] = 1534133322,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [33] = 
            {
                ["y"] = 0.6140800118,
                ["giver"] = "Hosni at-Tura",
                ["preQuest"] = 2497,
                ["x"] = 0.3099485636,
                ["name"] = "The Return of the Dream Shard",
                ["otherInfo"] = 
                {
                    ["time"] = 1534133785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [34] = 
            {
                ["y"] = 0.4175542891,
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 1633,
                ["x"] = 0.4502457082,
                ["name"] = "Another Omen",
                ["otherInfo"] = 
                {
                    ["time"] = 1534134224,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [35] = 
            {
                ["y"] = 0.4397457242,
                ["giver"] = "Watch Captain Rama",
                ["x"] = 0.5220771432,
                ["name"] = "Blood Revenge",
                ["otherInfo"] = 
                {
                    ["time"] = 1534134527,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [36] = 
            {
                ["y"] = 0.4184857011,
                ["giver"] = "Pierre Lanier",
                ["x"] = 0.5551342964,
                ["name"] = "Rat in a Trap",
                ["otherInfo"] = 
                {
                    ["time"] = 1534135047,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [37] = 
            {
                ["y"] = 0.4466885626,
                ["giver"] = "Watch Commander Kurt",
                ["preQuest"] = 1554,
                ["x"] = 0.5594199896,
                ["name"] = "A Means to an End",
                ["otherInfo"] = 
                {
                    ["time"] = 1534135245,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [38] = 
            {
                ["y"] = 0.4467457235,
                ["giver"] = "Watch Captain Ernard",
                ["preQuest"] = 1568,
                ["x"] = 0.5594199896,
                ["name"] = "Revenge Against Rama",
                ["otherInfo"] = 
                {
                    ["time"] = 1534136855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [39] = 
            {
                ["y"] = 0.5452857018,
                ["giver"] = "Dro-Dara",
                ["preQuest"] = 1384,
                ["x"] = 0.7167114019,
                ["name"] = "Plowshares to Swords",
                ["otherInfo"] = 
                {
                    ["time"] = 1534284908,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [40] = 
            {
                ["y"] = 0.4731028676,
                ["giver"] = "Sister Tabakah",
                ["x"] = 0.8102228642,
                ["name"] = "Azura's Relics",
                ["otherInfo"] = 
                {
                    ["time"] = 1534285563,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [41] = 
            {
                ["y"] = 0.5479228497,
                ["giver"] = "Knarstygg",
                ["preQuest"] = 2536,
                ["x"] = 0.7230571508,
                ["name"] = "A Predator's Heart",
                ["otherInfo"] = 
                {
                    ["time"] = 1534289013,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [42] = 
            {
                ["y"] = 0.4852257073,
                ["giver"] = "General Godrun",
                ["x"] = 0.7429599762,
                ["name"] = "General Godrun's Orders",
                ["otherInfo"] = 
                {
                    ["time"] = 1534292650,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [43] = 
            {
                ["y"] = 0.4715114236,
                ["giver"] = "Captain Dugakh",
                ["x"] = 0.7367143035,
                ["name"] = "Ogre Teeth",
                ["otherInfo"] = 
                {
                    ["time"] = 1534292860,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [44] = 
            {
                ["y"] = 0.4308257103,
                ["giver"] = "General Godrun",
                ["preQuest"] = 1437,
                ["x"] = 0.7524114251,
                ["name"] = "Ending the Ogre Threat",
                ["otherInfo"] = 
                {
                    ["time"] = 1534293441,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [45] = 
            {
                ["y"] = 0.4839485586,
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 1346,
                ["x"] = 0.7416971326,
                ["name"] = "Godrun's Dream",
                ["otherInfo"] = 
                {
                    ["time"] = 1534304400,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [46] = 
            {
                ["y"] = 0.4835257232,
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 3637,
                ["x"] = 0.7431628704,
                ["name"] = "Azura's Aid",
                ["otherInfo"] = 
                {
                    ["time"] = 1534304982,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [47] = 
            {
                ["y"] = 0.4296885729,
                ["giver"] = "Mathias Raiment",
                ["x"] = 0.6858485937,
                ["name"] = "A Look in the Mirror",
                ["otherInfo"] = 
                {
                    ["time"] = 1534365486,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [48] = 
            {
                ["y"] = 0.4326257110,
                ["giver"] = "Countess Ilise Manteau",
                ["preQuest"] = 614,
                ["x"] = 0.6523114443,
                ["name"] = "Gift from a Suitor",
                ["otherInfo"] = 
                {
                    ["time"] = 1534365750,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [49] = 
            {
                ["y"] = 0.4065999985,
                ["giver"] = "Michel Helomaine",
                ["x"] = 0.6221686006,
                ["name"] = "The Perfect Burial",
                ["otherInfo"] = 
                {
                    ["time"] = 1534368712,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [50] = 
            {
                ["y"] = 0.5167885423,
                ["giver"] = "Blaise Pamarc",
                ["preQuest"] = 2538,
                ["x"] = 0.6690571308,
                ["name"] = "King Aphren's Sword",
                ["otherInfo"] = 
                {
                    ["time"] = 1534370713,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [51] = 
            {
                ["y"] = 0.6117914319,
                ["giver"] = "Serge Arcole",
                ["x"] = 0.4425742924,
                ["name"] = "A Ransom for Miranda",
                ["otherInfo"] = 
                {
                    ["time"] = 1534395263,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [52] = 
            {
                ["y"] = 0.6594685912,
                ["giver"] = "Serge Arcole",
                ["preQuest"] = 2451,
                ["x"] = 0.4409771562,
                ["name"] = "A Woman Wronged",
                ["otherInfo"] = 
                {
                    ["time"] = 1534396158,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
    },
    ["questInfo"] = 
    {
        [6144] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2561] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6146] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2564] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6149] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6150] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6151] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6152] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2569] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [523] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6157] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4622] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6159] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2576] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2578] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2068] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6165] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6166] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4631] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6170] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6172] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 10,
                [3] = 1,
            },
        },
        [6174] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6176] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6177] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6179] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6180] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6181] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6185] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6190] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4656] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4145] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [6194] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5171] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6196] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3637] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6198] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [1591] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [575] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4672] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6218] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [4686] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1615] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2130] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6227] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6228] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1633] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2146] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3172] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1637] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [614] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1639] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4202] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2161] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3187] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3190] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3192] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4731] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5247] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5249] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [2184] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5259] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1678] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4751] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2192] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [657] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4754] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4246] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [1687] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4760] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4761] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5274] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4767] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5283] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5799] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5803] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1709] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2222] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5303] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5309] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5312] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1735] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3784] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2251] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5836] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2255] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5840] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5841] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3285] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3286] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [728] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5342] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [736] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [737] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4834] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5859] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3302] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3303] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4840] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3305] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4843] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4844] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4335] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4336] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3314] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5876] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5877] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5368] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4857] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4858] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5883] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5885] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5374] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5887] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5888] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5377] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3333] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4980] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6143] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 9,
                [3] = 10,
            },
        },
        [2558] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3337] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5893] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6140] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5388] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5389] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5902] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3343] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5392] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5905] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5394] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5395] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4884] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5872] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5901] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6137] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4888] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3353] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5914] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4379] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4088] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6135] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5406] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5407] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5920] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5409] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5922] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
        },
        [5923] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5412] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4901] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4902] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4903] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5416] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5417] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5418] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5863] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4659] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5933] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6160] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3059] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6162] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4401] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5900] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3379] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4916] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3381] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5903] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3383] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4920] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3385] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1339] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4923] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2364] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1341] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5950] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4927] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5952] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
        },
        [4929] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4930] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4931] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6126] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
        },
        [5948] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 7,
                [4] = 9,
                [5] = 1,
            },
        },
        [4934] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5886] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4936] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4937] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5880] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3050] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3916] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6121] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3918] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4926] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4944] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4945] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5857] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4435] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3412] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4949] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3414] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4952] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3416] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5881] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5864] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4443] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6199] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 7,
            },
        },
        [5981] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [4958] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5983] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [5832] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4961] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 10,
            },
        },
        [5919] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2403] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2404] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4965] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6195] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1383] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1384] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6111] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3296] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4971] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4972] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3367] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3438] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6197] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3440] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3953] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3783] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6003] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 7,
                [4] = 9,
                [5] = 1,
            },
        },
        [6004] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4839] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6008] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6007] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4472] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4473] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2356] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4054] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3964] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3029] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3344] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6099] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2567] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [465] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3970] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1346] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2436] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4841] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6022] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [4721] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2193] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5413] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [2566] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5400] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5415] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [2046] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4403] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1568] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4942] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5396] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2450] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2451] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5012] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6153] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5014] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4565] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5018] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3993] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3482] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1437] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5020] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3997] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5022] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5973] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [5024] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2408] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5538] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 10,
            },
        },
        [5027] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4516] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [521] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6145] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4519] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5051] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3436] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5976] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [6059] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6060] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6061] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5021] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5954] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
        },
        [2481] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4529] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3509] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4531] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4533] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2997] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2998] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4535] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1554] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3001] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4822] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3003] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3004] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1536] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2494] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2495] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2496] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2497] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4928] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3011] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6084] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6136] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6086] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6087] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2504] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3017] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1541] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3019] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3020] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1485] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5972] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [3023] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6096] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6097] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2344] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [467] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [6100] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6101] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6102] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6103] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4107] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4638] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2187] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3035] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5431] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6109] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2240] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3039] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6112] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6113] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
        },
        [6114] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6115] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6116] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6117] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6118] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6119] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2536] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2537] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2538] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6131] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5862] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6125] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3566] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6127] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4080] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6129] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6130] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [499] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6132] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2549] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2550] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1527] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2552] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1529] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6138] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6139] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2556] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6141] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6142] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2047] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
    },
    ["startTime"] = 1533505942,
    ["subZones"] = 
    {
        ["summerset/summerset_base"] = 
        {
            ["summerset/eldbursanctuary02_base"] = 
            {
                ["y"] = 0.5544005036,
                ["x"] = 0.3709714115,
            },
            ["summerset/ebonstadmont03_base"] = 
            {
                ["y"] = 0.3874606490,
                ["x"] = 0.3468613625,
            },
            ["summerset/sum_karnwasten"] = 
            {
                ["y"] = 0.3010985851,
                ["x"] = 0.2091100663,
            },
            ["summerset/karndar_03"] = 
            {
                ["y"] = 0.6266152859,
                ["x"] = 0.3199555576,
            },
            ["summerset/traitorsvault01_base"] = 
            {
                ["y"] = 0.6670005918,
                ["x"] = 0.5844435692,
            },
            ["summerset/artaeum_base"] = 
            {
                ["y"] = 0.4480006099,
                ["x"] = 0.4623057544,
            },
            ["summerset/sq4sapiarch02_base"] = 
            {
                ["y"] = 0.1052494198,
                ["x"] = 0.3934149444,
            },
            ["summerset/corgradwastehigher2_base"] = 
            {
                ["y"] = 0.2448797524,
                ["x"] = 0.2811351120,
            },
            ["summerset/lillandrilcave_base"] = 
            {
                ["y"] = 0.1849195659,
                ["x"] = 0.4480309784,
            },
            ["summerset/lillandrill_base"] = 
            {
                ["y"] = 0.5346389413,
                ["x"] = 0.2625741065,
            },
            ["summerset/alinor_base"] = 
            {
                ["y"] = 0.6258260608,
                ["x"] = 0.6571653485,
            },
            ["summerset/russafeldredtemple02_base"] = 
            {
                ["y"] = 0.4386571348,
                ["x"] = 0.4036326706,
            },
            ["summerset/torhamekhard_01"] = 
            {
                ["y"] = 0.4963967800,
                ["x"] = 0.5443542600,
            },
            ["summerset/ceytarncaveext01_base"] = 
            {
                ["y"] = 0.3494780362,
                ["x"] = 0.5518673062,
            },
            ["summerset/wastencoraldale_base"] = 
            {
                ["y"] = 0.2665567696,
                ["x"] = 0.5220731497,
            },
            ["summerset/archonsgrove_base"] = 
            {
                ["y"] = 0.5790919065,
                ["x"] = 0.5836012363,
            },
            ["summerset/seakeep_03"] = 
            {
                ["y"] = 0.2106248140,
                ["x"] = 0.4341204464,
            },
            ["summerset/mindtrap_base"] = 
            {
                ["y"] = 0.5749726295,
                ["x"] = 0.5049934983,
            },
            ["summerset/russafeldredtemple01_base"] = 
            {
                ["y"] = 0.4995644093,
                ["x"] = 0.4843394756,
            },
            ["summerset/ceytarncaveint03_base"] = 
            {
                ["y"] = 0.3513980210,
                ["x"] = 0.5509521365,
            },
            ["summerset/ui_map"] = 
            {
                ["y"] = 0.4230011404,
                ["x"] = 0.3561471999,
            },
            ["summerset/sinkhole_base"] = 
            {
                ["y"] = 0.4365155399,
                ["x"] = 0.4278960228,
            },
            ["summerset/illuminationacademy_01"] = 
            {
                ["y"] = 0.3171582818,
                ["x"] = 0.3232491612,
            },
            ["summerset/etonnir_01"] = 
            {
                ["y"] = 0.5096121430,
                ["x"] = 0.3271756768,
            },
            ["summerset/kingshavenext_base"] = 
            {
                ["y"] = 0.4893906713,
                ["x"] = 0.2751277089,
            },
            ["summerset/sq7courtofbedlamruins_base"] = 
            {
                ["y"] = 0.2188724726,
                ["x"] = 0.3114149868,
            },
            ["summerset/sunhold_base"] = 
            {
                ["y"] = 0.3487282395,
                ["x"] = 0.3633111417,
            },
            ["summerset/collegeofpsijicsruins_btm"] = 
            {
                ["y"] = 0.4480006099,
                ["x"] = 0.4623057544,
            },
        },
        ["vvardenfell/vvardenfell_base"] = 
        {
            ["vvardenfell/firemothisland_base"] = 
            {
                ["y"] = 0.4202829599,
                ["x"] = 0.8348253369,
            },
            ["vvardenfell/nchuleftingth7_base"] = 
            {
                ["y"] = 0.6730310321,
                ["x"] = 0.6729398966,
            },
            ["vvardenfell/cavernoftheincarnate_base"] = 
            {
                ["y"] = 0.5858443379,
                ["x"] = 0.2982215881,
            },
            ["vvardenfell/pinsun_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/nchuleftdepths_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/prisonofxykenaz_base"] = 
            {
                ["y"] = 0.7320503592,
                ["x"] = 0.2845602036,
            },
            ["vvardenfell/forgottenwastesext_base"] = 
            {
                ["y"] = 0.5191664100,
                ["x"] = 0.2571662962,
            },
            ["vvardenfell/pulklower_base"] = 
            {
                ["y"] = 0.6740599871,
                ["x"] = 0.3130408823,
            },
            ["vvardenfell/odirniran_base"] = 
            {
                ["y"] = 0.8294625878,
                ["x"] = 0.7728256583,
            },
            ["vvardenfell/gnisiseggmine_base"] = 
            {
                ["y"] = 0.2259497643,
                ["x"] = 0.3351431489,
            },
            ["vvardenfell/ashalmawia_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/ashimanu01_base"] = 
            {
                ["y"] = 0.3646239340,
                ["x"] = 0.4824426472,
            },
            ["vvardenfell/inanius_base"] = 
            {
                ["y"] = 0.6141583323,
                ["x"] = 0.7456139922,
            },
            ["vvardenfell/tusenend_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/nchuleftingth6_base"] = 
            {
                ["y"] = 0.3991185725,
                ["x"] = 0.8018486500,
            },
            ["vvardenfell/ashurnibibi_base"] = 
            {
                ["y"] = 0.2803797722,
                ["x"] = 0.6915417910,
            },
            ["vvardenfell/matusakin_base"] = 
            {
                ["y"] = 0.7982082367,
                ["x"] = 0.6896594167,
            },
            ["vvardenfell/zalkinsul01_base"] = 
            {
                ["y"] = 0.6608186364,
                ["x"] = 0.5960587263,
            },
            ["vvardenfell/nchuleft_base"] = 
            {
                ["y"] = 0.6121292114,
                ["x"] = 0.3294314444,
            },
            ["vvardenfell/kudanat_base"] = 
            {
                ["y"] = 0.3892686665,
                ["x"] = 0.6807340384,
            },
            ["vvardenfell/ramimilk_base"] = 
            {
                ["y"] = 0.4155180454,
                ["x"] = 0.5086320043,
            },
            ["vvardenfell/molagmarglassmine_base"] = 
            {
                ["y"] = 0.7141730189,
                ["x"] = 0.7482542396,
            },
            ["vvardenfell/vivechow01a_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/zaintiraris_base"] = 
            {
                ["y"] = 0.7254741788,
                ["x"] = 0.8212261796,
            },
            ["vvardenfell/viviccity_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/shulk_base"] = 
            {
                ["y"] = 0.3416326940,
                ["x"] = 0.6750468016,
            },
            ["vvardenfell/kaushtarari02_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/andrano_base"] = 
            {
                ["y"] = 0.4316285551,
                ["x"] = 0.7930721641,
            },
            ["vvardenfell/balur_base"] = 
            {
                ["y"] = 0.6600874662,
                ["x"] = 0.6206278801,
            },
            ["vvardenfell/hlaren_base"] = 
            {
                ["y"] = 0.3646239340,
                ["x"] = 0.4824426472,
            },
            ["vvardenfell/arkngthunch_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/nchuleftingth1_base"] = 
            {
                ["y"] = 0.6729421020,
                ["x"] = 0.6591807008,
            },
            ["vvardenfell/sadrithmora_base"] = 
            {
                ["y"] = 0.1882548034,
                ["x"] = 0.3869528770,
            },
            ["vvardenfell/mallapi_base"] = 
            {
                ["y"] = 0.3272490203,
                ["x"] = 0.5194997787,
            },
            ["vvardenfell/ashalmawia02_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/vassamsigrotto_base"] = 
            {
                ["y"] = 0.7821643949,
                ["x"] = 0.4418340623,
            },
            ["vvardenfell/khartagpoint_base"] = 
            {
                ["y"] = 0.2454762012,
                ["x"] = 0.4993799329,
            },
            ["vvardenfell/zainsipilu_base"] = 
            {
                ["y"] = 0.3583010733,
                ["x"] = 0.7515901923,
            },
            ["vvardenfell/galomdaeus_base"] = 
            {
                ["y"] = 0.4753374755,
                ["x"] = 0.8583722115,
            },
            ["vvardenfell/libraryofandule02_base"] = 
            {
                ["y"] = 0.2611378133,
                ["x"] = 0.2578419149,
            },
            ["vvardenfell/balmora_base"] = 
            {
                ["y"] = 0.3892686665,
                ["x"] = 0.6807340384,
            },
            ["vvardenfell/vassirdidanat01_base"] = 
            {
                ["y"] = 0.3831925094,
                ["x"] = 0.7204691768,
            },
            ["vvardenfell/skar_base"] = 
            {
                ["y"] = 0.3969361186,
                ["x"] = 0.4552309811,
            },
        },
        ["grahtwood/grahtwood_base"] = 
        {
            ["grahtwood/eldenrootservices_base"] = 
            {
                ["y"] = 0.6190371513,
                ["x"] = 0.3965311348,
            },
        },
        ["clockwork/clockwork_base"] = 
        {
            ["clockwork/brassfortress_base"] = 
            {
                ["y"] = 0.4953917861,
                ["x"] = 0.4424764514,
            },
            ["clockwork/ccq1_map3"] = 
            {
                ["y"] = 0.7180359364,
                ["x"] = 0.7557187080,
            },
        },
        ["greenshade/greenshade_base"] = 
        {
            ["greenshade/marbruk_base"] = 
            {
                ["y"] = 0.5915572643,
                ["x"] = 0.4128727615,
            },
        },
        ["alikr/alikr_base"] = 
        {
            ["alikr/sandblownmine_base"] = 
            {
                ["y"] = 0.8309459686,
                ["x"] = 0.5083644390,
            },
            ["alikr/salasen_base"] = 
            {
                ["y"] = 0.2205028683,
                ["x"] = 0.6820662022,
            },
            ["alikr/kulatimines-a_base"] = 
            {
                ["y"] = 0.4977097213,
                ["x"] = 0.5081379414,
            },
            ["alikr/yldzuun_base"] = 
            {
                ["y"] = 0.8309459686,
                ["x"] = 0.5083644390,
            },
            ["alikr/lostcity_base"] = 
            {
                ["y"] = 0.6729325652,
                ["x"] = 0.2899029255,
            },
            ["alikr/yokudanpalace02_base"] = 
            {
                ["y"] = 0.2947149575,
                ["x"] = 0.6587777138,
            },
            ["alikr/aldunz_base"] = 
            {
                ["y"] = 0.6404904127,
                ["x"] = 0.6422330141,
            },
            ["alikr/divadschagrinmine_base"] = 
            {
                ["y"] = 0.2483669370,
                ["x"] = 0.4622105956,
            },
            ["alikr/suturahs_crypt"] = 
            {
                ["y"] = 0.7747572660,
                ["x"] = 0.2986557186,
            },
            ["alikr/sentinel_base"] = 
            {
                ["y"] = 0.5104555488,
                ["x"] = 0.3627234399,
            },
            ["alikr/coldrockdiggings_base"] = 
            {
                ["y"] = 0.7188598514,
                ["x"] = 0.5001991391,
            },
            ["alikr/volenfell_base"] = 
            {
                ["y"] = 0.8726661801,
                ["x"] = 0.4628429115,
            },
        },
        ["bangkorai/bangkorai_base"] = 
        {
            ["bangkorai/evermore_base"] = 
            {
                ["y"] = 0.4622465670,
                ["x"] = 0.5381813645,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            ["stormhaven/godrunsdream_base"] = 
            {
                ["y"] = 0.7412771583,
                ["x"] = 0.4834085703,
            },
            ["stormhaven/norvulkruins_base"] = 
            {
                ["y"] = 0.6055743098,
                ["x"] = 0.3670828640,
            },
            ["stormhaven/wayrest_base"] = 
            {
                ["y"] = 0.3844971359,
                ["x"] = 0.6020143032,
            },
            ["stormhaven/bonesnapruinssecret_base"] = 
            {
                ["y"] = 0.3175171316,
                ["x"] = 0.4975742996,
            },
            ["stormhaven/portdunwatch_base"] = 
            {
                ["y"] = 0.3078914285,
                ["x"] = 0.3236285746,
            },
            ["stormhaven/pariahcatacombs_base"] = 
            {
                ["y"] = 0.4577028453,
                ["x"] = 0.4301457107,
            },
            ["stormhaven/bearclawmine_base"] = 
            {
                ["y"] = 0.7857285738,
                ["x"] = 0.4329885840,
            },
            ["stormhaven/windridgecave_base"] = 
            {
                ["y"] = 0.2868742943,
                ["x"] = 0.2765971422,
            },
            ["stormhaven/alcairecastle_base"] = 
            {
                ["y"] = 0.3298285604,
                ["x"] = 0.2951657176,
            },
            ["stormhaven/aphrenshold_base"] = 
            {
                ["y"] = 0.6410685778,
                ["x"] = 0.4917228520,
            },
        },
        ["stonefalls/stonefalls_base"] = 
        {
            ["stonefalls/davonswatch_base"] = 
            {
                ["y"] = 0.5806365609,
                ["x"] = 0.4937464893,
            },
        },
        ["auridon/auridon_base"] = 
        {
            ["auridon/khenarthisroost_base"] = 
            {
                ["y"] = 0.3501114547,
                ["x"] = 0.2228444815,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            ["glenumbra/ilessantower_base"] = 
            {
                ["y"] = 0.3480412066,
                ["x"] = 0.7259832025,
            },
            ["glenumbra/eboncrypt_base"] = 
            {
                ["y"] = 0.4798353016,
                ["x"] = 0.3692837954,
            },
            ["glenumbra/tomboflostkings_base"] = 
            {
                ["y"] = 0.7805057764,
                ["x"] = 0.2866012454,
            },
            ["glenumbra/silumm_base"] = 
            {
                ["y"] = 0.2721574605,
                ["x"] = 0.6779845357,
            },
            ["glenumbra/daggerfall_base"] = 
            {
                ["y"] = 0.3731749952,
                ["x"] = 0.7309818864,
            },
            ["glenumbra/spindleclutch_base"] = 
            {
                ["y"] = 0.7143661976,
                ["x"] = 0.3366774917,
            },
            ["glenumbra/cryptwatchfort_base"] = 
            {
                ["y"] = 0.6058680415,
                ["x"] = 0.2532835305,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            ["rivenspire/flyleafcatacombs_base"] = 
            {
                ["y"] = 0.1450490803,
                ["x"] = 0.5922636986,
            },
            ["rivenspire/shadowfatecavern_base"] = 
            {
                ["y"] = 0.2099232525,
                ["x"] = 0.7164837718,
            },
            ["rivenspire/northpoint_base"] = 
            {
                ["y"] = 0.6977521181,
                ["x"] = 0.4192044437,
            },
            ["rivenspire/obsidianscar_base"] = 
            {
                ["y"] = 0.6977521181,
                ["x"] = 0.4192044437,
            },
            ["rivenspire/orcsfingerruins_base"] = 
            {
                ["y"] = 0.8094767928,
                ["x"] = 0.3507380486,
            },
            ["rivenspire/doomcragshroudedpass_base"] = 
            {
                ["y"] = 0.2928013802,
                ["x"] = 0.4524268210,
            },
            ["rivenspire/edraldundercroftdomed_base"] = 
            {
                ["y"] = 0.7009591460,
                ["x"] = 0.5017006397,
            },
            ["rivenspire/tribulationcrypt_base"] = 
            {
                ["y"] = 0.6716846228,
                ["x"] = 0.6021974683,
            },
            ["rivenspire/shroudedpass2_base"] = 
            {
                ["y"] = 0.4067715704,
                ["x"] = 0.4239128530,
            },
            ["rivenspire/hildunessecretrefuge_base"] = 
            {
                ["y"] = 0.7363085151,
                ["x"] = 0.1964630783,
            },
            ["rivenspire/doomcragtop_base"] = 
            {
                ["y"] = 0.3183684349,
                ["x"] = 0.3759659529,
            },
            ["rivenspire/breaghafinupper_base"] = 
            {
                ["y"] = 0.6513264179,
                ["x"] = 0.2418812662,
            },
            ["rivenspire/erokii_base"] = 
            {
                ["y"] = 0.4000349045,
                ["x"] = 0.3114539683,
            },
            ["rivenspire/rivenspireoutlaw_base"] = 
            {
                ["y"] = 0.4735883772,
                ["x"] = 0.5317950249,
            },
            ["rivenspire/lorkrataruinsa_base"] = 
            {
                ["y"] = 0.5993559957,
                ["x"] = 0.4828965664,
            },
        },
    },
}
