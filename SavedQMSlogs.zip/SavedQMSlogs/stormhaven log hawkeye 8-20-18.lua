  ["stormhaven/stormhaven_base"] = 
        {
            ["stormhaven/aphrenshold_base"] = 
            {
                ["x"] = 0.4917228520,
                ["y"] = 0.6410685778,
            },
            ["stormhaven/godrunsdream_base"] = 
            {
                ["x"] = 0.4834085703,
                ["y"] = 0.7412771583,
            },
            ["stormhaven/pariahcatacombs_base"] = 
            {
                ["x"] = 0.4301457107,
                ["y"] = 0.4577028453,
            },
            ["stormhaven/bearclawmine_base"] = 
            {
                ["x"] = 0.4329885840,
                ["y"] = 0.7857285738,
            },
            ["stormhaven/alcairecastle_base"] = 
            {
                ["x"] = 0.2951657176,
                ["y"] = 0.3298285604,
            },
            ["stormhaven/wayrest_base"] = 
            {
                ["x"] = 0.6020143032,
                ["y"] = 0.3844971359,
            },
            ["stormhaven/norvulkruins_base"] = 
            {
                ["x"] = 0.3670828640,
                ["y"] = 0.6055743098,
            },
            ["stormhaven/windridgecave_base"] = 
            {
                ["x"] = 0.2765971422,
                ["y"] = 0.2868742943,
            },
            ["stormhaven/portdunwatch_base"] = 
            {
                ["x"] = 0.3236285746,
                ["y"] = 0.3078914285,
            },
            ["stormhaven/bonesnapruinssecret_base"] = 
            {
                ["x"] = 0.4975742996,
                ["y"] = 0.3175171316,
            },
        },
		  ["stormhaven/farangelsdelve_base"] = 
        {
            [1] = 
            {
                ["name"] = "Stolen Ashes",
                ["y"] = 0.4242919385,
                ["x"] = 0.4327341914,
                ["preQuest"] = 2550,
                ["giver"] = "Tomb Urn",
                ["otherInfo"] = 
                {
                    ["time"] = 1534129561,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/koeglinvillage_base"] = 
        {
            [1] = 
            {
                ["name"] = "False Accusations",
                ["y"] = 0.3335759938,
                ["x"] = 0.3885127902,
                ["preQuest"] = 3412,
                ["giver"] = "Dame Dabienne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533765631,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "The Slavers",
                ["y"] = 0.5187935233,
                ["x"] = 0.6060275435,
                ["preQuest"] = 2494,
                ["giver"] = "Margot Oscent",
                ["otherInfo"] = 
                {
                    ["time"] = 1533769172,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "To Alcaire Castle",
                ["y"] = 0.3445196748,
                ["x"] = 0.3553662896,
                ["preQuest"] = 2556,
                ["giver"] = "Dame Dabienne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533775980,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
		
		 ["stormhaven/alcairecastle_base"] = 
        {
            [4] = 
            {
                ["name"] = "Tracking Sir Hughes",
                ["y"] = 0.4368499517,
                ["x"] = 0.4016301334,
                ["preQuest"] = 2567,
                ["giver"] = "Duke Nathaniel",
                ["otherInfo"] = 
                {
                    ["time"] = 1533955857,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Two Sides to Every Coin",
                ["y"] = 0.3651475012,
                ["x"] = 0.4701412022,
                ["preQuest"] = 2552,
                ["giver"] = "Sir Hughes",
                ["otherInfo"] = 
                {
                    ["time"] = 1533950269,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "Life of the Duchess",
                ["y"] = 0.4338193238,
                ["x"] = 0.4061531425,
                ["preQuest"] = 2564,
                ["giver"] = "Duchess Lakana",
                ["otherInfo"] = 
                {
                    ["time"] = 1533951481,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "The Safety of the Kingdom",
                ["y"] = 0.5228102207,
                ["x"] = 0.3367925584,
                ["preQuest"] = 2566,
                ["giver"] = "Sir Hughes",
                ["otherInfo"] = 
                {
                    ["time"] = 1533955422,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
		["stormhaven/bonesnapruinssecret_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.6375247836,
                ["x"] = 0.6059898734,
                ["name"] = "Lost Lions",
                ["giver"] = "Sir Edgard",
                ["otherInfo"] = 
                {
                    ["time"] = 1533871296,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Repairing the Cage",
                ["y"] = 0.8454304934,
                ["x"] = 0.6948909760,
                ["preQuest"] = 1637,
                ["giver"] = "Battlemage Gaston",
                ["otherInfo"] = 
                {
                    ["time"] = 1533868567,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/wayrest_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.1780604571,
                ["x"] = 0.4391658008,
                ["name"] = "The Debt Collector's Debts",
                ["giver"] = "M'jaddha",
                ["otherInfo"] = 
                {
                    ["time"] = 1534116513,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.1300478876,
                ["x"] = 0.2756144106,
                ["name"] = "The Dreugh Threat",
                ["giver"] = "Sergeant Stegine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534125955,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "They Dragged Him Away",
                ["y"] = 0.0535364039,
                ["x"] = 0.2342794538,
                ["preQuest"] = 2068,
                ["giver"] = "Adiel Charnis",
                ["otherInfo"] = 
                {
                    ["time"] = 1534127126,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
			   ["y"] = 0.2736096680,
                ["x"] = 1.0325227976,
                ["name"] = "Old Adventurers",
                ["giver"] = "Janne Marolles",
                ["otherInfo"] = 
                {
                    ["time"] = 1534283292,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["name"] = "To The Clockwork City",
                ["y"] = 0.3309824765,
                ["x"] = 0.6182646751,
                ["preQuest"] = 1615,
                ["giver"] = "Eldrasea Deras",
                ["otherInfo"] = 
                {
                    ["time"] = 1534367222,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["name"] = "Vaermina's Gambit",
                ["y"] = 0.4614630342,
                ["x"] = 0.4303103685,
                ["preQuest"] = 521,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534373250,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["name"] = "The Road to Rivenspire",
                ["y"] = 0.4613187909,
                ["x"] = 0.3795575202,
                ["preQuest"] = 575,
                ["giver"] = "High King Emeric",
                ["otherInfo"] = 
                {
                    ["time"] = 1534374724,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5017451048,
                ["x"] = 0.1636523604,
                ["name"] = "Pledge: Moon Hunter Keep",
                ["giver"] = "Urgarlag Chief-bane",
                ["otherInfo"] = 
                {
                    ["time"] = 1534387635,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/hoarfrost_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5418079495,
                ["x"] = 0.4679913223,
                ["name"] = "The Wayward Son",
                ["giver"] = "Captain Thayer",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631769,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "The Bandit",
                ["y"] = 0.5901261568,
                ["x"] = 0.3932930827,
                ["preQuest"] = 5020,
                ["giver"] = "Captain Thayer",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "The Lover",
                ["y"] = 0.5798182487,
                ["x"] = 0.4004475772,
                ["preQuest"] = 5022,
                ["giver"] = "Captain Thayer",
                ["otherInfo"] = 
                {
                    ["time"] = 1534650828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
		        ["stormhaven/portdunwatch_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3056835532,
                ["x"] = 0.4718382061,
                ["name"] = "Do as I Say",
                ["giver"] = "Remy Berard",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943190,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/bearclawmine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4829317331,
                ["x"] = 0.3204819262,
                ["name"] = "Next of Kin",
                ["giver"] = "Hubert",
                ["otherInfo"] = 
                {
                    ["time"] = 1534364051,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
         ["stormhaven/stormhaven_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3512257040,
                ["x"] = 0.1734942794,
                ["name"] = "A Family Affair",
                ["giver"] = "Merthyval Lort",
                ["otherInfo"] = 
                {
                    ["time"] = 1533765724,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "Scamp Invasion",
                ["y"] = 0.3290571570,
                ["x"] = 0.1847085655,
                ["preQuest"] = 2561,
                ["giver"] = "William Nurin",
                ["otherInfo"] = 
                {
                    ["time"] = 1533766855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "Can't Leave Without Her",
                ["y"] = 0.4067914188,
                ["x"] = 0.2047742903,
                ["preQuest"] = 2578,
                ["giver"] = "Phinis Vanne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533767983,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.3682714403,
                ["x"] = 0.2087714225,
                ["name"] = "The Slumbering Farmer",
                ["giver"] = "Brother Perry",
                ["otherInfo"] = 
                {
                    ["time"] = 1533768092,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["name"] = "Rozenn's Dream",
                ["y"] = 0.3650457263,
                ["x"] = 0.2702714205,
                ["preQuest"] = 1678,
                ["giver"] = "Ingride Vanne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533776633,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["name"] = "Lighthouse Attack Plans",
                ["y"] = 0.4724285603,
                ["x"] = 0.1770542860,
                ["preQuest"] = 1709,
                ["giver"] = "Attack Plans",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846079,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.5024399757,
                ["x"] = 0.1766742915,
                ["name"] = "Repair Koeglin Lighthouse",
                ["giver"] = "Tyree Marence",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846248,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.5064542890,
                ["x"] = 0.1754028499,
                ["name"] = "Repair Koeglin Lighthouse",
                ["giver"] = "Tyree Marence",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846986,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.4726114273,
                ["x"] = 0.1770028621,
                ["name"] = "Lighthouse Attack Plans",
                ["giver"] = "Attack Plans",
                ["otherInfo"] = 
                {
                    ["time"] = 1533847046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.5501142740,
                ["x"] = 0.1617742926,
                ["name"] = "Captive Crewmembers",
                ["giver"] = "Captain Albert Marck",
                ["otherInfo"] = 
                {
                    ["time"] = 1533851768,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["name"] = "Divert and Deliver",
                ["y"] = 0.5126199722,
                ["x"] = 0.2323114276,
                ["preQuest"] = 728,
                ["giver"] = "First Mate Elvira Derre",
                ["otherInfo"] = 
                {
                    ["time"] = 1533853374,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.3264142871,
                ["x"] = 0.2869457006,
                ["name"] = "False Knights",
                ["giver"] = "Sir Graham",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943284,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.3274685740,
                ["x"] = 0.2859799862,
                ["name"] = "False Knights",
                ["giver"] = "Sir Graham",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943891,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.3046999872,
                ["x"] = 0.2963399887,
                ["name"] = "The Flame of Dissent",
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943921,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["name"] = "Retaking Firebrand Keep",
                ["y"] = 0.3039971292,
                ["x"] = 0.2970771492,
                ["preQuest"] = 736,
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1533944379,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["name"] = "Army at the Gates",
                ["y"] = 0.3003971577,
                ["x"] = 0.3258914351,
                ["preQuest"] = 737,
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1533944995,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.2786599994,
                ["x"] = 0.2456285655,
                ["name"] = "Legacy of the Three",
                ["giver"] = "Weather-Beaten Trunk",
                ["otherInfo"] = 
                {
                    ["time"] = 1533956133,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["name"] = "Sir Hughes' Fate",
                ["y"] = 0.3008942902,
                ["x"] = 0.3260971308,
                ["preQuest"] = 2576,
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1534024196,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["name"] = "Unanswered Questions",
                ["y"] = 0.2973114252,
                ["x"] = 0.3323028684,
                ["preQuest"] = 467,
                ["giver"] = "Duke Nathaniel",
                ["otherInfo"] = 
                {
                    ["time"] = 1534032366,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["name"] = "Fire in the Fields",
                ["y"] = 0.4025200009,
                ["x"] = 0.4674942791,
                ["preQuest"] = 1735,
                ["giver"] = "Brother Zacharie",
                ["otherInfo"] = 
                {
                    ["time"] = 1534035243,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.4018571377,
                ["x"] = 0.4949942827,
                ["name"] = "Dreams to Nightmares",
                ["giver"] = "Brother Perry",
                ["otherInfo"] = 
                {
                    ["time"] = 1534040985,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["name"] = "The Gate to Quagmire",
                ["y"] = 0.3202342987,
                ["x"] = 0.5474256873,
                ["preQuest"] = 2046,
                ["giver"] = "Master Muzgu",
                ["otherInfo"] = 
                {
                    ["time"] = 1534041930,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["name"] = "Azura's Guardian",
                ["y"] = 0.3711885810,
                ["x"] = 0.4313657284,
                ["preQuest"] = 1536,
                ["giver"] = "Sister Safia",
                ["otherInfo"] = 
                {
                    ["time"] = 1534043081,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [24] = 
            {
                ["name"] = "A Prison of Sleep",
                ["y"] = 0.3937314153,
                ["x"] = 0.4481828511,
                ["preQuest"] = 1529,
                ["giver"] = "Master Altien",
                ["otherInfo"] = 
                {
                    ["time"] = 1534110562,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [25] = 
            {
                ["y"] = 0.3914342821,
                ["x"] = 0.4417657256,
                ["name"] = "Injured Spirit Wardens",
                ["giver"] = "Falice Menoit",
                ["otherInfo"] = 
                {
                    ["time"] = 1534110585,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [26] = 
            {
                ["name"] = "Pursuing the Shard",
                ["y"] = 0.4171828628,
                ["x"] = 0.4508599937,
                ["preQuest"] = 1541,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534115232,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [27] = 
            {
                ["name"] = "The Sower Reaps",
                ["y"] = 0.5928171277,
                ["x"] = 0.4334171414,
                ["preQuest"] = 1485,
                ["giver"] = "Arcady Charnis",
                ["otherInfo"] = 
                {
                    ["time"] = 1534127785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [28] = 
            {
                ["y"] = 0.5902314186,
                ["x"] = 0.4062657058,
                ["name"] = "Abominations from Beyond",
                ["giver"] = "Priestess Pietine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534128064,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [29] = 
            {
                ["y"] = 0.6093199849,
                ["x"] = 0.3788971305,
                ["name"] = "Curse of Skulls",
                ["giver"] = "Cursed Skull",
                ["otherInfo"] = 
                {
                    ["time"] = 1534128145,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [30] = 
            {
                ["name"] = "The Signet Ring",
                ["y"] = 0.6113514304,
                ["x"] = 0.3172799945,
                ["preQuest"] = 499,
                ["giver"] = "Hosni at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534132043,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [31] = 
            {
                ["name"] = "Evidence Against Adima",
                ["y"] = 0.5777771473,
                ["x"] = 0.2957200110,
                ["preQuest"] = 2495,
                ["giver"] = "Lady Sirali at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534132624,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [32] = 
            {
                ["name"] = "Saving Hosni",
                ["y"] = 0.5778542757,
                ["x"] = 0.2950657010,
                ["preQuest"] = 2496,
                ["giver"] = "Lady Sirali at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534133322,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [33] = 
            {
                ["name"] = "The Return of the Dream Shard",
                ["y"] = 0.6140800118,
                ["x"] = 0.3099485636,
                ["preQuest"] = 2497,
                ["giver"] = "Hosni at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534133785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [34] = 
            {
                ["name"] = "Another Omen",
                ["y"] = 0.4175542891,
                ["x"] = 0.4502457082,
                ["preQuest"] = 1633,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534134224,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [35] = 
            {
                ["y"] = 0.4397457242,
                ["x"] = 0.5220771432,
                ["name"] = "Blood Revenge",
                ["giver"] = "Watch Captain Rama",
                ["otherInfo"] = 
                {
                    ["time"] = 1534134527,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [36] = 
            {
                ["y"] = 0.4184857011,
                ["x"] = 0.5551342964,
                ["name"] = "Rat in a Trap",
                ["giver"] = "Pierre Lanier",
                ["otherInfo"] = 
                {
                    ["time"] = 1534135047,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [37] = 
            {
                ["name"] = "A Means to an End",
                ["y"] = 0.4466885626,
                ["x"] = 0.5594199896,
                ["preQuest"] = 1554,
                ["giver"] = "Watch Commander Kurt",
                ["otherInfo"] = 
                {
                    ["time"] = 1534135245,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [38] = 
            {
                ["name"] = "Revenge Against Rama",
                ["y"] = 0.4467457235,
                ["x"] = 0.5594199896,
                ["preQuest"] = 1568,
                ["giver"] = "Watch Captain Ernard",
                ["otherInfo"] = 
                {
                    ["time"] = 1534136855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [39] = 
            {
                ["name"] = "Plowshares to Swords",
                ["y"] = 0.5452857018,
                ["x"] = 0.7167114019,
                ["preQuest"] = 1384,
                ["giver"] = "Dro-Dara",
                ["otherInfo"] = 
                {
                    ["time"] = 1534284908,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [40] = 
            {
                ["y"] = 0.4731028676,
                ["x"] = 0.8102228642,
                ["name"] = "Azura's Relics",
                ["giver"] = "Sister Tabakah",
                ["otherInfo"] = 
                {
                    ["time"] = 1534285563,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [41] = 
            {
                ["name"] = "A Predator's Heart",
                ["y"] = 0.5479228497,
                ["x"] = 0.7230571508,
                ["preQuest"] = 2536,
                ["giver"] = "Knarstygg",
                ["otherInfo"] = 
                {
                    ["time"] = 1534289013,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [42] = 
            {
                ["y"] = 0.4852257073,
                ["x"] = 0.7429599762,
                ["name"] = "General Godrun's Orders",
                ["giver"] = "General Godrun",
                ["otherInfo"] = 
                {
                    ["time"] = 1534292650,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [43] = 
            {
                ["y"] = 0.4715114236,
                ["x"] = 0.7367143035,
                ["name"] = "Ogre Teeth",
                ["giver"] = "Captain Dugakh",
                ["otherInfo"] = 
                {
                    ["time"] = 1534292860,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [44] = 
            {
                ["name"] = "Ending the Ogre Threat",
                ["y"] = 0.4308257103,
                ["x"] = 0.7524114251,
                ["preQuest"] = 1437,
                ["giver"] = "General Godrun",
                ["otherInfo"] = 
                {
                    ["time"] = 1534293441,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [45] = 
            {
                ["name"] = "Godrun's Dream",
                ["y"] = 0.4839485586,
                ["x"] = 0.7416971326,
                ["preQuest"] = 1346,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534304400,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [46] = 
            {
                ["name"] = "Azura's Aid",
                ["y"] = 0.4835257232,
                ["x"] = 0.7431628704,
                ["preQuest"] = 3637,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534304982,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [47] = 
            {
                ["y"] = 0.4296885729,
                ["x"] = 0.6858485937,
                ["name"] = "A Look in the Mirror",
                ["giver"] = "Mathias Raiment",
                ["otherInfo"] = 
                {
                    ["time"] = 1534365486,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [48] = 
            {
                ["name"] = "Gift from a Suitor",
                ["y"] = 0.4326257110,
                ["x"] = 0.6523114443,
                ["preQuest"] = 614,
                ["giver"] = "Countess Ilise Manteau",
                ["otherInfo"] = 
                {
                    ["time"] = 1534365750,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [49] = 
            {
                ["y"] = 0.4065999985,
                ["x"] = 0.6221686006,
                ["name"] = "The Perfect Burial",
                ["giver"] = "Michel Helomaine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534368712,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [50] = 
            {
                ["name"] = "King Aphren's Sword",
                ["y"] = 0.5167885423,
                ["x"] = 0.6690571308,
                ["preQuest"] = 2538,
                ["giver"] = "Blaise Pamarc",
                ["otherInfo"] = 
                {
                    ["time"] = 1534370713,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [51] = 
            {
                ["y"] = 0.6117914319,
                ["x"] = 0.4425742924,
                ["name"] = "A Ransom for Miranda",
                ["giver"] = "Serge Arcole",
                ["otherInfo"] = 
                {
                    ["time"] = 1534395263,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [52] = 
            {
                ["name"] = "A Woman Wronged",
                ["y"] = 0.6594685912,
                ["x"] = 0.4409771562,
                ["preQuest"] = 2451,
                ["giver"] = "Serge Arcole",
                ["otherInfo"] = 
                {
                    ["time"] = 1534396158,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },