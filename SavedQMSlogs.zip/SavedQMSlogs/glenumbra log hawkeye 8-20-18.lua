["subZones"] = 
    {
        ["glenumbra/glenumbra_base"] = 
        {
            ["glenumbra/daggerfall_base"] = 
            {
                ["x"] = 0.7309818864,
                ["y"] = 0.3731749952,
            },
            ["glenumbra/cryptwatchfort_base"] = 
            {
                ["x"] = 0.2532835305,
                ["y"] = 0.6058680415,
            },
            ["glenumbra/silumm_base"] = 
            {
                ["x"] = 0.6779845357,
                ["y"] = 0.2721574605,
            },
            ["glenumbra/spindleclutch_base"] = 
            {
                ["x"] = 0.3366774917,
                ["y"] = 0.7143661976,
            },
            ["glenumbra/eboncrypt_base"] = 
            {
                ["x"] = 0.3692837954,
                ["y"] = 0.4798353016,
            },
            ["glenumbra/tomboflostkings_base"] = 
            {
                ["x"] = 0.2866012454,
                ["y"] = 0.7805057764,
            },
            ["glenumbra/ilessantower_base"] = 
            {
                ["x"] = 0.7259832025,
                ["y"] = 0.3480412066,
            },
        },
		
		 ["glenumbra/ilessantower_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7700323462,
                ["x"] = 0.5450952053,
                ["name"] = "Red Rook Resources",
                ["giver"] = "Red Rook Note",
                ["otherInfo"] = 
                {
                    ["time"] = 1533684860,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/minesofkhuras_base"] = 
        {
            [1] = 
            {
                ["name"] = "A Brush With Death",
                ["y"] = 0.7706518769,
                ["x"] = 0.3869094849,
                ["preQuest"] = 3440,
                ["giver"] = "Guifford Vinielle's Sketchbook",
                ["otherInfo"] = 
                {
                    ["time"] = 1533705261,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            [1] = 
            {
                ["name"] = "A Dangerous Dream",
                ["y"] = 0.2641271353,
                ["x"] = 0.6233919263,
                ["preQuest"] = 3379,
                ["giver"] = "Recruit Maelle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506571,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2552480102,
                ["x"] = 0.6356987953,
                ["name"] = "Legitimate Interests",
                ["giver"] = "Garmeg the Ironfinder",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506619,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.2836774588,
                ["x"] = 0.6614254117,
                ["name"] = "Vines and Villains",
                ["giver"] = "Provost Piper",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506677,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.2603922486,
                ["x"] = 0.6967237592,
                ["name"] = "Cursed Treasure",
                ["giver"] = "Sir Marley Oris",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506771,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["name"] = "Forgotten Ancestry",
                ["y"] = 0.2198418677,
                ["x"] = 0.7467461228,
                ["preQuest"] = 6227,
                ["giver"] = "Harald Winvale",
                ["otherInfo"] = 
                {
                    ["time"] = 1533526292,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["name"] = "The Jeweled Crown of Anton",
                ["y"] = 0.2978167236,
                ["x"] = 0.7838526368,
                ["preQuest"] = 3509,
                ["giver"] = "Stibbons",
                ["otherInfo"] = 
                {
                    ["time"] = 1533528128,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["name"] = "Servants of Ancient Kings",
                ["y"] = 0.1833901852,
                ["x"] = 0.7397236228,
                ["preQuest"] = 3050,
                ["giver"] = "King Donel Deleyn",
                ["otherInfo"] = 
                {
                    ["time"] = 1533594760,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.2773717642,
                ["x"] = 0.5530404449,
                ["name"] = "The Corpse Horde",
                ["giver"] = "Sir Malik Nasir",
                ["otherInfo"] = 
                {
                    ["time"] = 1533609896,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["name"] = "Farlivere's Gambit",
                ["y"] = 0.7047001719,
                ["x"] = 0.4874128997,
                ["preQuest"] = 3314,
                ["giver"] = "Daggerfall Patroller",
                ["otherInfo"] = 
                {
                    ["time"] = 1533616621,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["name"] = "Disorganized Crime",
                ["y"] = 0.6687227488,
                ["x"] = 0.5088144541,
                ["preQuest"] = 3001,
                ["giver"] = "Lord Arcady Noellaume",
                ["otherInfo"] = 
                {
                    ["time"] = 1533617294,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.6681137681,
                ["x"] = 0.5077500343,
                ["name"] = "Lady Eloise's Lockbox",
                ["giver"] = "Lady Eloise Noellaume",
                ["otherInfo"] = 
                {
                    ["time"] = 1533617404,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["name"] = "Wicked Trade",
                ["y"] = 0.4949662387,
                ["x"] = 0.5817878842,
                ["preQuest"] = 4335,
                ["giver"] = "Erwan Castille",
                ["otherInfo"] = 
                {
                    ["time"] = 1533670237,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["name"] = "Wyrd and Coven",
                ["y"] = 0.5040016770,
                ["x"] = 0.6777231693,
                ["preQuest"] = 3023,
                ["giver"] = "Guy LeBlanc",
                ["otherInfo"] = 
                {
                    ["time"] = 1533670926,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.4546503127,
                ["x"] = 0.6808248162,
                ["name"] = "Crocodile Bounty",
                ["giver"] = "Mercenary",
                ["otherInfo"] = 
                {
                    ["time"] = 1533671046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["name"] = "Legacy of Baelborne Rock",
                ["y"] = 0.7100141644,
                ["x"] = 0.3761095703,
                ["preQuest"] = 3017,
                ["giver"] = "Athel Baelborne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533679671,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["name"] = "The Dagger's Edge",
                ["y"] = 0.6140681505,
                ["x"] = 0.3377877176,
                ["preQuest"] = 3414,
                ["giver"] = "Lord Alain Diel",
                ["otherInfo"] = 
                {
                    ["time"] = 1533686910,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.4058459699,
                ["x"] = 0.4421305656,
                ["name"] = "The Ghosts of Westtry",
                ["giver"] = "Leon Milielle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533699922,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["name"] = "Memento Mori",
                ["y"] = 0.4247629941,
                ["x"] = 0.3977132440,
                ["preQuest"] = 3019,
                ["giver"] = "Leon Milielle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533701453,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["name"] = "Signals of Dominion",
                ["y"] = 0.3811810613,
                ["x"] = 0.3257557452,
                ["preQuest"] = 3020,
                ["giver"] = "Lieutenant Clarice",
                ["otherInfo"] = 
                {
                    ["time"] = 1533702206,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.3935525715,
                ["x"] = 0.3128614426,
                ["name"] = "Wayward Scouts",
                ["giver"] = "Scout's Orders",
                ["otherInfo"] = 
                {
                    ["time"] = 1533702234,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
		 ["glenumbra/badmansstart_base"] = 
        {
            [1] = 
            {
                ["name"] = "Season of Harvest",
                ["y"] = 0.6460055113,
                ["x"] = 0.4435261786,
                ["preQuest"] = 4767,
                ["giver"] = "Curator Nicholas",
                ["otherInfo"] = 
                {
                    ["time"] = 1533693555,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
		["glenumbra/aldcroft_base"] = 
        {
            [1] = 
            {
                ["name"] = "Pride of the Lion Guard",
                ["y"] = 0.3413914144,
                ["x"] = 0.5562694669,
                ["preQuest"] = 3004,
                ["giver"] = "Captain Vistra",
                ["otherInfo"] = 
                {
                    ["time"] = 1533669833,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
    },
	  ["glenumbra/cryptwatchfort_base"] = 
        {
            [1] = 
            {
                ["name"] = "Fortune in Failure",
                ["y"] = 0.3049505055,
                ["x"] = 0.3861386180,
                ["preQuest"] = 4080,
                ["giver"] = "Hastily Scribbled Note",
                ["otherInfo"] = 
                {
                    ["time"] = 1533695799,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/badmanscave_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5939509273,
                ["x"] = 0.6003810167,
                ["name"] = "Can't Take It With Them",
                ["giver"] = "Finvir",
                ["otherInfo"] = 
                {
                    ["time"] = 1533694067,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
		 ["glenumbra/daggerfall_base"] = 
        {
            [4] = 
            {
                ["name"] = "Back-Alley Murders",
                ["y"] = 0.5736614466,
                ["x"] = 0.5158903599,
                ["preQuest"] = 3011,
                ["giver"] = "Beggar Matthew",
                ["otherInfo"] = 
                {
                    ["time"] = 1533679195,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Swine Thief",
                ["y"] = 0.3237193525,
                ["x"] = 0.4550656676,
                ["preQuest"] = 3039,
                ["giver"] = "Swineherd Wickton",
                ["otherInfo"] = 
                {
                    ["time"] = 1533677832,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2878405750,
                ["x"] = 0.5131012201,
                ["name"] = "One of the Undaunted",
                ["giver"] = "Mighty Mordra",
                ["otherInfo"] = 
                {
                    ["time"] = 1533677886,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.2740499675,
                ["x"] = 0.4846858084,
                ["name"] = "Room to Spare",
                ["giver"] = "Felande Demarie",
                ["otherInfo"] = 
                {
                    ["time"] = 1533678341,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },