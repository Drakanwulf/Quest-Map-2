QM_Scout =
{
    ["startTime"] = 1533505942,
    ["questInfo"] = 
    {
        [6144] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2561] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6146] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2564] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6149] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6150] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6151] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2569] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [523] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4622] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2576] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2578] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2068] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6165] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6166] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4631] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6170] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6172] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 10,
                [3] = 1,
            },
        },
        [6174] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6176] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6177] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6179] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6180] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6181] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6185] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6190] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4656] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4145] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [6194] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5171] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6196] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 1,
            },
        },
        [3637] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6198] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [1591] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [575] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4672] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6218] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [4686] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1615] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2130] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6227] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6228] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1633] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2146] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3172] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1637] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [614] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1639] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4202] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2161] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3187] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3190] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3192] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4731] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5247] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5249] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [2184] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5259] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1678] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4751] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2192] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [657] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4754] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4246] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [1687] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4760] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4761] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5274] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4767] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5283] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5799] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5803] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1709] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2222] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5303] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5309] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5312] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1735] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3784] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2251] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5836] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2255] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3285] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3286] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [728] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5342] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [736] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [737] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4834] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3302] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3303] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4840] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3305] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4843] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4844] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4335] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4336] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3314] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5877] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5368] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4857] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4858] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5374] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5377] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3333] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3337] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5388] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5389] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [3343] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5392] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5394] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5395] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4884] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4888] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3353] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4379] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5406] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5407] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5409] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5412] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4901] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4902] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4903] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5416] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5417] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5418] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [4401] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3379] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4916] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3381] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3383] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4920] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3385] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4923] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2364] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1341] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4926] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4927] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5952] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
        },
        [4929] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4930] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4931] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4934] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4936] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4937] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3916] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3918] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6199] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 7,
                [4] = 1,
            },
        },
        [4944] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4945] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6195] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4435] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3412] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4949] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3414] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2558] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4952] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6197] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6140] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4443] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5881] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5981] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [4958] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5983] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [3783] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4961] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 10,
            },
        },
        [6137] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2403] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2404] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4965] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4088] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1383] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1384] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6135] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3296] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4971] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4972] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5431] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3438] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4839] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3440] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3953] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3059] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2240] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6004] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4980] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2356] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6007] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4472] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4473] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4638] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6126] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
        },
        [3964] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3367] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2344] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3344] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3050] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6121] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3970] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2193] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2436] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4721] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6022] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [2567] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4841] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2566] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5972] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [2046] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5413] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5400] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6111] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5396] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5415] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [6153] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [2450] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2451] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5012] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1568] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5014] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1541] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3482] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3993] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5018] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4403] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5020] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3997] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [5022] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5973] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [5024] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4054] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3029] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5027] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4516] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1339] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6099] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4519] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4928] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [465] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3416] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6059] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6060] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6061] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2408] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3436] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2481] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4529] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4533] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4531] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3509] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2997] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2998] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4535] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5021] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3001] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5051] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3003] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3004] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1536] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2494] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2495] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2496] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2497] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [521] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3011] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5976] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [4822] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [1554] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5954] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
        },
        [2504] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3017] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6162] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3019] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3020] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1485] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6145] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3023] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6096] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6097] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4565] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [467] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [6100] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6101] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6102] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1437] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4942] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4659] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6136] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3035] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [499] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6109] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1346] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3039] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6112] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6113] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
        },
        [6114] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6115] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6116] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6117] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6118] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6119] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2536] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2537] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2538] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4107] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2187] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6125] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3566] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6127] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4080] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6129] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6130] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6131] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6132] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2549] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2550] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1527] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2552] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1529] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6138] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6139] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2556] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6141] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6142] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2047] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
    },
    ["subZones"] = 
    {
        ["vvardenfell/vvardenfell_base"] = 
        {
            ["vvardenfell/odirniran_base"] = 
            {
                ["x"] = 0.7728256583,
                ["y"] = 0.8294625878,
            },
            ["vvardenfell/firemothisland_base"] = 
            {
                ["x"] = 0.8348253369,
                ["y"] = 0.4202829599,
            },
            ["vvardenfell/zaintiraris_base"] = 
            {
                ["x"] = 0.8212261796,
                ["y"] = 0.7254741788,
            },
            ["vvardenfell/andrano_base"] = 
            {
                ["x"] = 0.7930721641,
                ["y"] = 0.4316285551,
            },
            ["vvardenfell/zainsipilu_base"] = 
            {
                ["x"] = 0.7515901923,
                ["y"] = 0.3583010733,
            },
            ["vvardenfell/viviccity_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/molagmarglassmine_base"] = 
            {
                ["x"] = 0.7482542396,
                ["y"] = 0.7141730189,
            },
        },
        ["auridon/auridon_base"] = 
        {
            ["auridon/khenarthisroost_base"] = 
            {
                ["x"] = 0.2228444815,
                ["y"] = 0.3501114547,
            },
        },
        ["alikr/alikr_base"] = 
        {
            ["alikr/volenfell_base"] = 
            {
                ["x"] = 0.4628429115,
                ["y"] = 0.8726661801,
            },
            ["alikr/sandblownmine_base"] = 
            {
                ["x"] = 0.5083644390,
                ["y"] = 0.8309459686,
            },
            ["alikr/lostcity_base"] = 
            {
                ["x"] = 0.2899029255,
                ["y"] = 0.6729325652,
            },
            ["alikr/yldzuun_base"] = 
            {
                ["x"] = 0.5083644390,
                ["y"] = 0.8309459686,
            },
            ["alikr/salasen_base"] = 
            {
                ["x"] = 0.6820662022,
                ["y"] = 0.2205028683,
            },
            ["alikr/divadschagrinmine_base"] = 
            {
                ["x"] = 0.4622105956,
                ["y"] = 0.2483669370,
            },
            ["alikr/kulatimines-a_base"] = 
            {
                ["x"] = 0.5081379414,
                ["y"] = 0.4977097213,
            },
            ["alikr/suturahs_crypt"] = 
            {
                ["x"] = 0.2986557186,
                ["y"] = 0.7747572660,
            },
            ["alikr/sentinel_base"] = 
            {
                ["x"] = 0.3627234399,
                ["y"] = 0.5104555488,
            },
            ["alikr/coldrockdiggings_base"] = 
            {
                ["x"] = 0.5001991391,
                ["y"] = 0.7188598514,
            },
            ["alikr/aldunz_base"] = 
            {
                ["x"] = 0.6422330141,
                ["y"] = 0.6404904127,
            },
            ["alikr/yokudanpalace02_base"] = 
            {
                ["x"] = 0.6587777138,
                ["y"] = 0.2947149575,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            ["stormhaven/godrunsdream_base"] = 
            {
                ["x"] = 0.4834085703,
                ["y"] = 0.7412771583,
            },
            ["stormhaven/aphrenshold_base"] = 
            {
                ["x"] = 0.4917228520,
                ["y"] = 0.6410685778,
            },
            ["stormhaven/portdunwatch_base"] = 
            {
                ["x"] = 0.3236285746,
                ["y"] = 0.3078914285,
            },
            ["stormhaven/alcairecastle_base"] = 
            {
                ["x"] = 0.2951657176,
                ["y"] = 0.3298285604,
            },
            ["stormhaven/bearclawmine_base"] = 
            {
                ["x"] = 0.4329885840,
                ["y"] = 0.7857285738,
            },
            ["stormhaven/bonesnapruinssecret_base"] = 
            {
                ["x"] = 0.4975742996,
                ["y"] = 0.3175171316,
            },
            ["stormhaven/windridgecave_base"] = 
            {
                ["x"] = 0.2765971422,
                ["y"] = 0.2868742943,
            },
            ["stormhaven/wayrest_base"] = 
            {
                ["x"] = 0.6020143032,
                ["y"] = 0.3844971359,
            },
            ["stormhaven/norvulkruins_base"] = 
            {
                ["x"] = 0.3670828640,
                ["y"] = 0.6055743098,
            },
            ["stormhaven/pariahcatacombs_base"] = 
            {
                ["x"] = 0.4301457107,
                ["y"] = 0.4577028453,
            },
        },
        ["grahtwood/grahtwood_base"] = 
        {
            ["grahtwood/eldenrootservices_base"] = 
            {
                ["x"] = 0.3965311348,
                ["y"] = 0.6190371513,
            },
        },
        ["summerset/summerset_base"] = 
        {
            ["summerset/ui_map"] = 
            {
                ["x"] = 0.3561471999,
                ["y"] = 0.4230011404,
            },
            ["summerset/corgradwastehigher2_base"] = 
            {
                ["x"] = 0.2811351120,
                ["y"] = 0.2448797524,
            },
            ["summerset/torhamekhard_01"] = 
            {
                ["x"] = 0.5443542600,
                ["y"] = 0.4963967800,
            },
            ["summerset/wastencoraldale_base"] = 
            {
                ["x"] = 0.5220731497,
                ["y"] = 0.2665567696,
            },
            ["summerset/ceytarncaveext01_base"] = 
            {
                ["x"] = 0.5518673062,
                ["y"] = 0.3494780362,
            },
            ["summerset/archonsgrove_base"] = 
            {
                ["x"] = 0.5836012363,
                ["y"] = 0.5790919065,
            },
            ["summerset/artaeum_base"] = 
            {
                ["x"] = 0.4623057544,
                ["y"] = 0.4480006099,
            },
            ["summerset/sunhold_base"] = 
            {
                ["x"] = 0.3633111417,
                ["y"] = 0.3487282395,
            },
            ["summerset/sq4sapiarch02_base"] = 
            {
                ["x"] = 0.3934149444,
                ["y"] = 0.1052494198,
            },
            ["summerset/seakeep_03"] = 
            {
                ["x"] = 0.4341204464,
                ["y"] = 0.2106248140,
            },
            ["summerset/collegeofpsijicsruins_btm"] = 
            {
                ["x"] = 0.4623057544,
                ["y"] = 0.4480006099,
            },
            ["summerset/illuminationacademy_01"] = 
            {
                ["x"] = 0.3232491612,
                ["y"] = 0.3171582818,
            },
            ["summerset/karndar_03"] = 
            {
                ["x"] = 0.3199555576,
                ["y"] = 0.6266152859,
            },
            ["summerset/sinkhole_base"] = 
            {
                ["x"] = 0.4278960228,
                ["y"] = 0.4365155399,
            },
            ["summerset/ebonstadmont03_base"] = 
            {
                ["x"] = 0.3468613625,
                ["y"] = 0.3874606490,
            },
            ["summerset/lillandrilcave_base"] = 
            {
                ["x"] = 0.4480309784,
                ["y"] = 0.1849195659,
            },
            ["summerset/russafeldredtemple01_base"] = 
            {
                ["x"] = 0.4843394756,
                ["y"] = 0.4995644093,
            },
            ["summerset/eldbursanctuary02_base"] = 
            {
                ["x"] = 0.3709714115,
                ["y"] = 0.5544005036,
            },
            ["summerset/russafeldredtemple02_base"] = 
            {
                ["x"] = 0.4036326706,
                ["y"] = 0.4386571348,
            },
            ["summerset/etonnir_01"] = 
            {
                ["x"] = 0.3271756768,
                ["y"] = 0.5096121430,
            },
            ["summerset/sum_karnwasten"] = 
            {
                ["x"] = 0.2091100663,
                ["y"] = 0.3010985851,
            },
            ["summerset/kingshavenext_base"] = 
            {
                ["x"] = 0.2751277089,
                ["y"] = 0.4893906713,
            },
            ["summerset/sq7courtofbedlamruins_base"] = 
            {
                ["x"] = 0.3114149868,
                ["y"] = 0.2188724726,
            },
            ["summerset/ceytarncaveint03_base"] = 
            {
                ["x"] = 0.5509521365,
                ["y"] = 0.3513980210,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            ["glenumbra/daggerfall_base"] = 
            {
                ["x"] = 0.7309818864,
                ["y"] = 0.3731749952,
            },
            ["glenumbra/silumm_base"] = 
            {
                ["x"] = 0.6779845357,
                ["y"] = 0.2721574605,
            },
            ["glenumbra/spindleclutch_base"] = 
            {
                ["x"] = 0.3366774917,
                ["y"] = 0.7143661976,
            },
            ["glenumbra/eboncrypt_base"] = 
            {
                ["x"] = 0.3692837954,
                ["y"] = 0.4798353016,
            },
            ["glenumbra/cryptwatchfort_base"] = 
            {
                ["x"] = 0.2532835305,
                ["y"] = 0.6058680415,
            },
            ["glenumbra/ilessantower_base"] = 
            {
                ["x"] = 0.7259832025,
                ["y"] = 0.3480412066,
            },
            ["glenumbra/tomboflostkings_base"] = 
            {
                ["x"] = 0.2866012454,
                ["y"] = 0.7805057764,
            },
        },
        ["stonefalls/stonefalls_base"] = 
        {
            ["stonefalls/davonswatch_base"] = 
            {
                ["x"] = 0.4937464893,
                ["y"] = 0.5806365609,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            ["rivenspire/northpoint_base"] = 
            {
                ["x"] = 0.4192044437,
                ["y"] = 0.6977521181,
            },
            ["rivenspire/tribulationcrypt_base"] = 
            {
                ["x"] = 0.6021974683,
                ["y"] = 0.6716846228,
            },
            ["rivenspire/shadowfatecavern_base"] = 
            {
                ["x"] = 0.7164837718,
                ["y"] = 0.2099232525,
            },
            ["rivenspire/breaghafinupper_base"] = 
            {
                ["x"] = 0.2418812662,
                ["y"] = 0.6513264179,
            },
            ["rivenspire/lorkrataruinsa_base"] = 
            {
                ["x"] = 0.4828965664,
                ["y"] = 0.5993559957,
            },
            ["rivenspire/rivenspireoutlaw_base"] = 
            {
                ["x"] = 0.5317950249,
                ["y"] = 0.4735883772,
            },
            ["rivenspire/edraldundercroftdomed_base"] = 
            {
                ["x"] = 0.5017006397,
                ["y"] = 0.7009591460,
            },
            ["rivenspire/orcsfingerruins_base"] = 
            {
                ["x"] = 0.3507380486,
                ["y"] = 0.8094767928,
            },
            ["rivenspire/doomcragshroudedpass_base"] = 
            {
                ["x"] = 0.4524268210,
                ["y"] = 0.2928013802,
            },
            ["rivenspire/hildunessecretrefuge_base"] = 
            {
                ["x"] = 0.1964630783,
                ["y"] = 0.7363085151,
            },
            ["rivenspire/obsidianscar_base"] = 
            {
                ["x"] = 0.4192044437,
                ["y"] = 0.6977521181,
            },
            ["rivenspire/flyleafcatacombs_base"] = 
            {
                ["x"] = 0.5922636986,
                ["y"] = 0.1450490803,
            },
            ["rivenspire/shroudedpass2_base"] = 
            {
                ["x"] = 0.4239128530,
                ["y"] = 0.4067715704,
            },
            ["rivenspire/doomcragtop_base"] = 
            {
                ["x"] = 0.3759659529,
                ["y"] = 0.3183684349,
            },
            ["rivenspire/erokii_base"] = 
            {
                ["x"] = 0.3114539683,
                ["y"] = 0.4000349045,
            },
        },
        ["greenshade/greenshade_base"] = 
        {
            ["greenshade/marbruk_base"] = 
            {
                ["x"] = 0.4128727615,
                ["y"] = 0.5915572643,
            },
        },
        ["clockwork/clockwork_base"] = 
        {
            ["clockwork/brassfortress_base"] = 
            {
                ["x"] = 0.4424764514,
                ["y"] = 0.4953917861,
            },
            ["clockwork/ccq1_map3"] = 
            {
                ["x"] = 0.7557187080,
                ["y"] = 0.7180359364,
            },
        },
    },
    ["quests"] = 
    {
        ["stormhaven/bonesnapruinssecret_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Sir Edgard",
                ["x"] = 0.6059898734,
                ["otherInfo"] = 
                {
                    ["time"] = 1533871296,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Lost Lions",
                ["y"] = 0.6375247836,
            },
            [1] = 
            {
                ["preQuest"] = 1637,
                ["giver"] = "Battlemage Gaston",
                ["x"] = 0.6948909760,
                ["otherInfo"] = 
                {
                    ["time"] = 1533868567,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Repairing the Cage",
                ["y"] = 0.8454304934,
            },
        },
        ["vvardenfell/viviccity_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6007,
                ["giver"] = "Edryno Giryon",
                ["x"] = 0.5224552155,
                ["otherInfo"] = 
                {
                    ["time"] = 1536777892,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Late Delivery",
                ["y"] = 0.4175760448,
            },
        },
        ["summerset/sunhold_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Kinlady Helenaere",
                ["x"] = 0.7326334715,
                ["otherInfo"] = 
                {
                    ["time"] = 1535584965,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Sunhold Sundered",
                ["y"] = 0.7812337875,
            },
        },
        ["grahtwood/eldenrootservices_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Undaunted Enclave Invitation",
                ["x"] = 0.6841142774,
                ["otherInfo"] = 
                {
                    ["time"] = 1534827071,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Taking the Undaunted Pledge",
                ["y"] = 0.4082742929,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Merthyval Lort",
                ["x"] = 0.1734942794,
                ["otherInfo"] = 
                {
                    ["time"] = 1533765724,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "A Family Affair",
                ["y"] = 0.3512257040,
            },
            [2] = 
            {
                ["preQuest"] = 2561,
                ["giver"] = "William Nurin",
                ["x"] = 0.1847085655,
                ["otherInfo"] = 
                {
                    ["time"] = 1533766855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Scamp Invasion",
                ["y"] = 0.3290571570,
            },
            [3] = 
            {
                ["preQuest"] = 2578,
                ["giver"] = "Phinis Vanne",
                ["x"] = 0.2047742903,
                ["otherInfo"] = 
                {
                    ["time"] = 1533767983,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Can't Leave Without Her",
                ["y"] = 0.4067914188,
            },
            [4] = 
            {
                ["giver"] = "Brother Perry",
                ["x"] = 0.2087714225,
                ["otherInfo"] = 
                {
                    ["time"] = 1533768092,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Slumbering Farmer",
                ["y"] = 0.3682714403,
            },
            [5] = 
            {
                ["preQuest"] = 1678,
                ["giver"] = "Ingride Vanne",
                ["x"] = 0.2702714205,
                ["otherInfo"] = 
                {
                    ["time"] = 1533776633,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Rozenn's Dream",
                ["y"] = 0.3650457263,
            },
            [6] = 
            {
                ["preQuest"] = 1709,
                ["giver"] = "Attack Plans",
                ["x"] = 0.1770542860,
                ["otherInfo"] = 
                {
                    ["time"] = 1533846079,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Lighthouse Attack Plans",
                ["y"] = 0.4724285603,
            },
            [7] = 
            {
                ["giver"] = "Tyree Marence",
                ["x"] = 0.1766742915,
                ["otherInfo"] = 
                {
                    ["time"] = 1533846248,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Repair Koeglin Lighthouse",
                ["y"] = 0.5024399757,
            },
            [8] = 
            {
                ["giver"] = "Tyree Marence",
                ["x"] = 0.1754028499,
                ["otherInfo"] = 
                {
                    ["time"] = 1533846986,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Repair Koeglin Lighthouse",
                ["y"] = 0.5064542890,
            },
            [9] = 
            {
                ["giver"] = "Attack Plans",
                ["x"] = 0.1770028621,
                ["otherInfo"] = 
                {
                    ["time"] = 1533847046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Lighthouse Attack Plans",
                ["y"] = 0.4726114273,
            },
            [10] = 
            {
                ["giver"] = "Captain Albert Marck",
                ["x"] = 0.1617742926,
                ["otherInfo"] = 
                {
                    ["time"] = 1533851768,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Captive Crewmembers",
                ["y"] = 0.5501142740,
            },
            [11] = 
            {
                ["preQuest"] = 728,
                ["giver"] = "First Mate Elvira Derre",
                ["x"] = 0.2323114276,
                ["otherInfo"] = 
                {
                    ["time"] = 1533853374,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Divert and Deliver",
                ["y"] = 0.5126199722,
            },
            [12] = 
            {
                ["giver"] = "Sir Graham",
                ["x"] = 0.2869457006,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943284,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "False Knights",
                ["y"] = 0.3264142871,
            },
            [13] = 
            {
                ["giver"] = "Sir Graham",
                ["x"] = 0.2859799862,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943891,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "False Knights",
                ["y"] = 0.3274685740,
            },
            [14] = 
            {
                ["giver"] = "Sir Edmund",
                ["x"] = 0.2963399887,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943921,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Flame of Dissent",
                ["y"] = 0.3046999872,
            },
            [15] = 
            {
                ["preQuest"] = 736,
                ["giver"] = "Sir Edmund",
                ["x"] = 0.2970771492,
                ["otherInfo"] = 
                {
                    ["time"] = 1533944379,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Retaking Firebrand Keep",
                ["y"] = 0.3039971292,
            },
            [16] = 
            {
                ["preQuest"] = 737,
                ["giver"] = "Sir Edmund",
                ["x"] = 0.3258914351,
                ["otherInfo"] = 
                {
                    ["time"] = 1533944995,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Army at the Gates",
                ["y"] = 0.3003971577,
            },
            [17] = 
            {
                ["giver"] = "Weather-Beaten Trunk",
                ["x"] = 0.2456285655,
                ["otherInfo"] = 
                {
                    ["time"] = 1533956133,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Legacy of the Three",
                ["y"] = 0.2786599994,
            },
            [18] = 
            {
                ["preQuest"] = 2576,
                ["giver"] = "Sir Edmund",
                ["x"] = 0.3260971308,
                ["otherInfo"] = 
                {
                    ["time"] = 1534024196,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Sir Hughes' Fate",
                ["y"] = 0.3008942902,
            },
            [19] = 
            {
                ["preQuest"] = 467,
                ["giver"] = "Duke Nathaniel",
                ["x"] = 0.3323028684,
                ["otherInfo"] = 
                {
                    ["time"] = 1534032366,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Unanswered Questions",
                ["y"] = 0.2973114252,
            },
            [20] = 
            {
                ["preQuest"] = 1735,
                ["giver"] = "Brother Zacharie",
                ["x"] = 0.4674942791,
                ["otherInfo"] = 
                {
                    ["time"] = 1534035243,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Fire in the Fields",
                ["y"] = 0.4025200009,
            },
            [21] = 
            {
                ["giver"] = "Brother Perry",
                ["x"] = 0.4949942827,
                ["otherInfo"] = 
                {
                    ["time"] = 1534040985,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Dreams to Nightmares",
                ["y"] = 0.4018571377,
            },
            [22] = 
            {
                ["preQuest"] = 2046,
                ["giver"] = "Master Muzgu",
                ["x"] = 0.5474256873,
                ["otherInfo"] = 
                {
                    ["time"] = 1534041930,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Gate to Quagmire",
                ["y"] = 0.3202342987,
            },
            [23] = 
            {
                ["preQuest"] = 1536,
                ["giver"] = "Sister Safia",
                ["x"] = 0.4313657284,
                ["otherInfo"] = 
                {
                    ["time"] = 1534043081,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Azura's Guardian",
                ["y"] = 0.3711885810,
            },
            [24] = 
            {
                ["preQuest"] = 1529,
                ["giver"] = "Master Altien",
                ["x"] = 0.4481828511,
                ["otherInfo"] = 
                {
                    ["time"] = 1534110562,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "A Prison of Sleep",
                ["y"] = 0.3937314153,
            },
            [25] = 
            {
                ["giver"] = "Falice Menoit",
                ["x"] = 0.4417657256,
                ["otherInfo"] = 
                {
                    ["time"] = 1534110585,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Injured Spirit Wardens",
                ["y"] = 0.3914342821,
            },
            [26] = 
            {
                ["preQuest"] = 1541,
                ["giver"] = "Abbot Durak",
                ["x"] = 0.4508599937,
                ["otherInfo"] = 
                {
                    ["time"] = 1534115232,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Pursuing the Shard",
                ["y"] = 0.4171828628,
            },
            [27] = 
            {
                ["preQuest"] = 1485,
                ["giver"] = "Arcady Charnis",
                ["x"] = 0.4334171414,
                ["otherInfo"] = 
                {
                    ["time"] = 1534127785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Sower Reaps",
                ["y"] = 0.5928171277,
            },
            [28] = 
            {
                ["giver"] = "Priestess Pietine",
                ["x"] = 0.4062657058,
                ["otherInfo"] = 
                {
                    ["time"] = 1534128064,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Abominations from Beyond",
                ["y"] = 0.5902314186,
            },
            [29] = 
            {
                ["giver"] = "Cursed Skull",
                ["x"] = 0.3788971305,
                ["otherInfo"] = 
                {
                    ["time"] = 1534128145,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Curse of Skulls",
                ["y"] = 0.6093199849,
            },
            [30] = 
            {
                ["preQuest"] = 499,
                ["giver"] = "Hosni at-Tura",
                ["x"] = 0.3172799945,
                ["otherInfo"] = 
                {
                    ["time"] = 1534132043,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Signet Ring",
                ["y"] = 0.6113514304,
            },
            [31] = 
            {
                ["preQuest"] = 2495,
                ["giver"] = "Lady Sirali at-Tura",
                ["x"] = 0.2957200110,
                ["otherInfo"] = 
                {
                    ["time"] = 1534132624,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Evidence Against Adima",
                ["y"] = 0.5777771473,
            },
            [32] = 
            {
                ["preQuest"] = 2496,
                ["giver"] = "Lady Sirali at-Tura",
                ["x"] = 0.2950657010,
                ["otherInfo"] = 
                {
                    ["time"] = 1534133322,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Saving Hosni",
                ["y"] = 0.5778542757,
            },
            [33] = 
            {
                ["preQuest"] = 2497,
                ["giver"] = "Hosni at-Tura",
                ["x"] = 0.3099485636,
                ["otherInfo"] = 
                {
                    ["time"] = 1534133785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Return of the Dream Shard",
                ["y"] = 0.6140800118,
            },
            [34] = 
            {
                ["preQuest"] = 1633,
                ["giver"] = "Abbot Durak",
                ["x"] = 0.4502457082,
                ["otherInfo"] = 
                {
                    ["time"] = 1534134224,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Another Omen",
                ["y"] = 0.4175542891,
            },
            [35] = 
            {
                ["giver"] = "Watch Captain Rama",
                ["x"] = 0.5220771432,
                ["otherInfo"] = 
                {
                    ["time"] = 1534134527,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Blood Revenge",
                ["y"] = 0.4397457242,
            },
            [36] = 
            {
                ["giver"] = "Pierre Lanier",
                ["x"] = 0.5551342964,
                ["otherInfo"] = 
                {
                    ["time"] = 1534135047,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Rat in a Trap",
                ["y"] = 0.4184857011,
            },
            [37] = 
            {
                ["preQuest"] = 1554,
                ["giver"] = "Watch Commander Kurt",
                ["x"] = 0.5594199896,
                ["otherInfo"] = 
                {
                    ["time"] = 1534135245,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "A Means to an End",
                ["y"] = 0.4466885626,
            },
            [38] = 
            {
                ["preQuest"] = 1568,
                ["giver"] = "Watch Captain Ernard",
                ["x"] = 0.5594199896,
                ["otherInfo"] = 
                {
                    ["time"] = 1534136855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Revenge Against Rama",
                ["y"] = 0.4467457235,
            },
            [39] = 
            {
                ["preQuest"] = 1384,
                ["giver"] = "Dro-Dara",
                ["x"] = 0.7167114019,
                ["otherInfo"] = 
                {
                    ["time"] = 1534284908,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Plowshares to Swords",
                ["y"] = 0.5452857018,
            },
            [40] = 
            {
                ["giver"] = "Sister Tabakah",
                ["x"] = 0.8102228642,
                ["otherInfo"] = 
                {
                    ["time"] = 1534285563,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Azura's Relics",
                ["y"] = 0.4731028676,
            },
            [41] = 
            {
                ["preQuest"] = 2536,
                ["giver"] = "Knarstygg",
                ["x"] = 0.7230571508,
                ["otherInfo"] = 
                {
                    ["time"] = 1534289013,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Predator's Heart",
                ["y"] = 0.5479228497,
            },
            [42] = 
            {
                ["giver"] = "General Godrun",
                ["x"] = 0.7429599762,
                ["otherInfo"] = 
                {
                    ["time"] = 1534292650,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "General Godrun's Orders",
                ["y"] = 0.4852257073,
            },
            [43] = 
            {
                ["giver"] = "Captain Dugakh",
                ["x"] = 0.7367143035,
                ["otherInfo"] = 
                {
                    ["time"] = 1534292860,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Ogre Teeth",
                ["y"] = 0.4715114236,
            },
            [44] = 
            {
                ["preQuest"] = 1437,
                ["giver"] = "General Godrun",
                ["x"] = 0.7524114251,
                ["otherInfo"] = 
                {
                    ["time"] = 1534293441,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Ending the Ogre Threat",
                ["y"] = 0.4308257103,
            },
            [45] = 
            {
                ["preQuest"] = 1346,
                ["giver"] = "Abbot Durak",
                ["x"] = 0.7416971326,
                ["otherInfo"] = 
                {
                    ["time"] = 1534304400,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Godrun's Dream",
                ["y"] = 0.4839485586,
            },
            [46] = 
            {
                ["preQuest"] = 3637,
                ["giver"] = "Abbot Durak",
                ["x"] = 0.7431628704,
                ["otherInfo"] = 
                {
                    ["time"] = 1534304982,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Azura's Aid",
                ["y"] = 0.4835257232,
            },
            [47] = 
            {
                ["giver"] = "Mathias Raiment",
                ["x"] = 0.6858485937,
                ["otherInfo"] = 
                {
                    ["time"] = 1534365486,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Look in the Mirror",
                ["y"] = 0.4296885729,
            },
            [48] = 
            {
                ["preQuest"] = 614,
                ["giver"] = "Countess Ilise Manteau",
                ["x"] = 0.6523114443,
                ["otherInfo"] = 
                {
                    ["time"] = 1534365750,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Gift from a Suitor",
                ["y"] = 0.4326257110,
            },
            [49] = 
            {
                ["giver"] = "Michel Helomaine",
                ["x"] = 0.6221686006,
                ["otherInfo"] = 
                {
                    ["time"] = 1534368712,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Perfect Burial",
                ["y"] = 0.4065999985,
            },
            [50] = 
            {
                ["preQuest"] = 2538,
                ["giver"] = "Blaise Pamarc",
                ["x"] = 0.6690571308,
                ["otherInfo"] = 
                {
                    ["time"] = 1534370713,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "King Aphren's Sword",
                ["y"] = 0.5167885423,
            },
            [51] = 
            {
                ["giver"] = "Serge Arcole",
                ["x"] = 0.4425742924,
                ["otherInfo"] = 
                {
                    ["time"] = 1534395263,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Ransom for Miranda",
                ["y"] = 0.6117914319,
            },
            [52] = 
            {
                ["preQuest"] = 2451,
                ["giver"] = "Serge Arcole",
                ["x"] = 0.4409771562,
                ["otherInfo"] = 
                {
                    ["time"] = 1534396158,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Woman Wronged",
                ["y"] = 0.6594685912,
            },
        },
        ["stormhaven/alcairecastle_base"] = 
        {
            [4] = 
            {
                ["preQuest"] = 2567,
                ["giver"] = "Duke Nathaniel",
                ["x"] = 0.4016301334,
                ["otherInfo"] = 
                {
                    ["time"] = 1533955857,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Tracking Sir Hughes",
                ["y"] = 0.4368499517,
            },
            [1] = 
            {
                ["preQuest"] = 2552,
                ["giver"] = "Sir Hughes",
                ["x"] = 0.4701412022,
                ["otherInfo"] = 
                {
                    ["time"] = 1533950269,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Two Sides to Every Coin",
                ["y"] = 0.3651475012,
            },
            [2] = 
            {
                ["preQuest"] = 2564,
                ["giver"] = "Duchess Lakana",
                ["x"] = 0.4061531425,
                ["otherInfo"] = 
                {
                    ["time"] = 1533951481,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Life of the Duchess",
                ["y"] = 0.4338193238,
            },
            [3] = 
            {
                ["preQuest"] = 2566,
                ["giver"] = "Sir Hughes",
                ["x"] = 0.3367925584,
                ["otherInfo"] = 
                {
                    ["time"] = 1533955422,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Safety of the Kingdom",
                ["y"] = 0.5228102207,
            },
        },
        ["grahtwood/eldenrootcrafting_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167461,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.8027322292,
            },
            [2] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167461,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.8027322292,
            },
            [3] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167462,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.8027322292,
            },
            [4] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.5290710330,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167462,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.8027322292,
            },
            [5] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.7377595901,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.4062841535,
            },
            [6] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.7377595901,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.4062841535,
            },
            [7] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.7377595901,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167479,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.4062841535,
            },
        },
        ["bangkorai/evermore_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Sergeant Antieve",
                ["x"] = 0.2374275327,
                ["otherInfo"] = 
                {
                    ["time"] = 1536637763,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A City in Black",
                ["y"] = 0.5988582373,
            },
            [2] = 
            {
                ["giver"] = "Llotha Nelvani",
                ["x"] = 0.6538221240,
                ["otherInfo"] = 
                {
                    ["time"] = 1536639113,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Grave Matter",
                ["y"] = 0.2207296342,
            },
            [3] = 
            {
                ["preQuest"] = 4980,
                ["giver"] = "Zaag",
                ["x"] = 0.5188118815,
                ["otherInfo"] = 
                {
                    ["time"] = 1536712003,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Conflicted Emotions",
                ["y"] = 0.3479261398,
            },
        },
        ["glenumbra/badmansstart_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4767,
                ["giver"] = "Curator Nicholas",
                ["x"] = 0.4435261786,
                ["otherInfo"] = 
                {
                    ["time"] = 1533693555,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Season of Harvest",
                ["y"] = 0.6460055113,
            },
        },
        ["glenumbra/aldcroft_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 3004,
                ["giver"] = "Captain Vistra",
                ["x"] = 0.5562694669,
                ["otherInfo"] = 
                {
                    ["time"] = 1533669833,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Pride of the Lion Guard",
                ["y"] = 0.3413914144,
            },
        },
        ["stormhaven/farangelsdelve_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 2550,
                ["giver"] = "Tomb Urn",
                ["x"] = 0.4327341914,
                ["otherInfo"] = 
                {
                    ["time"] = 1534129561,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Stolen Ashes",
                ["y"] = 0.4242919385,
            },
        },
        ["auridon/thebanishedcells_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4841,
                ["giver"] = "Keeper Cirion",
                ["x"] = 0.4782767594,
                ["otherInfo"] = 
                {
                    ["time"] = 1536197347,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Banishing the Banished",
                ["y"] = 0.8494246006,
            },
        },
        ["summerset/dreamingcave03_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6112,
                ["giver"] = "Ritemaster Iachesis",
                ["x"] = 0.6542621255,
                ["otherInfo"] = 
                {
                    ["time"] = 1535594149,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Buried Memories",
                ["y"] = 0.7077407837,
            },
            [2] = 
            {
                ["preQuest"] = 6132,
                ["giver"] = "Ritemaster Iachesis",
                ["x"] = 0.6307587624,
                ["otherInfo"] = 
                {
                    ["time"] = 1535601322,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Tower Sentinels",
                ["y"] = 0.7504896522,
            },
            [3] = 
            {
                ["preQuest"] = 6142,
                ["giver"] = "Ritemaster Iachesis",
                ["x"] = 0.6557949185,
                ["otherInfo"] = 
                {
                    ["time"] = 1535690559,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Dreaming Cave",
                ["y"] = 0.6959039569,
            },
        },
        ["summerset/kingshavenext_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6137,
                ["giver"] = "Mehdze",
                ["x"] = 0.8305439353,
                ["otherInfo"] = 
                {
                    ["time"] = 1535322698,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Savage Truths",
                ["y"] = 0.4646966457,
            },
        },
        ["alikr/kozanset_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Hamza",
                ["x"] = 0.5800043941,
                ["otherInfo"] = 
                {
                    ["time"] = 1536432173,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Feathered Fiends",
                ["y"] = 0.4487309158,
            },
        },
        ["rivenspire/orcsfingerruins_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Teeba-Ja",
                ["x"] = 0.6867665052,
                ["otherInfo"] = 
                {
                    ["time"] = 1534990861,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Shedding the Past",
                ["y"] = 0.5621206164,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 3379,
                ["giver"] = "Recruit Maelle",
                ["x"] = 0.6233919263,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506571,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "A Dangerous Dream",
                ["y"] = 0.2641271353,
            },
            [2] = 
            {
                ["giver"] = "Garmeg the Ironfinder",
                ["x"] = 0.6356987953,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506619,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Legitimate Interests",
                ["y"] = 0.2552480102,
            },
            [3] = 
            {
                ["giver"] = "Provost Piper",
                ["x"] = 0.6614254117,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506677,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Vines and Villains",
                ["y"] = 0.2836774588,
            },
            [4] = 
            {
                ["giver"] = "Sir Marley Oris",
                ["x"] = 0.6967237592,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506771,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Cursed Treasure",
                ["y"] = 0.2603922486,
            },
            [5] = 
            {
                ["preQuest"] = 6227,
                ["giver"] = "Harald Winvale",
                ["x"] = 0.7467461228,
                ["otherInfo"] = 
                {
                    ["time"] = 1533526292,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Forgotten Ancestry",
                ["y"] = 0.2198418677,
            },
            [6] = 
            {
                ["preQuest"] = 3509,
                ["giver"] = "Stibbons",
                ["x"] = 0.7838526368,
                ["otherInfo"] = 
                {
                    ["time"] = 1533528128,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Jeweled Crown of Anton",
                ["y"] = 0.2978167236,
            },
            [7] = 
            {
                ["preQuest"] = 3050,
                ["giver"] = "King Donel Deleyn",
                ["x"] = 0.7397236228,
                ["otherInfo"] = 
                {
                    ["time"] = 1533594760,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Servants of Ancient Kings",
                ["y"] = 0.1833901852,
            },
            [8] = 
            {
                ["giver"] = "Sir Malik Nasir",
                ["x"] = 0.5530404449,
                ["otherInfo"] = 
                {
                    ["time"] = 1533609896,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Corpse Horde",
                ["y"] = 0.2773717642,
            },
            [9] = 
            {
                ["preQuest"] = 3314,
                ["giver"] = "Daggerfall Patroller",
                ["x"] = 0.4874128997,
                ["otherInfo"] = 
                {
                    ["time"] = 1533616621,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Farlivere's Gambit",
                ["y"] = 0.7047001719,
            },
            [10] = 
            {
                ["preQuest"] = 3001,
                ["giver"] = "Lord Arcady Noellaume",
                ["x"] = 0.5088144541,
                ["otherInfo"] = 
                {
                    ["time"] = 1533617294,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Disorganized Crime",
                ["y"] = 0.6687227488,
            },
            [11] = 
            {
                ["giver"] = "Lady Eloise Noellaume",
                ["x"] = 0.5077500343,
                ["otherInfo"] = 
                {
                    ["time"] = 1533617404,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Lady Eloise's Lockbox",
                ["y"] = 0.6681137681,
            },
            [12] = 
            {
                ["preQuest"] = 4335,
                ["giver"] = "Erwan Castille",
                ["x"] = 0.5817878842,
                ["otherInfo"] = 
                {
                    ["time"] = 1533670237,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Wicked Trade",
                ["y"] = 0.4949662387,
            },
            [13] = 
            {
                ["preQuest"] = 3023,
                ["giver"] = "Guy LeBlanc",
                ["x"] = 0.6777231693,
                ["otherInfo"] = 
                {
                    ["time"] = 1533670926,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Wyrd and Coven",
                ["y"] = 0.5040016770,
            },
            [14] = 
            {
                ["giver"] = "Mercenary",
                ["x"] = 0.6808248162,
                ["otherInfo"] = 
                {
                    ["time"] = 1533671046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Crocodile Bounty",
                ["y"] = 0.4546503127,
            },
            [15] = 
            {
                ["preQuest"] = 3017,
                ["giver"] = "Athel Baelborne",
                ["x"] = 0.3761095703,
                ["otherInfo"] = 
                {
                    ["time"] = 1533679671,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Legacy of Baelborne Rock",
                ["y"] = 0.7100141644,
            },
            [16] = 
            {
                ["preQuest"] = 3414,
                ["giver"] = "Lord Alain Diel",
                ["x"] = 0.3377877176,
                ["otherInfo"] = 
                {
                    ["time"] = 1533686910,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Dagger's Edge",
                ["y"] = 0.6140681505,
            },
            [17] = 
            {
                ["giver"] = "Leon Milielle",
                ["x"] = 0.4421305656,
                ["otherInfo"] = 
                {
                    ["time"] = 1533699922,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Ghosts of Westtry",
                ["y"] = 0.4058459699,
            },
            [18] = 
            {
                ["preQuest"] = 3019,
                ["giver"] = "Leon Milielle",
                ["x"] = 0.3977132440,
                ["otherInfo"] = 
                {
                    ["time"] = 1533701453,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Memento Mori",
                ["y"] = 0.4247629941,
            },
            [19] = 
            {
                ["preQuest"] = 3020,
                ["giver"] = "Lieutenant Clarice",
                ["x"] = 0.3257557452,
                ["otherInfo"] = 
                {
                    ["time"] = 1533702206,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Signals of Dominion",
                ["y"] = 0.3811810613,
            },
            [20] = 
            {
                ["giver"] = "Scout's Orders",
                ["x"] = 0.3128614426,
                ["otherInfo"] = 
                {
                    ["time"] = 1533702234,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Wayward Scouts",
                ["y"] = 0.3935525715,
            },
        },
        ["glenumbra/cryptwatchfort_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4080,
                ["giver"] = "Hastily Scribbled Note",
                ["x"] = 0.3861386180,
                ["otherInfo"] = 
                {
                    ["time"] = 1533695799,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Fortune in Failure",
                ["y"] = 0.3049505055,
            },
        },
        ["summerset/etonnir_01"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6174,
                ["giver"] = "Seeks-the-Dark",
                ["x"] = 0.9197530746,
                ["otherInfo"] = 
                {
                    ["time"] = 1535321772,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Looting the Light",
                ["y"] = 0.3739441335,
            },
        },
        ["glenumbra/minesofkhuras_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 3440,
                ["giver"] = "Guifford Vinielle's Sketchbook",
                ["x"] = 0.3869094849,
                ["otherInfo"] = 
                {
                    ["time"] = 1533705261,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "A Brush With Death",
                ["y"] = 0.7706518769,
            },
        },
        ["rivenspire/tribulationcrypt_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4844,
                ["giver"] = "Ancient Sword",
                ["x"] = 0.2981927693,
                ["otherInfo"] = 
                {
                    ["time"] = 1534718973,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Past Remembered",
                ["y"] = 0.1962851435,
            },
        },
        ["alikr/lostcity_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Letter to Tavo",
                ["x"] = 0.3969942033,
                ["otherInfo"] = 
                {
                    ["time"] = 1536444856,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "An Ill-Fated Venture",
                ["y"] = 0.5315229297,
            },
            [1] = 
            {
                ["preQuest"] = 2364,
                ["giver"] = "Paldeen",
                ["x"] = 0.4905205965,
                ["otherInfo"] = 
                {
                    ["time"] = 1536443214,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Secrets of the Lost City",
                ["y"] = 0.9049382806,
            },
        },
        ["alikr/alikr_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Herminius Sophus",
                ["x"] = 0.1420014948,
                ["otherInfo"] = 
                {
                    ["time"] = 1535068408,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Past in Ruins",
                ["y"] = 0.4980856478,
            },
            [2] = 
            {
                ["giver"] = "Lady Clarisse Laurent",
                ["x"] = 0.2751331925,
                ["otherInfo"] = 
                {
                    ["time"] = 1536019893,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Thwarting the Aldmeri Dominion",
                ["y"] = 0.6744162440,
            },
            [3] = 
            {
                ["giver"] = "Stibbons",
                ["x"] = 0.2463007271,
                ["otherInfo"] = 
                {
                    ["time"] = 1536020090,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Lady Laurent's Favor",
                ["y"] = 0.6599228382,
            },
            [4] = 
            {
                ["preQuest"] = 4672,
                ["giver"] = "Marimah",
                ["x"] = 0.2971570790,
                ["otherInfo"] = 
                {
                    ["time"] = 1536178583,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Initiation",
                ["y"] = 0.6580856442,
            },
            [5] = 
            {
                ["preQuest"] = 4686,
                ["giver"] = "Talia at-Marimah",
                ["x"] = 0.2966592014,
                ["otherInfo"] = 
                {
                    ["time"] = 1536180217,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Ash'abah Rising",
                ["y"] = 0.6594074965,
            },
            [6] = 
            {
                ["giver"] = "Anjan",
                ["x"] = 0.3212123513,
                ["otherInfo"] = 
                {
                    ["time"] = 1536180330,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Nature of Fate",
                ["y"] = 0.6000323892,
            },
            [7] = 
            {
                ["giver"] = "Throne Keeper Farvad",
                ["x"] = 0.3972641230,
                ["otherInfo"] = 
                {
                    ["time"] = 1536279743,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Tu'whacca's Breath",
                ["y"] = 0.5750286579,
            },
            [8] = 
            {
                ["preQuest"] = 3190,
                ["giver"] = "Ramati at-Gar",
                ["x"] = 0.4091062844,
                ["otherInfo"] = 
                {
                    ["time"] = 1536279855,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Revered Ancestors",
                ["y"] = 0.5544087887,
            },
            [9] = 
            {
                ["preQuest"] = 2184,
                ["giver"] = "Throne Keeper Farvad",
                ["x"] = 0.4021185040,
                ["otherInfo"] = 
                {
                    ["time"] = 1536352135,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Reckoning with Uwafa",
                ["y"] = 0.5306970477,
            },
            [10] = 
            {
                ["preQuest"] = 2192,
                ["giver"] = "Throne Keeper Farvad",
                ["x"] = 0.4317500591,
                ["otherInfo"] = 
                {
                    ["time"] = 1536352628,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Scholar of Bergama",
                ["y"] = 0.5306920409,
            },
            [11] = 
            {
                ["giver"] = "Samsi af-Bazra",
                ["x"] = 0.3236694038,
                ["otherInfo"] = 
                {
                    ["time"] = 1536372240,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Badwater Mine",
                ["y"] = 0.5347821712,
            },
            [12] = 
            {
                ["preQuest"] = 3383,
                ["giver"] = "Hayazzin",
                ["x"] = 0.3955812752,
                ["otherInfo"] = 
                {
                    ["time"] = 1536372763,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Satak was the First Serpent",
                ["y"] = 0.6404829621,
            },
            [13] = 
            {
                ["giver"] = "Letta",
                ["x"] = 0.5881976485,
                ["otherInfo"] = 
                {
                    ["time"] = 1536381303,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Snakes in the Sands",
                ["y"] = 0.5868707895,
            },
            [14] = 
            {
                ["giver"] = "Darius",
                ["x"] = 0.8310804367,
                ["otherInfo"] = 
                {
                    ["time"] = 1536428264,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Honoring the Dishonored",
                ["y"] = 0.5111326575,
            },
            [15] = 
            {
                ["preQuest"] = 3970,
                ["giver"] = "Onwyn",
                ["x"] = 0.4959322810,
                ["otherInfo"] = 
                {
                    ["time"] = 1536447037,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Winner for Onwyn",
                ["y"] = 0.6113567352,
            },
            [16] = 
            {
                ["giver"] = "Kasal",
                ["x"] = 0.5143863559,
                ["otherInfo"] = 
                {
                    ["time"] = 1536457310,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Crawling Chaos",
                ["y"] = 0.5169479847,
            },
            [17] = 
            {
                ["preQuest"] = 2255,
                ["giver"] = "Leki's Disciple",
                ["x"] = 0.5780732036,
                ["otherInfo"] = 
                {
                    ["time"] = 1536458167,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Master of Leki's Blade",
                ["y"] = 0.5050261617,
            },
            [18] = 
            {
                ["giver"] = "Musi",
                ["x"] = 0.5640453100,
                ["otherInfo"] = 
                {
                    ["time"] = 1536458202,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Undying Loyalty",
                ["y"] = 0.5162708759,
            },
            [19] = 
            {
                ["preQuest"] = 4754,
                ["giver"] = "Hadoon",
                ["x"] = 0.6632511616,
                ["otherInfo"] = 
                {
                    ["time"] = 1536461018,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Nature of Fate: Part Two",
                ["y"] = 0.5207567811,
            },
            [20] = 
            {
                ["preQuest"] = 3367,
                ["giver"] = "Throne Keeper Farvad",
                ["x"] = 0.7338088155,
                ["otherInfo"] = 
                {
                    ["time"] = 1536463157,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "March of the Ra Gada",
                ["y"] = 0.5130893588,
            },
            [21] = 
            {
                ["preQuest"] = 2356,
                ["giver"] = "Throne Keeper Farvad",
                ["x"] = 0.7541349530,
                ["otherInfo"] = 
                {
                    ["time"] = 1536467785,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Trials of the Hero",
                ["y"] = 0.5679935217,
            },
            [22] = 
            {
                ["preQuest"] = 3296,
                ["giver"] = "Uhrih",
                ["x"] = 0.6972267628,
                ["otherInfo"] = 
                {
                    ["time"] = 1536468477,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Malignant Militia",
                ["y"] = 0.4839780927,
            },
            [23] = 
            {
                ["preQuest"] = 4731,
                ["giver"] = "Aqabi of the Ungodly",
                ["x"] = 0.5570375919,
                ["otherInfo"] = 
                {
                    ["time"] = 1536469203,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Whose Wedding?",
                ["y"] = 0.4343739152,
            },
            [24] = 
            {
                ["preQuest"] = 4760,
                ["giver"] = "Talia at-Marimah",
                ["x"] = 0.5669330359,
                ["otherInfo"] = 
                {
                    ["time"] = 1536535974,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alasan's Plot",
                ["y"] = 0.3558725417,
            },
            [25] = 
            {
                ["giver"] = "Jeromec Lemal",
                ["x"] = 0.5701867342,
                ["otherInfo"] = 
                {
                    ["time"] = 1536536153,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Warship Designs",
                ["y"] = 0.3352153301,
            },
            [26] = 
            {
                ["preQuest"] = 2222,
                ["giver"] = "Shiri",
                ["x"] = 0.5660890937,
                ["otherInfo"] = 
                {
                    ["time"] = 1536554353,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Shiri's Research",
                ["y"] = 0.3564052880,
            },
            [27] = 
            {
                ["preQuest"] = 2240,
                ["giver"] = "Captain Rawan",
                ["x"] = 0.7369155884,
                ["otherInfo"] = 
                {
                    ["time"] = 1536617240,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Search for Shiri",
                ["y"] = 0.5097684860,
            },
            [28] = 
            {
                ["giver"] = "General Thoda",
                ["x"] = 0.8402663469,
                ["otherInfo"] = 
                {
                    ["time"] = 1536617590,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Imperial Incursion",
                ["y"] = 0.3919790983,
            },
            [29] = 
            {
                ["giver"] = "High Priest Zuladr",
                ["x"] = 0.8084615469,
                ["otherInfo"] = 
                {
                    ["time"] = 1536618662,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Temple's Treasures",
                ["y"] = 0.3394672573,
            },
            [30] = 
            {
                ["preQuest"] = 2404,
                ["giver"] = "General Thoda",
                ["x"] = 0.8407717347,
                ["otherInfo"] = 
                {
                    ["time"] = 1536622233,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Amputating the Hand",
                ["y"] = 0.3409484625,
            },
            [31] = 
            {
                ["preQuest"] = 2997,
                ["giver"] = "Ansei Halelah",
                ["x"] = 0.7744261622,
                ["otherInfo"] = 
                {
                    ["time"] = 1536637029,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Restoring the Ansei Wards",
                ["y"] = 0.2969753444,
            },
        },
        ["alikr/salasen_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Gurlak",
                ["x"] = 0.2225854546,
                ["otherInfo"] = 
                {
                    ["time"] = 1536021367,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Oldest Orc",
                ["y"] = 0.7185712457,
            },
        },
        ["alikr/coldrockdiggings_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Promissory Note",
                ["x"] = 0.6747359037,
                ["otherInfo"] = 
                {
                    ["time"] = 1536546333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Past Due",
                ["y"] = 0.3042840362,
            },
        },
        ["deshaan/deshaan_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Risa's Journal",
                ["x"] = 0.6753426790,
                ["otherInfo"] = 
                {
                    ["time"] = 1536986793,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Remembering Risa",
                ["y"] = 0.5704402328,
            },
        },
        ["vvardenfell/sadrithmora_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Eoki",
                ["x"] = 0.2976600230,
                ["otherInfo"] = 
                {
                    ["time"] = 1536778382,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Hireling of House Telvanni",
                ["y"] = 0.4552703798,
            },
            [2] = 
            {
                ["giver"] = "Llonas Givyn",
                ["x"] = 0.3116475642,
                ["otherInfo"] = 
                {
                    ["time"] = 1536778413,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Bound by Love",
                ["y"] = 0.5542289615,
            },
            [3] = 
            {
                ["preQuest"] = 5799,
                ["giver"] = "Eoki",
                ["x"] = 0.3429779112,
                ["otherInfo"] = 
                {
                    ["time"] = 1536896431,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Rising to Retainer",
                ["y"] = 0.3695585728,
            },
        },
        ["vvardenfell/vvardenfell_base"] = 
        {
            [4] = 
            {
                ["preQuest"] = 5881,
                ["giver"] = "Deminah Salvi",
                ["x"] = 0.4003142416,
                ["otherInfo"] = 
                {
                    ["time"] = 1536966177,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Breaking Through the Fog",
                ["y"] = 0.8341385722,
            },
            [1] = 
            {
                ["giver"] = "Avo Elarven",
                ["x"] = 0.6053663492,
                ["otherInfo"] = 
                {
                    ["time"] = 1536797695,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Scarlet Judge",
                ["y"] = 0.7837001085,
            },
            [2] = 
            {
                ["giver"] = "Buoyant Armiger",
                ["x"] = 0.7578663826,
                ["otherInfo"] = 
                {
                    ["time"] = 1536863121,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "An Armiger's Duty",
                ["y"] = 0.7866915464,
            },
            [3] = 
            {
                ["giver"] = "Halinjirr",
                ["x"] = 0.3934557736,
                ["otherInfo"] = 
                {
                    ["time"] = 1536963658,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Hidden Harvest",
                ["y"] = 0.7889339924,
            },
        },
        ["summerset/collegeofpsijicsruins_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Relicmaster Glenadir",
                ["x"] = 0.5981447697,
                ["otherInfo"] = 
                {
                    ["time"] = 1535331338,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Vault of Moawita",
                ["y"] = 0.4317321479,
            },
        },
        ["alikr/divadschagrinmine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Armin",
                ["x"] = 0.1543603837,
                ["otherInfo"] = 
                {
                    ["time"] = 1536357513,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Search is Over",
                ["y"] = 0.5220297575,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4901,
                ["giver"] = "Darien Gautier",
                ["x"] = 0.4597792029,
                ["otherInfo"] = 
                {
                    ["time"] = 1534398094,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Shornhelm Divided",
                ["y"] = 0.7394628525,
            },
            [2] = 
            {
                ["giver"] = "Daribert Hurier",
                ["x"] = 0.4797356725,
                ["otherInfo"] = 
                {
                    ["time"] = 1534398418,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Under Siege",
                ["y"] = 0.6906269193,
            },
            [3] = 
            {
                ["giver"] = "Scholar Cantier",
                ["x"] = 0.5490812063,
                ["otherInfo"] = 
                {
                    ["time"] = 1534458595,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Traitor's Tale",
                ["y"] = 0.5729492903,
            },
            [4] = 
            {
                ["preQuest"] = 3286,
                ["giver"] = "Jowan Hinault",
                ["x"] = 0.4653404057,
                ["otherInfo"] = 
                {
                    ["time"] = 1534458893,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Dearly Departed",
                ["y"] = 0.6188712120,
            },
            [5] = 
            {
                ["giver"] = "Bumnog",
                ["x"] = 0.3692457676,
                ["otherInfo"] = 
                {
                    ["time"] = 1534547666,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Rusty Daggers",
                ["y"] = 0.6888028383,
            },
            [6] = 
            {
                ["preQuest"] = 5012,
                ["giver"] = "Nathalye Ervine",
                ["x"] = 0.2783106267,
                ["otherInfo"] = 
                {
                    ["time"] = 1534553708,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "In the Doghouse",
                ["y"] = 0.6280971169,
            },
            [7] = 
            {
                ["giver"] = "Michel Gette",
                ["x"] = 0.2556575239,
                ["otherInfo"] = 
                {
                    ["time"] = 1534553764,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Blood-Cursed Town",
                ["y"] = 0.6459167004,
            },
            [8] = 
            {
                ["preQuest"] = 4903,
                ["giver"] = "Count Verandis Ravenwatch",
                ["x"] = 0.2930417359,
                ["otherInfo"] = 
                {
                    ["time"] = 1534567301,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Blood-Splattered Shield",
                ["y"] = 0.4514686763,
            },
            [9] = 
            {
                ["preQuest"] = 465,
                ["giver"] = "Gwendis",
                ["x"] = 0.2146217972,
                ["otherInfo"] = 
                {
                    ["time"] = 1534627281,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Concealing Veil",
                ["y"] = 0.6468122602,
            },
            [10] = 
            {
                ["giver"] = "Federic Seychelle",
                ["x"] = 0.6914007068,
                ["otherInfo"] = 
                {
                    ["time"] = 1534627498,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Change of Heart",
                ["y"] = 0.4664203823,
            },
            [11] = 
            {
                ["preQuest"] = 4857,
                ["giver"] = "Count Verandis Ravenwatch",
                ["x"] = 0.5995568037,
                ["otherInfo"] = 
                {
                    ["time"] = 1534631512,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Northpoint in Peril",
                ["y"] = 0.4809440672,
            },
            [12] = 
            {
                ["giver"] = "Alvaren Garoutte",
                ["x"] = 0.5871042013,
                ["otherInfo"] = 
                {
                    ["time"] = 1534631587,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Archaic Relics",
                ["y"] = 0.5149237514,
            },
            [13] = 
            {
                ["giver"] = "Marisette",
                ["x"] = 0.6284329295,
                ["otherInfo"] = 
                {
                    ["time"] = 1534634478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Crimes of the Past",
                ["y"] = 0.6254729033,
            },
            [14] = 
            {
                ["giver"] = "Adusa-daro",
                ["x"] = 0.6064910293,
                ["otherInfo"] = 
                {
                    ["time"] = 1534634772,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Hope Lost",
                ["y"] = 0.6622117758,
            },
            [15] = 
            {
                ["giver"] = "Strange Sapling",
                ["x"] = 0.6333553791,
                ["otherInfo"] = 
                {
                    ["time"] = 1534651278,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Price of Longevity",
                ["y"] = 0.5597689748,
            },
            [16] = 
            {
                ["preQuest"] = 4926,
                ["giver"] = "Adusa-daro",
                ["x"] = 0.2959030271,
                ["otherInfo"] = 
                {
                    ["time"] = 1534736590,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Assassin's List",
                ["y"] = 0.4603060186,
            },
            [17] = 
            {
                ["giver"] = "Lieutenant Sgugh",
                ["x"] = 0.2673034668,
                ["otherInfo"] = 
                {
                    ["time"] = 1534737005,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Sanctifying Flames",
                ["y"] = 0.6350313425,
            },
            [18] = 
            {
                ["preQuest"] = 4927,
                ["giver"] = "Adusa-daro",
                ["x"] = 0.2859297097,
                ["otherInfo"] = 
                {
                    ["time"] = 1534737994,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Threat of Death",
                ["y"] = 0.4686428905,
            },
            [19] = 
            {
                ["preQuest"] = 4928,
                ["giver"] = "Adusa-daro",
                ["x"] = 0.2863873839,
                ["otherInfo"] = 
                {
                    ["time"] = 1534738422,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Dagger to the Heart",
                ["y"] = 0.4693705440,
            },
            [20] = 
            {
                ["preQuest"] = 4965,
                ["giver"] = "Constable Agazu",
                ["x"] = 0.6877788305,
                ["otherInfo"] = 
                {
                    ["time"] = 1534742538,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Frightened Folk",
                ["y"] = 0.4420057237,
            },
            [21] = 
            {
                ["preQuest"] = 4931,
                ["giver"] = "Constable Agazu",
                ["x"] = 0.7006397247,
                ["otherInfo"] = 
                {
                    ["time"] = 1534810643,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Fell's Justice",
                ["y"] = 0.4126192331,
            },
            [22] = 
            {
                ["preQuest"] = 5312,
                ["giver"] = "Beryn",
                ["x"] = 0.1827658564,
                ["otherInfo"] = 
                {
                    ["time"] = 1534831726,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Spider's Cocoon",
                ["y"] = 0.6250448823,
            },
            [23] = 
            {
                ["giver"] = "Lothson Cold-Eye",
                ["x"] = 0.7315177917,
                ["otherInfo"] = 
                {
                    ["time"] = 1534913311,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Lady's Keepsake",
                ["y"] = 0.2306008041,
            },
            [24] = 
            {
                ["giver"] = "Lady Clarisse Laurent",
                ["x"] = 0.6774894595,
                ["otherInfo"] = 
                {
                    ["time"] = 1534983366,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Emerald Chalice",
                ["y"] = 0.2659831345,
            },
            [25] = 
            {
                ["preQuest"] = 4884,
                ["giver"] = "Gwendis",
                ["x"] = 0.3189841807,
                ["otherInfo"] = 
                {
                    ["time"] = 1534999198,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Crown of Shornhelm",
                ["y"] = 0.3771019280,
            },
        },
        ["rivenspire/crestshademine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Troll Socialization Research Notes",
                ["x"] = 0.4132508039,
                ["otherInfo"] = 
                {
                    ["time"] = 1534624071,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Friend of Trolls",
                ["y"] = 0.3638949394,
            },
        },
        ["rivenspire/erokii_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Anenya",
                ["x"] = 0.7498008013,
                ["otherInfo"] = 
                {
                    ["time"] = 1535001830,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Ancient Power",
                ["y"] = 0.3673306704,
            },
        },
        ["reapersmarch/reapersmarch_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Ancient Scroll",
                ["x"] = 0.6639211178,
                ["otherInfo"] = 
                {
                    ["time"] = 1536288690,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Hircine's Gift",
                ["y"] = 0.2042936236,
            },
        },
        ["summerset/shimmerene_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Calibar",
                ["x"] = 0.2751390040,
                ["otherInfo"] = 
                {
                    ["time"] = 1534970964,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Queen's Decree",
                ["y"] = 0.6924549937,
            },
            [2] = 
            {
                ["preQuest"] = 5283,
                ["giver"] = "Calibar",
                ["x"] = 0.2323507369,
                ["otherInfo"] = 
                {
                    ["time"] = 1535086542,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Queen's Decree",
                ["y"] = 0.6622093320,
            },
            [3] = 
            {
                ["giver"] = "Lanarie",
                ["x"] = 0.6734209061,
                ["otherInfo"] = 
                {
                    ["time"] = 1535148723,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Tale of Two Mothers",
                ["y"] = 0.6188374758,
            },
        },
        ["summerset/dreamingcave01_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6109,
                ["giver"] = "Ritemaster Iachesis",
                ["x"] = 0.5636072755,
                ["otherInfo"] = 
                {
                    ["time"] = 1535752808,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Lost in Translation",
                ["y"] = 0.5473768711,
            },
            [2] = 
            {
                ["preQuest"] = 6113,
                ["giver"] = "Oriandra",
                ["x"] = 0.3942164779,
                ["otherInfo"] = 
                {
                    ["time"] = 1535755815,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Necessary Alliance",
                ["y"] = 0.3588981628,
            },
            [3] = 
            {
                ["preQuest"] = 6126,
                ["giver"] = "Valsirenn",
                ["x"] = 0.7556292415,
                ["otherInfo"] = 
                {
                    ["time"] = 1535778626,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A New Alliance",
                ["y"] = 0.5018859506,
            },
        },
        ["grahtwood/eldenrootgroundfloor_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6022,
                ["giver"] = "Sealed Woodworking Writ",
                ["x"] = 0.7304733396,
                ["otherInfo"] = 
                {
                    ["time"] = 1534216349,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Shield",
                ["y"] = 0.6416119933,
            },
            [2] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["x"] = 0.7304733396,
                ["otherInfo"] = 
                {
                    ["time"] = 1534216360,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Glyph",
                ["y"] = 0.6416119933,
            },
            [3] = 
            {
                ["preQuest"] = 6228,
                ["giver"] = "Sealed Alchemy Writ",
                ["x"] = 0.7366622090,
                ["otherInfo"] = 
                {
                    ["time"] = 1536277342,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Concoction",
                ["y"] = 0.6324936152,
            },
            [4] = 
            {
                ["giver"] = "Sealed Blacksmithing Writ",
                ["x"] = 0.7366622090,
                ["otherInfo"] = 
                {
                    ["time"] = 1536277352,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Weapon",
                ["y"] = 0.6324936152,
            },
            [5] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["x"] = 0.7366622090,
                ["otherInfo"] = 
                {
                    ["time"] = 1536277364,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Glyph",
                ["y"] = 0.6324936152,
            },
            [6] = 
            {
                ["preQuest"] = 5973,
                ["giver"] = "Sealed Enchanting Writ",
                ["x"] = 0.7290217876,
                ["otherInfo"] = 
                {
                    ["time"] = 1536278199,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Glyph",
                ["y"] = 0.6388408542,
            },
        },
        ["clockwork/clockworkoutlawsrefuge_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Brengolin",
                ["x"] = 0.8880208135,
                ["otherInfo"] = 
                {
                    ["time"] = 1536034433,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Tarnished Truffles",
                ["y"] = 0.3236269057,
            },
            [2] = 
            {
                ["preQuest"] = 6059,
                ["giver"] = "Brengolin",
                ["x"] = 0.8927556872,
                ["otherInfo"] = 
                {
                    ["time"] = 1536097307,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Tasty Tongue Varnish",
                ["y"] = 0.3177083433,
            },
            [3] = 
            {
                ["preQuest"] = 6060,
                ["giver"] = "Brengolin",
                ["x"] = 0.8754734993,
                ["otherInfo"] = 
                {
                    ["time"] = 1536098581,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Matter of Tenderness",
                ["y"] = 0.3283617496,
            },
        },
        ["glenumbra/daggerfall_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 3039,
                ["giver"] = "Swineherd Wickton",
                ["x"] = 0.4550656676,
                ["otherInfo"] = 
                {
                    ["time"] = 1533677832,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Swine Thief",
                ["y"] = 0.3237193525,
            },
            [2] = 
            {
                ["giver"] = "Mighty Mordra",
                ["x"] = 0.5131012201,
                ["otherInfo"] = 
                {
                    ["time"] = 1533677886,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "One of the Undaunted",
                ["y"] = 0.2878405750,
            },
            [3] = 
            {
                ["giver"] = "Felande Demarie",
                ["x"] = 0.4846858084,
                ["otherInfo"] = 
                {
                    ["time"] = 1533678341,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Room to Spare",
                ["y"] = 0.2740499675,
            },
            [4] = 
            {
                ["preQuest"] = 3011,
                ["giver"] = "Beggar Matthew",
                ["x"] = 0.5158903599,
                ["otherInfo"] = 
                {
                    ["time"] = 1533679195,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Back-Alley Murders",
                ["y"] = 0.5736614466,
            },
            [5] = 
            {
                ["giver"] = "Vanus Galerion",
                ["x"] = 0.4713554382,
                ["otherInfo"] = 
                {
                    ["time"] = 1535244755,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Through a Veil Darkly",
                ["y"] = 0.4101165533,
            },
            [6] = 
            {
                ["preQuest"] = 3916,
                ["giver"] = "Arch-Mage Shalidor",
                ["x"] = 0.5207746625,
                ["otherInfo"] = 
                {
                    ["time"] = 1535850142,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Simply Misplaced",
                ["y"] = 0.3904083073,
            },
            [7] = 
            {
                ["preQuest"] = 3953,
                ["giver"] = "Arch-Mage Shalidor",
                ["x"] = 0.5224900842,
                ["otherInfo"] = 
                {
                    ["time"] = 1535871355,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Mad God's Bargain",
                ["y"] = 0.3899323344,
            },
        },
        ["rivenspire/northpoint_base"] = 
        {
            [4] = 
            {
                ["preQuest"] = 4916,
                ["giver"] = "Blademaster Qariar",
                ["x"] = 0.3138366342,
                ["otherInfo"] = 
                {
                    ["time"] = 1534915414,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Last of Them",
                ["y"] = 0.5237141848,
            },
            [1] = 
            {
                ["preQuest"] = 4958,
                ["giver"] = "Skordo the Knife",
                ["x"] = 0.4576599598,
                ["otherInfo"] = 
                {
                    ["time"] = 1534897233,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Liberation of Northpoint",
                ["y"] = 0.1727312952,
            },
            [2] = 
            {
                ["preQuest"] = 4972,
                ["giver"] = "Baron Alard Dorell",
                ["x"] = 0.5080171227,
                ["otherInfo"] = 
                {
                    ["time"] = 1534915013,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Puzzle of the Pass",
                ["y"] = 0.5755673051,
            },
            [3] = 
            {
                ["giver"] = "Short-Tail",
                ["x"] = 0.6390510201,
                ["otherInfo"] = 
                {
                    ["time"] = 1534915193,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Guar Gone",
                ["y"] = 0.4246223271,
            },
        },
        ["auridon/bewan_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Altmeri Relic",
                ["x"] = 0.5038520694,
                ["otherInfo"] = 
                {
                    ["time"] = 1535248036,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Lost Bet",
                ["y"] = 0.6983050704,
            },
        },
        ["grahtwood/eldenhollow_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4107,
                ["giver"] = "Bakkhara",
                ["x"] = 0.3663927019,
                ["otherInfo"] = 
                {
                    ["time"] = 1536199213,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Ancient Remains",
                ["y"] = 0.5466459394,
            },
        },
        ["alikr/sandblownmine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Letter to Fadeel",
                ["x"] = 0.5561488867,
                ["otherInfo"] = 
                {
                    ["time"] = 1536431569,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Real Snake",
                ["y"] = 0.4986650050,
            },
        },
        ["alikr/santaki_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4659,
                ["giver"] = "Tharayya Journal Entry: 2",
                ["x"] = 0.5429641008,
                ["otherInfo"] = 
                {
                    ["time"] = 1536024066,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Tharayya's Trail",
                ["y"] = 0.4405688643,
            },
        },
        ["summerset/alinor_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6097,
                ["giver"] = "Vandoril",
                ["x"] = 0.2997643054,
                ["otherInfo"] = 
                {
                    ["time"] = 1535250228,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Checking on Cloudrest",
                ["y"] = 0.6473568082,
            },
            [2] = 
            {
                ["giver"] = "Roguzog",
                ["x"] = 0.2337974161,
                ["otherInfo"] = 
                {
                    ["time"] = 1535250333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Duelist's Dilemma",
                ["y"] = 0.4404526651,
            },
            [3] = 
            {
                ["giver"] = "Battlereeve Tanerline",
                ["x"] = 0.6147393584,
                ["otherInfo"] = 
                {
                    ["time"] = 1535602223,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Abyssal Cabal",
                ["y"] = 0.5066245198,
            },
            [4] = 
            {
                ["giver"] = "Rigurt the Brash",
                ["x"] = 0.6475471258,
                ["otherInfo"] = 
                {
                    ["time"] = 1535602261,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Culture Clash",
                ["y"] = 0.5052776337,
            },
            [5] = 
            {
                ["preQuest"] = 6165,
                ["giver"] = "Battlereeve Tanerline",
                ["x"] = 0.4284041226,
                ["otherInfo"] = 
                {
                    ["time"] = 1535676619,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Sinking Summerset",
                ["y"] = 0.7019631863,
            },
            [6] = 
            {
                ["preQuest"] = 4961,
                ["giver"] = "Millenith",
                ["x"] = 0.5599572659,
                ["otherInfo"] = 
                {
                    ["time"] = 1536297803,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Crafting Certification",
                ["y"] = 0.6079903841,
            },
            [7] = 
            {
                ["preQuest"] = 5259,
                ["giver"] = "Millenith",
                ["x"] = 0.5599572659,
                ["otherInfo"] = 
                {
                    ["time"] = 1536297818,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Certification",
                ["y"] = 0.6079903841,
            },
            [8] = 
            {
                ["preQuest"] = 5249,
                ["giver"] = "Millenith",
                ["x"] = 0.5654178858,
                ["otherInfo"] = 
                {
                    ["time"] = 1536369985,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Certification",
                ["y"] = 0.6068924069,
            },
        },
        ["rivenspire/shornhelm_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4902,
                ["giver"] = "High King Emeric",
                ["x"] = 0.5924155712,
                ["otherInfo"] = 
                {
                    ["time"] = 1534547100,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Dream-Walk Into Darkness",
                ["y"] = 0.2087104321,
            },
            [2] = 
            {
                ["preQuest"] = 4834,
                ["giver"] = "Adusa-daro",
                ["x"] = 0.5225196481,
                ["otherInfo"] = 
                {
                    ["time"] = 1534720776,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Spy in Shornhelm",
                ["y"] = 0.3165285885,
            },
            [3] = 
            {
                ["giver"] = "Nicolene",
                ["x"] = 0.4601444602,
                ["otherInfo"] = 
                {
                    ["time"] = 1534724812,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Children of Yokuda",
                ["y"] = 0.6325260401,
            },
            [4] = 
            {
                ["preQuest"] = 4945,
                ["giver"] = "Adusa-daro",
                ["x"] = 0.5138304830,
                ["otherInfo"] = 
                {
                    ["time"] = 1534735695,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Assassin Hunter",
                ["y"] = 0.3113873005,
            },
            [5] = 
            {
                ["preQuest"] = 4936,
                ["giver"] = "Queen Maraya",
                ["x"] = 0.6035054326,
                ["otherInfo"] = 
                {
                    ["time"] = 1535066382,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Favor for the Queen",
                ["y"] = 0.2218610644,
            },
            [6] = 
            {
                ["preQuest"] = 3918,
                ["giver"] = "Arch-Mage Shalidor",
                ["x"] = 0.3513490558,
                ["otherInfo"] = 
                {
                    ["time"] = 1535870022,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Chateau of the Ravenous Rodent",
                ["y"] = 0.6464839578,
            },
        },
        ["summerset/artaeum_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6096,
                ["giver"] = "Ritemaster Iachesis",
                ["x"] = 0.6434336305,
                ["otherInfo"] = 
                {
                    ["time"] = 1535331163,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Pearl of Great Price",
                ["y"] = 0.2702807188,
            },
            [2] = 
            {
                ["giver"] = "Ulliceta gra-Kogg",
                ["x"] = 0.3989331722,
                ["otherInfo"] = 
                {
                    ["time"] = 1535594843,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Half-Formed Understandings",
                ["y"] = 0.4446600974,
            },
        },
        ["summerset/ui_map"] = 
        {
            [1] = 
            {
                ["giver"] = "Olorime",
                ["x"] = 0.4132726490,
                ["otherInfo"] = 
                {
                    ["time"] = 1534294704,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woe of the Welkynars",
                ["y"] = 0.2734320164,
            },
        },
        ["alikr/bergama_base"] = 
        {
            [4] = 
            {
                ["preQuest"] = 2344,
                ["giver"] = "Jarrod",
                ["x"] = 0.7893781066,
                ["otherInfo"] = 
                {
                    ["time"] = 1536381627,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Trapped in the Bluffs",
                ["y"] = 0.2626455426,
            },
            [1] = 
            {
                ["preQuest"] = 3344,
                ["giver"] = "Qadim",
                ["x"] = 0.1632595807,
                ["otherInfo"] = 
                {
                    ["time"] = 1536373428,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Gone Missing",
                ["y"] = 0.5567598939,
            },
            [2] = 
            {
                ["giver"] = "Jagnas",
                ["x"] = 0.5938260555,
                ["otherInfo"] = 
                {
                    ["time"] = 1536376454,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Left at the Altar",
                ["y"] = 0.4496798813,
            },
            [3] = 
            {
                ["preQuest"] = 2251,
                ["giver"] = "Meriq",
                ["x"] = 0.5318244696,
                ["otherInfo"] = 
                {
                    ["time"] = 1536378812,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Trouble at Tava's Blessing",
                ["y"] = 0.4399827719,
            },
        },
        ["rivenspire/hildunessecretrefuge_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Nadafa's Journal",
                ["x"] = 0.6928258538,
                ["otherInfo"] = 
                {
                    ["time"] = 1534896674,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Love Lost",
                ["y"] = 0.3277197778,
            },
        },
        ["auridon/vulkhelguard_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6363090277,
            },
            [2] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6363090277,
            },
            [3] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033477,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6363090277,
            },
            [4] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5947007537,
            },
            [5] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5947007537,
            },
            [6] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5947007537,
            },
            [7] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5947007537,
            },
            [8] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6336819530,
            },
            [9] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6336819530,
            },
            [10] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196952,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6336819530,
            },
            [11] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5952637196,
            },
            [12] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5952637196,
            },
            [13] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5952637196,
            },
            [14] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214704,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5952637196,
            },
            [15] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6322933435,
            },
            [16] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6322933435,
            },
            [17] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214742,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6322933435,
            },
            [18] = 
            {
                ["preQuest"] = 6228,
                ["giver"] = "Sealed Clothier Writ",
                ["x"] = 0.3380454481,
                ["otherInfo"] = 
                {
                    ["time"] = 1534215666,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Masterful Leatherwear",
                ["y"] = 0.5761359334,
            },
            [19] = 
            {
                ["giver"] = "Sealed Alchemy Writ",
                ["x"] = 0.3380454481,
                ["otherInfo"] = 
                {
                    ["time"] = 1534215692,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Masterful Concoction",
                ["y"] = 0.5761359334,
            },
            [20] = 
            {
                ["preQuest"] = 5952,
                ["giver"] = "Battlemaster Rivyn",
                ["x"] = 0.5293735266,
                ["otherInfo"] = 
                {
                    ["time"] = 1535167121,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Test of Mettle",
                ["y"] = 0.5142739415,
            },
            [21] = 
            {
                ["preQuest"] = 5954,
                ["giver"] = "Battlemaster Rivyn",
                ["x"] = 0.5293610096,
                ["otherInfo"] = 
                {
                    ["time"] = 1535169644,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Let the Games Begin",
                ["y"] = 0.5142739415,
            },
            [22] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5972027779,
            },
            [23] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5972027779,
            },
            [24] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5972027779,
            },
            [25] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2266438156,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165506,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5972027779,
            },
            [26] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2808997333,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6320431232,
            },
            [27] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2808997333,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6320431232,
            },
            [28] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2808997333,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6320431232,
            },
            [29] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276305,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5947132707,
            },
            [30] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5947132707,
            },
            [31] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5947132707,
            },
            [32] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2246547192,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5947132707,
            },
            [33] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2842649221,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6298664212,
            },
            [34] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2842649221,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6298664212,
            },
            [35] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2842649221,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6298664212,
            },
            [36] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724534,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5956890583,
            },
            [37] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5956890583,
            },
            [38] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5956890583,
            },
            [39] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2244795859,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5956890583,
            },
            [40] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2820006013,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6317679286,
            },
            [41] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2820006013,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6317679286,
            },
            [42] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2820006013,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6317679286,
            },
            [43] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725827,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5962395072,
            },
            [44] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725827,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5962395072,
            },
            [45] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5962395072,
            },
            [46] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2239916921,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5962395072,
            },
            [47] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2839646637,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725860,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6304793954,
            },
            [48] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2839646637,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725861,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6304793954,
            },
            [49] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2839646637,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725861,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6304793954,
            },
            [50] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2822132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6361964345,
            },
            [51] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2822132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6361964345,
            },
            [52] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2822132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6361964345,
            },
            [53] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.5950009823,
            },
            [54] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5950009823,
            },
            [55] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5950009823,
            },
            [56] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2263310701,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5950009823,
            },
        },
        ["rivenspire/flyleafcatacombs_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4942,
                ["giver"] = "Handre's Last Will",
                ["x"] = 0.3211788237,
                ["otherInfo"] = 
                {
                    ["time"] = 1534832824,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Fadeel's Freedom",
                ["y"] = 0.1988012046,
            },
        },
        ["stormhaven/koeglinvillage_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 3412,
                ["giver"] = "Dame Dabienne",
                ["x"] = 0.3885127902,
                ["otherInfo"] = 
                {
                    ["time"] = 1533765631,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "False Accusations",
                ["y"] = 0.3335759938,
            },
            [2] = 
            {
                ["preQuest"] = 2494,
                ["giver"] = "Margot Oscent",
                ["x"] = 0.6060275435,
                ["otherInfo"] = 
                {
                    ["time"] = 1533769172,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Slavers",
                ["y"] = 0.5187935233,
            },
            [3] = 
            {
                ["preQuest"] = 2556,
                ["giver"] = "Dame Dabienne",
                ["x"] = 0.3553662896,
                ["otherInfo"] = 
                {
                    ["time"] = 1533775980,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "To Alcaire Castle",
                ["y"] = 0.3445196748,
            },
        },
        ["glenumbra/ilessantower_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Red Rook Note",
                ["x"] = 0.5450952053,
                ["otherInfo"] = 
                {
                    ["time"] = 1533684860,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Red Rook Resources",
                ["y"] = 0.7700323462,
            },
        },
        ["stormhaven/wayrest_base"] = 
        {
            [1] = 
            {
                ["giver"] = "M'jaddha",
                ["x"] = 0.4391658008,
                ["otherInfo"] = 
                {
                    ["time"] = 1534116513,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Debt Collector's Debts",
                ["y"] = 0.1780604571,
            },
            [2] = 
            {
                ["giver"] = "Sergeant Stegine",
                ["x"] = 0.2756144106,
                ["otherInfo"] = 
                {
                    ["time"] = 1534125955,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Dreugh Threat",
                ["y"] = 0.1300478876,
            },
            [3] = 
            {
                ["preQuest"] = 2068,
                ["giver"] = "Adiel Charnis",
                ["x"] = 0.2342794538,
                ["otherInfo"] = 
                {
                    ["time"] = 1534127126,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "They Dragged Him Away",
                ["y"] = 0.0535364039,
            },
            [4] = 
            {
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.3749423027,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Clothier Writ",
                ["y"] = 0.2255538255,
            },
            [5] = 
            {
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.3749423027,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.2255538255,
            },
            [6] = 
            {
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.3749423027,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Woodworker Writ",
                ["y"] = 0.2255538255,
            },
            [7] = 
            {
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.3749423027,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196577,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.2255538255,
            },
            [8] = 
            {
                ["giver"] = "Janne Marolles",
                ["x"] = 1.0325227976,
                ["otherInfo"] = 
                {
                    ["time"] = 1534283292,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Old Adventurers",
                ["y"] = 0.2736096680,
            },
            [9] = 
            {
                ["preQuest"] = 1615,
                ["giver"] = "Eldrasea Deras",
                ["x"] = 0.6182646751,
                ["otherInfo"] = 
                {
                    ["time"] = 1534367222,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "To The Clockwork City",
                ["y"] = 0.3309824765,
            },
            [10] = 
            {
                ["preQuest"] = 521,
                ["giver"] = "Abbot Durak",
                ["x"] = 0.4303103685,
                ["otherInfo"] = 
                {
                    ["time"] = 1534373250,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Vaermina's Gambit",
                ["y"] = 0.4614630342,
            },
            [11] = 
            {
                ["preQuest"] = 575,
                ["giver"] = "High King Emeric",
                ["x"] = 0.3795575202,
                ["otherInfo"] = 
                {
                    ["time"] = 1534374724,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Road to Rivenspire",
                ["y"] = 0.4613187909,
            },
            [12] = 
            {
                ["giver"] = "Urgarlag Chief-bane",
                ["x"] = 0.1636523604,
                ["otherInfo"] = 
                {
                    ["time"] = 1534387635,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Moon Hunter Keep",
                ["y"] = 0.5017451048,
            },
            [13] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1531094909,
                ["otherInfo"] = 
                {
                    ["time"] = 1534903120,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Fungal Grotto I",
                ["y"] = 0.4949232638,
            },
            [14] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1525470167,
                ["otherInfo"] = 
                {
                    ["time"] = 1534905260,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Fungal Grotto I",
                ["y"] = 0.4953559339,
            },
            [15] = 
            {
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1517682076,
                ["otherInfo"] = 
                {
                    ["time"] = 1535077586,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Crypt of Hearts I",
                ["y"] = 0.4776739478,
            },
            [16] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1553738266,
                ["otherInfo"] = 
                {
                    ["time"] = 1535077599,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Darkshade Caverns I",
                ["y"] = 0.4947213531,
            },
            [17] = 
            {
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1539315730,
                ["otherInfo"] = 
                {
                    ["time"] = 1535399588,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Vaults of Madness",
                ["y"] = 0.4767653048,
            },
            [18] = 
            {
                ["giver"] = "Alvur Baren",
                ["x"] = 0.5489355922,
                ["otherInfo"] = 
                {
                    ["time"] = 1535850518,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Madness in Reaper's March",
                ["y"] = 0.4954713285,
            },
            [19] = 
            {
                ["preQuest"] = 4435,
                ["giver"] = "Arch-Mage Shalidor",
                ["x"] = 0.5344698429,
                ["otherInfo"] = 
                {
                    ["time"] = 1535851711,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Circus of Cheerful Slaughter",
                ["y"] = 0.4661936164,
            },
            [20] = 
            {
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1524027884,
                ["otherInfo"] = 
                {
                    ["time"] = 1536110391,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Crypt of Hearts I",
                ["y"] = 0.4758134186,
            },
            [21] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1557199657,
                ["otherInfo"] = 
                {
                    ["time"] = 1536110402,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: Darkshade Caverns I",
                ["y"] = 0.4946204126,
            },
            [22] = 
            {
                ["giver"] = "Urgarlag Chief-bane",
                ["x"] = 0.1639984995,
                ["otherInfo"] = 
                {
                    ["time"] = 1536470819,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Pledge: White-Gold Tower",
                ["y"] = 0.5108312964,
            },
        },
        ["summerset/lillandrill_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Tindoria",
                ["x"] = 0.3591848612,
                ["otherInfo"] = 
                {
                    ["time"] = 1535503983,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Perils of Art",
                ["y"] = 0.8553342223,
            },
            [1] = 
            {
                ["giver"] = "Faralan",
                ["x"] = 0.5875323415,
                ["otherInfo"] = 
                {
                    ["time"] = 1535493532,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Murder In Lillandril",
                ["y"] = 0.6400873661,
            },
        },
        ["summerset/dreamingcave02_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.4700719118,
                ["otherInfo"] = 
                {
                    ["time"] = 1535410158,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Psijics' Calling",
                ["y"] = 0.4740376472,
            },
            [2] = 
            {
                ["preQuest"] = 6172,
                ["giver"] = "Josajeh",
                ["x"] = 0.2159475535,
                ["otherInfo"] = 
                {
                    ["time"] = 1535593687,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Breaches On the Bay",
                ["y"] = 0.6987097859,
            },
            [3] = 
            {
                ["preQuest"] = 6125,
                ["giver"] = "Valsirenn",
                ["x"] = 0.4051924646,
                ["otherInfo"] = 
                {
                    ["time"] = 1535773627,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Crystal Tower",
                ["y"] = 0.4301501811,
            },
            [4] = 
            {
                ["preQuest"] = 6181,
                ["giver"] = "Josajeh",
                ["x"] = 0.2083333284,
                ["otherInfo"] = 
                {
                    ["time"] = 1536722193,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Breaches of Frost and Fire",
                ["y"] = 0.6967005134,
            },
            [5] = 
            {
                ["preQuest"] = 6185,
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.7799809575,
                ["otherInfo"] = 
                {
                    ["time"] = 1536983304,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Shattered Staff",
                ["y"] = 0.4353320599,
            },
            [6] = 
            {
                ["preQuest"] = 6197,
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.7763853669,
                ["otherInfo"] = 
                {
                    ["time"] = 1536987133,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Breach Amid the Trees",
                ["y"] = 0.3812923133,
            },
            [7] = 
            {
                ["preQuest"] = 6194,
                ["giver"] = "Josajeh",
                ["x"] = 0.2544944882,
                ["otherInfo"] = 
                {
                    ["time"] = 1537064293,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Time for Mud and Mushrooms",
                ["y"] = 0.8366116881,
            },
            [8] = 
            {
                ["preQuest"] = 6190,
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.8109136820,
                ["otherInfo"] = 
                {
                    ["time"] = 1537150686,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Towers' Remains",
                ["y"] = 0.4661061764,
            },
            [9] = 
            {
                ["preQuest"] = 6198,
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.7952094078,
                ["otherInfo"] = 
                {
                    ["time"] = 1537156099,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Time in Doomcrag's Shadow",
                ["y"] = 0.4019670188,
            },
            [10] = 
            {
                ["preQuest"] = 6195,
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.8043041229,
                ["otherInfo"] = 
                {
                    ["time"] = 1537158261,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "A Breach Beyond the Crags",
                ["y"] = 0.3982656598,
            },
            [11] = 
            {
                ["preQuest"] = 6196,
                ["giver"] = "Loremaster Celarus",
                ["otherInfo"] = 
                {
                    ["time"] = 1537239403,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["x"] = 0.7910321355,
                ["name"] = "The Towers' Fall",
                ["y"] = 0.3783840835,
            },
        },
        ["summerset/summerset_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 6170,
                ["giver"] = "Silurie",
                ["x"] = 0.2925261259,
                ["otherInfo"] = 
                {
                    ["time"] = 1535251241,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Taste of Fear",
                ["y"] = 0.5346723199,
            },
            [2] = 
            {
                ["giver"] = "Celinar",
                ["x"] = 0.5957511067,
                ["otherInfo"] = 
                {
                    ["time"] = 1535255755,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Runaway's Tale",
                ["y"] = 0.5206859112,
            },
            [3] = 
            {
                ["preQuest"] = 6151,
                ["giver"] = "Hiranesse",
                ["x"] = 0.2685208023,
                ["otherInfo"] = 
                {
                    ["time"] = 1535261874,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Lost at Sea",
                ["y"] = 0.5220580101,
            },
            [4] = 
            {
                ["preQuest"] = 6149,
                ["giver"] = "Rinyde",
                ["x"] = 0.3724193871,
                ["otherInfo"] = 
                {
                    ["time"] = 1535263016,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Manor of Masques",
                ["y"] = 0.4847295582,
            },
            [5] = 
            {
                ["preQuest"] = 6114,
                ["giver"] = "Linwenvar",
                ["x"] = 0.4583003223,
                ["otherInfo"] = 
                {
                    ["time"] = 1535317497,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Old Wounds",
                ["y"] = 0.4649710059,
            },
            [6] = 
            {
                ["preQuest"] = 6135,
                ["giver"] = "Oriandra",
                ["x"] = 0.5359108448,
                ["otherInfo"] = 
                {
                    ["time"] = 1535320156,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Whispers from the Deep",
                ["y"] = 0.3748296201,
            },
            [7] = 
            {
                ["giver"] = "Andewen",
                ["x"] = 0.3586560786,
                ["otherInfo"] = 
                {
                    ["time"] = 1535338816,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Ebon Sanctum",
                ["y"] = 0.3742801845,
            },
            [8] = 
            {
                ["giver"] = "Merenfire",
                ["x"] = 0.3263515234,
                ["otherInfo"] = 
                {
                    ["time"] = 1535338862,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Illusions of Grandeur",
                ["y"] = 0.3584633172,
            },
            [9] = 
            {
                ["giver"] = "Amsha",
                ["x"] = 0.2576109469,
                ["otherInfo"] = 
                {
                    ["time"] = 1535339223,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Wasting Away",
                ["y"] = 0.2951898277,
            },
            [10] = 
            {
                ["giver"] = "Tableau",
                ["x"] = 0.3235512078,
                ["otherInfo"] = 
                {
                    ["time"] = 1535407539,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Hulkynd's Heart",
                ["y"] = 0.4748214185,
            },
            [11] = 
            {
                ["preQuest"] = 6146,
                ["giver"] = "Renzir",
                ["x"] = 0.2977776527,
                ["otherInfo"] = 
                {
                    ["time"] = 1535431714,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "An Unexpected Betrayal",
                ["y"] = 0.2113002241,
            },
            [12] = 
            {
                ["giver"] = "Talomar",
                ["x"] = 0.6750555038,
                ["otherInfo"] = 
                {
                    ["time"] = 1535505848,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Untamed and Unleashed",
                ["y"] = 0.6039851308,
            },
            [13] = 
            {
                ["preQuest"] = 6121,
                ["giver"] = "Igeke Rat-Bite",
                ["x"] = 0.7185612917,
                ["otherInfo"] = 
                {
                    ["time"] = 1535513267,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Gjadil's Legacy",
                ["y"] = 0.7324187160,
            },
            [14] = 
            {
                ["giver"] = "Manacar",
                ["x"] = 0.2794109285,
                ["otherInfo"] = 
                {
                    ["time"] = 1535562876,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Bantering with Bandits",
                ["y"] = 0.5546858907,
            },
            [15] = 
            {
                ["preQuest"] = 6140,
                ["giver"] = "Bailiff Erator",
                ["x"] = 0.5906194448,
                ["otherInfo"] = 
                {
                    ["time"] = 1535564644,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Lauriel's Lament",
                ["y"] = 0.3029791117,
            },
            [16] = 
            {
                ["giver"] = "Miranrel",
                ["x"] = 0.5512996912,
                ["otherInfo"] = 
                {
                    ["time"] = 1535576284,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Gryphon Grievance",
                ["y"] = 0.2825572789,
            },
            [17] = 
            {
                ["preQuest"] = 6179,
                ["giver"] = "Kinlady Ilunsare",
                ["x"] = 0.4651895463,
                ["otherInfo"] = 
                {
                    ["time"] = 1535577799,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Obedience Issues",
                ["y"] = 0.7353738546,
            },
            [18] = 
            {
                ["giver"] = "Pandermalion",
                ["x"] = 0.2621946633,
                ["otherInfo"] = 
                {
                    ["time"] = 1535660442,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Storming the Walls",
                ["y"] = 0.4188621342,
            },
        },
        ["glenumbra/crosswych_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 3337,
                ["giver"] = "Tamien Sellan",
                ["x"] = 0.6166941524,
                ["otherInfo"] = 
                {
                    ["time"] = 1533595782,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Miners' Lament",
                ["y"] = 0.6053073406,
            },
            [2] = 
            {
                ["preQuest"] = 3302,
                ["giver"] = "Tamien Sellan",
                ["x"] = 0.6395968795,
                ["otherInfo"] = 
                {
                    ["time"] = 1533596819,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Crosswych Reclaimed",
                ["y"] = 0.6034337878,
            },
            [3] = 
            {
                ["giver"] = "Alessio Guillon",
                ["x"] = 0.6025131345,
                ["otherInfo"] = 
                {
                    ["time"] = 1533608597,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "The Missing Prophecy",
                ["y"] = 0.5922731757,
            },
            [4] = 
            {
                ["giver"] = "Bera Moorsmith",
                ["x"] = 0.5974093080,
                ["otherInfo"] = 
                {
                    ["time"] = 1533608894,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Anchors from the Harbour",
                ["y"] = 0.5522983670,
            },
            [5] = 
            {
                ["giver"] = "Adelle Montagne",
                ["x"] = 0.4721064568,
                ["otherInfo"] = 
                {
                    ["time"] = 1533609272,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Long Lost Lore",
                ["y"] = 0.6174532175,
            },
        },
        ["rivenspire/hoarfrost_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Captain Thayer",
                ["x"] = 0.4679913223,
                ["otherInfo"] = 
                {
                    ["time"] = 1534631769,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Wayward Son",
                ["y"] = 0.5418079495,
            },
            [2] = 
            {
                ["preQuest"] = 5020,
                ["giver"] = "Captain Thayer",
                ["x"] = 0.3932930827,
                ["otherInfo"] = 
                {
                    ["time"] = 1534634333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Bandit",
                ["y"] = 0.5901261568,
            },
            [3] = 
            {
                ["preQuest"] = 5022,
                ["giver"] = "Captain Thayer",
                ["x"] = 0.4004475772,
                ["otherInfo"] = 
                {
                    ["time"] = 1534650828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Lover",
                ["y"] = 0.5798182487,
            },
        },
        ["stormhaven/portdunwatch_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Remy Berard",
                ["x"] = 0.4718382061,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943190,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Do as I Say",
                ["y"] = 0.3056835532,
            },
        },
        ["rivenspire/shroudedpass_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 5024,
                ["giver"] = "Count Verandis Ravenwatch",
                ["x"] = 0.2278132588,
                ["otherInfo"] = 
                {
                    ["time"] = 1534996733,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "The Lightless Remnant",
                ["y"] = 0.2501651645,
            },
        },
        ["stonefalls/fungalgrotto_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Vila Theran",
                ["x"] = 0.3413615227,
                ["otherInfo"] = 
                {
                    ["time"] = 1534903204,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Kings of the Grotto",
                ["y"] = 0.7768288851,
            },
        },
        ["vvardenfell/vivecthroneroom01_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 5803,
                ["giver"] = "Vivec",
                ["x"] = 0.4857364297,
                ["otherInfo"] = 
                {
                    ["time"] = 1536777197,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Divine Inquiries",
                ["y"] = 0.6491472721,
            },
        },
        ["stormhaven/bearclawmine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Hubert",
                ["x"] = 0.3204819262,
                ["otherInfo"] = 
                {
                    ["time"] = 1534364051,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Next of Kin",
                ["y"] = 0.4829317331,
            },
        },
        ["glenumbra/badmanscave_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Finvir",
                ["x"] = 0.6003810167,
                ["otherInfo"] = 
                {
                    ["time"] = 1533694067,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
                ["name"] = "Can't Take It With Them",
                ["y"] = 0.5939509273,
            },
        },
        ["coldharbor/vaultsofmadness1_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Gasteau Chamrond",
                ["x"] = 0.1713191420,
                ["otherInfo"] = 
                {
                    ["time"] = 1535399791,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Mind of Madness",
                ["y"] = 0.8147234321,
            },
        },
        ["alikr/sentinel_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4949,
                ["giver"] = "Captain Albert Marck",
                ["x"] = 0.2926796973,
                ["otherInfo"] = 
                {
                    ["time"] = 1535066932,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Risen From the Depths",
                ["y"] = 0.1584839523,
            },
            [2] = 
            {
                ["giver"] = "Watch Captain Zafira",
                ["x"] = 0.2063108236,
                ["otherInfo"] = 
                {
                    ["time"] = 1535068009,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Rise of the Dead",
                ["y"] = 0.5169557929,
            },
            [3] = 
            {
                ["giver"] = "Suspicious Monkey",
                ["x"] = 0.3683007956,
                ["otherInfo"] = 
                {
                    ["time"] = 1535919356,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Monkey Magic",
                ["y"] = 0.5333856940,
            },
            [4] = 
            {
                ["preQuest"] = 3333,
                ["giver"] = "Ildani",
                ["x"] = 0.2022365928,
                ["otherInfo"] = 
                {
                    ["time"] = 1535922375,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Seize the Moment",
                ["y"] = 0.5817687511,
            },
            [5] = 
            {
                ["preQuest"] = 2146,
                ["giver"] = "King Fahara'jad",
                ["x"] = 0.6791270971,
                ["otherInfo"] = 
                {
                    ["time"] = 1535930876,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "In Search of the Ash'abah",
                ["y"] = 0.6957021356,
            },
        },
        ["alikr/imperviousvault_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 2998,
                ["giver"] = "King Fahara'jad",
                ["x"] = 0.7415758967,
                ["otherInfo"] = 
                {
                    ["time"] = 1536637446,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Kingdom in Mourning",
                ["y"] = 0.5337469578,
            },
        },
        ["rivenspire/obsidianscar_base"] = 
        {
            [1] = 
            {
                ["preQuest"] = 4923,
                ["giver"] = "Lashgikh",
                ["x"] = 0.3315152228,
                ["otherInfo"] = 
                {
                    ["time"] = 1534833619,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Foul Deeds in the Deep",
                ["y"] = 0.8949609399,
            },
        },
        ["stormhaven/norvulkruins_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Matys Derone",
                ["x"] = 0.5907257795,
                ["otherInfo"] = 
                {
                    ["time"] = 1534368364,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
                ["name"] = "Word from the Dead",
                ["y"] = 0.8044354916,
            },
        },
    },
}
