QM_Scout =
{
    ["startTime"] = 1533505942,
    ["quests"] = 
    {
        ["auridon/bewan_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535248036,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Altmeri Relic",
                ["x"] = 0.5038520694,
                ["name"] = "Lost Bet",
                ["y"] = 0.6983050704,
            },
        },
        ["stormhaven/koeglinvillage_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533765631,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Dame Dabienne",
                ["preQuest"] = 3412,
                ["name"] = "False Accusations",
                ["x"] = 0.3885127902,
                ["y"] = 0.3335759938,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533769172,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Margot Oscent",
                ["preQuest"] = 2494,
                ["name"] = "The Slavers",
                ["x"] = 0.6060275435,
                ["y"] = 0.5187935233,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533775980,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Dame Dabienne",
                ["preQuest"] = 2556,
                ["name"] = "To Alcaire Castle",
                ["x"] = 0.3553662896,
                ["y"] = 0.3445196748,
            },
        },
        ["stormhaven/alcairecastle_base"] = 
        {
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533955857,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Duke Nathaniel",
                ["preQuest"] = 2567,
                ["name"] = "Tracking Sir Hughes",
                ["x"] = 0.4016301334,
                ["y"] = 0.4368499517,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533950269,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Hughes",
                ["preQuest"] = 2552,
                ["name"] = "Two Sides to Every Coin",
                ["x"] = 0.4701412022,
                ["y"] = 0.3651475012,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533951481,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Duchess Lakana",
                ["preQuest"] = 2564,
                ["name"] = "Life of the Duchess",
                ["x"] = 0.4061531425,
                ["y"] = 0.4338193238,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533955422,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Hughes",
                ["preQuest"] = 2566,
                ["name"] = "The Safety of the Kingdom",
                ["x"] = 0.3367925584,
                ["y"] = 0.5228102207,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533765724,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Merthyval Lort",
                ["x"] = 0.1734942794,
                ["name"] = "A Family Affair",
                ["y"] = 0.3512257040,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533766855,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "William Nurin",
                ["preQuest"] = 2561,
                ["name"] = "Scamp Invasion",
                ["x"] = 0.1847085655,
                ["y"] = 0.3290571570,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533767983,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Phinis Vanne",
                ["preQuest"] = 2578,
                ["name"] = "Can't Leave Without Her",
                ["x"] = 0.2047742903,
                ["y"] = 0.4067914188,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533768092,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Brother Perry",
                ["x"] = 0.2087714225,
                ["name"] = "The Slumbering Farmer",
                ["y"] = 0.3682714403,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533776633,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Ingride Vanne",
                ["preQuest"] = 1678,
                ["name"] = "Rozenn's Dream",
                ["x"] = 0.2702714205,
                ["y"] = 0.3650457263,
            },
            [6] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533846079,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Attack Plans",
                ["preQuest"] = 1709,
                ["name"] = "Lighthouse Attack Plans",
                ["x"] = 0.1770542860,
                ["y"] = 0.4724285603,
            },
            [7] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533846248,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Tyree Marence",
                ["x"] = 0.1766742915,
                ["name"] = "Repair Koeglin Lighthouse",
                ["y"] = 0.5024399757,
            },
            [8] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533846986,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Tyree Marence",
                ["x"] = 0.1754028499,
                ["name"] = "Repair Koeglin Lighthouse",
                ["y"] = 0.5064542890,
            },
            [9] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533847046,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Attack Plans",
                ["x"] = 0.1770028621,
                ["name"] = "Lighthouse Attack Plans",
                ["y"] = 0.4726114273,
            },
            [10] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533851768,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Captain Albert Marck",
                ["x"] = 0.1617742926,
                ["name"] = "Captive Crewmembers",
                ["y"] = 0.5501142740,
            },
            [11] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533853374,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "First Mate Elvira Derre",
                ["preQuest"] = 728,
                ["name"] = "Divert and Deliver",
                ["x"] = 0.2323114276,
                ["y"] = 0.5126199722,
            },
            [12] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533943284,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Graham",
                ["x"] = 0.2869457006,
                ["name"] = "False Knights",
                ["y"] = 0.3264142871,
            },
            [13] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533943891,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Graham",
                ["x"] = 0.2859799862,
                ["name"] = "False Knights",
                ["y"] = 0.3274685740,
            },
            [14] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533943921,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Edmund",
                ["x"] = 0.2963399887,
                ["name"] = "The Flame of Dissent",
                ["y"] = 0.3046999872,
            },
            [15] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533944379,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Edmund",
                ["preQuest"] = 736,
                ["name"] = "Retaking Firebrand Keep",
                ["x"] = 0.2970771492,
                ["y"] = 0.3039971292,
            },
            [16] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533944995,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Edmund",
                ["preQuest"] = 737,
                ["name"] = "Army at the Gates",
                ["x"] = 0.3258914351,
                ["y"] = 0.3003971577,
            },
            [17] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533956133,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Weather-Beaten Trunk",
                ["x"] = 0.2456285655,
                ["name"] = "Legacy of the Three",
                ["y"] = 0.2786599994,
            },
            [18] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534024196,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Edmund",
                ["preQuest"] = 2576,
                ["name"] = "Sir Hughes' Fate",
                ["x"] = 0.3260971308,
                ["y"] = 0.3008942902,
            },
            [19] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534032366,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Duke Nathaniel",
                ["preQuest"] = 467,
                ["name"] = "Unanswered Questions",
                ["x"] = 0.3323028684,
                ["y"] = 0.2973114252,
            },
            [20] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534035243,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Brother Zacharie",
                ["preQuest"] = 1735,
                ["name"] = "Fire in the Fields",
                ["x"] = 0.4674942791,
                ["y"] = 0.4025200009,
            },
            [21] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534040985,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Brother Perry",
                ["x"] = 0.4949942827,
                ["name"] = "Dreams to Nightmares",
                ["y"] = 0.4018571377,
            },
            [22] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534041930,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Master Muzgu",
                ["preQuest"] = 2046,
                ["name"] = "The Gate to Quagmire",
                ["x"] = 0.5474256873,
                ["y"] = 0.3202342987,
            },
            [23] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534043081,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sister Safia",
                ["preQuest"] = 1536,
                ["name"] = "Azura's Guardian",
                ["x"] = 0.4313657284,
                ["y"] = 0.3711885810,
            },
            [24] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534110562,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Master Altien",
                ["preQuest"] = 1529,
                ["name"] = "A Prison of Sleep",
                ["x"] = 0.4481828511,
                ["y"] = 0.3937314153,
            },
            [25] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534110585,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Falice Menoit",
                ["x"] = 0.4417657256,
                ["name"] = "Injured Spirit Wardens",
                ["y"] = 0.3914342821,
            },
            [26] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534115232,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 1541,
                ["name"] = "Pursuing the Shard",
                ["x"] = 0.4508599937,
                ["y"] = 0.4171828628,
            },
            [27] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534127785,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Arcady Charnis",
                ["preQuest"] = 1485,
                ["name"] = "The Sower Reaps",
                ["x"] = 0.4334171414,
                ["y"] = 0.5928171277,
            },
            [28] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534128064,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Priestess Pietine",
                ["x"] = 0.4062657058,
                ["name"] = "Abominations from Beyond",
                ["y"] = 0.5902314186,
            },
            [29] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534128145,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Cursed Skull",
                ["x"] = 0.3788971305,
                ["name"] = "Curse of Skulls",
                ["y"] = 0.6093199849,
            },
            [30] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534132043,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Hosni at-Tura",
                ["preQuest"] = 499,
                ["name"] = "The Signet Ring",
                ["x"] = 0.3172799945,
                ["y"] = 0.6113514304,
            },
            [31] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534132624,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Lady Sirali at-Tura",
                ["preQuest"] = 2495,
                ["name"] = "Evidence Against Adima",
                ["x"] = 0.2957200110,
                ["y"] = 0.5777771473,
            },
            [32] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534133322,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Lady Sirali at-Tura",
                ["preQuest"] = 2496,
                ["name"] = "Saving Hosni",
                ["x"] = 0.2950657010,
                ["y"] = 0.5778542757,
            },
            [33] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534133785,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Hosni at-Tura",
                ["preQuest"] = 2497,
                ["name"] = "The Return of the Dream Shard",
                ["x"] = 0.3099485636,
                ["y"] = 0.6140800118,
            },
            [34] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534134224,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 1633,
                ["name"] = "Another Omen",
                ["x"] = 0.4502457082,
                ["y"] = 0.4175542891,
            },
            [35] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534134527,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Watch Captain Rama",
                ["x"] = 0.5220771432,
                ["name"] = "Blood Revenge",
                ["y"] = 0.4397457242,
            },
            [36] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534135047,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Pierre Lanier",
                ["x"] = 0.5551342964,
                ["name"] = "Rat in a Trap",
                ["y"] = 0.4184857011,
            },
            [37] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534135245,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Watch Commander Kurt",
                ["preQuest"] = 1554,
                ["name"] = "A Means to an End",
                ["x"] = 0.5594199896,
                ["y"] = 0.4466885626,
            },
            [38] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534136855,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Watch Captain Ernard",
                ["preQuest"] = 1568,
                ["name"] = "Revenge Against Rama",
                ["x"] = 0.5594199896,
                ["y"] = 0.4467457235,
            },
            [39] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534284908,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Dro-Dara",
                ["preQuest"] = 1384,
                ["name"] = "Plowshares to Swords",
                ["x"] = 0.7167114019,
                ["y"] = 0.5452857018,
            },
            [40] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534285563,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Sister Tabakah",
                ["x"] = 0.8102228642,
                ["name"] = "Azura's Relics",
                ["y"] = 0.4731028676,
            },
            [41] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534289013,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Knarstygg",
                ["preQuest"] = 2536,
                ["name"] = "A Predator's Heart",
                ["x"] = 0.7230571508,
                ["y"] = 0.5479228497,
            },
            [42] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534292650,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "General Godrun",
                ["x"] = 0.7429599762,
                ["name"] = "General Godrun's Orders",
                ["y"] = 0.4852257073,
            },
            [43] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534292860,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Captain Dugakh",
                ["x"] = 0.7367143035,
                ["name"] = "Ogre Teeth",
                ["y"] = 0.4715114236,
            },
            [44] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534293441,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "General Godrun",
                ["preQuest"] = 1437,
                ["name"] = "Ending the Ogre Threat",
                ["x"] = 0.7524114251,
                ["y"] = 0.4308257103,
            },
            [45] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534304400,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 1346,
                ["name"] = "Godrun's Dream",
                ["x"] = 0.7416971326,
                ["y"] = 0.4839485586,
            },
            [46] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534304982,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 3637,
                ["name"] = "Azura's Aid",
                ["x"] = 0.7431628704,
                ["y"] = 0.4835257232,
            },
            [47] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534365486,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Mathias Raiment",
                ["x"] = 0.6858485937,
                ["name"] = "A Look in the Mirror",
                ["y"] = 0.4296885729,
            },
            [48] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534365750,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Countess Ilise Manteau",
                ["preQuest"] = 614,
                ["name"] = "Gift from a Suitor",
                ["x"] = 0.6523114443,
                ["y"] = 0.4326257110,
            },
            [49] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534368712,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Michel Helomaine",
                ["x"] = 0.6221686006,
                ["name"] = "The Perfect Burial",
                ["y"] = 0.4065999985,
            },
            [50] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534370713,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Blaise Pamarc",
                ["preQuest"] = 2538,
                ["name"] = "King Aphren's Sword",
                ["x"] = 0.6690571308,
                ["y"] = 0.5167885423,
            },
            [51] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534395263,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Serge Arcole",
                ["x"] = 0.4425742924,
                ["name"] = "A Ransom for Miranda",
                ["y"] = 0.6117914319,
            },
            [52] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534396158,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Serge Arcole",
                ["preQuest"] = 2451,
                ["name"] = "A Woman Wronged",
                ["x"] = 0.4409771562,
                ["y"] = 0.6594685912,
            },
        },
        ["summerset/etonnir_01"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535321772,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Seeks-the-Dark",
                ["preQuest"] = 6174,
                ["name"] = "Looting the Light",
                ["x"] = 0.9197530746,
                ["y"] = 0.3739441335,
            },
        },
        ["stormhaven/portdunwatch_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533943190,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Remy Berard",
                ["x"] = 0.4718382061,
                ["name"] = "Do as I Say",
                ["y"] = 0.3056835532,
            },
        },
        ["summerset/kingshavenext_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535322698,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Mehdze",
                ["preQuest"] = 6137,
                ["name"] = "Savage Truths",
                ["x"] = 0.8305439353,
                ["y"] = 0.4646966457,
            },
        },
        ["glenumbra/daggerfall_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533677832,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Swineherd Wickton",
                ["preQuest"] = 3039,
                ["name"] = "Swine Thief",
                ["x"] = 0.4550656676,
                ["y"] = 0.3237193525,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533677886,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Mighty Mordra",
                ["x"] = 0.5131012201,
                ["name"] = "One of the Undaunted",
                ["y"] = 0.2878405750,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533678341,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Felande Demarie",
                ["x"] = 0.4846858084,
                ["name"] = "Room to Spare",
                ["y"] = 0.2740499675,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533679195,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Beggar Matthew",
                ["preQuest"] = 3011,
                ["name"] = "Back-Alley Murders",
                ["x"] = 0.5158903599,
                ["y"] = 0.5736614466,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535244755,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Vanus Galerion",
                ["x"] = 0.4713554382,
                ["name"] = "Through a Veil Darkly",
                ["y"] = 0.4101165533,
            },
        },
        ["alikr/alikr_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535068408,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Herminius Sophus",
                ["x"] = 0.1420014948,
                ["name"] = "Past in Ruins",
                ["y"] = 0.4980856478,
            },
        },
        ["summerset/alinor_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535250228,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Vandoril",
                ["preQuest"] = 6097,
                ["name"] = "Checking on Cloudrest",
                ["x"] = 0.2997643054,
                ["y"] = 0.6473568082,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535250333,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Roguzog",
                ["x"] = 0.2337974161,
                ["name"] = "A Duelist's Dilemma",
                ["y"] = 0.4404526651,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535602223,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Battlereeve Tanerline",
                ["x"] = 0.6147393584,
                ["name"] = "The Abyssal Cabal",
                ["y"] = 0.5066245198,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535602261,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Rigurt the Brash",
                ["x"] = 0.6475471258,
                ["name"] = "Culture Clash",
                ["y"] = 0.5052776337,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535676619,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Battlereeve Tanerline",
                ["preQuest"] = 6165,
                ["name"] = "Sinking Summerset",
                ["x"] = 0.4284041226,
                ["y"] = 0.7019631863,
            },
        },
        ["rivenspire/orcsfingerruins_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534990861,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Teeba-Ja",
                ["x"] = 0.6867665052,
                ["name"] = "Shedding the Past",
                ["y"] = 0.5621206164,
            },
        },
        ["glenumbra/cryptwatchfort_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533695799,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Hastily Scribbled Note",
                ["preQuest"] = 4080,
                ["name"] = "Fortune in Failure",
                ["x"] = 0.3861386180,
                ["y"] = 0.3049505055,
            },
        },
        ["glenumbra/badmansstart_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533693555,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Curator Nicholas",
                ["preQuest"] = 4767,
                ["name"] = "Season of Harvest",
                ["x"] = 0.4435261786,
                ["y"] = 0.6460055113,
            },
        },
        ["coldharbor/vaultsofmadness1_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535399791,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Gasteau Chamrond",
                ["x"] = 0.1713191420,
                ["name"] = "Mind of Madness",
                ["y"] = 0.8147234321,
            },
        },
        ["rivenspire/flyleafcatacombs_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534832824,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Handre's Last Will",
                ["preQuest"] = 4942,
                ["name"] = "Fadeel's Freedom",
                ["x"] = 0.3211788237,
                ["y"] = 0.1988012046,
            },
        },
        ["summerset/dreamingcave02_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535410158,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Loremaster Celarus",
                ["x"] = 0.4700719118,
                ["name"] = "The Psijics' Calling",
                ["y"] = 0.4740376472,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535593687,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Josajeh",
                ["preQuest"] = 6172,
                ["name"] = "Breaches On the Bay",
                ["x"] = 0.2159475535,
                ["y"] = 0.6987097859,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535773627,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Valsirenn",
                ["preQuest"] = 6125,
                ["x"] = 0.4051924646,
                ["name"] = "The Crystal Tower",
                ["y"] = 0.4301501811,
            },
        },
        ["rivenspire/obsidianscar_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534833619,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Lashgikh",
                ["preQuest"] = 4923,
                ["name"] = "Foul Deeds in the Deep",
                ["x"] = 0.3315152228,
                ["y"] = 0.8949609399,
            },
        },
        ["stormhaven/farangelsdelve_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534129561,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Tomb Urn",
                ["preQuest"] = 2550,
                ["name"] = "Stolen Ashes",
                ["x"] = 0.4327341914,
                ["y"] = 0.4242919385,
            },
        },
        ["glenumbra/minesofkhuras_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533705261,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Guifford Vinielle's Sketchbook",
                ["preQuest"] = 3440,
                ["name"] = "A Brush With Death",
                ["x"] = 0.3869094849,
                ["y"] = 0.7706518769,
            },
        },
        ["rivenspire/shornhelm_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534547100,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "High King Emeric",
                ["preQuest"] = 4902,
                ["name"] = "Dream-Walk Into Darkness",
                ["x"] = 0.5924155712,
                ["y"] = 0.2087104321,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534720776,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4834,
                ["name"] = "A Spy in Shornhelm",
                ["x"] = 0.5225196481,
                ["y"] = 0.3165285885,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534724812,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Nicolene",
                ["x"] = 0.4601444602,
                ["name"] = "Children of Yokuda",
                ["y"] = 0.6325260401,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534735695,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4945,
                ["name"] = "Assassin Hunter",
                ["x"] = 0.5138304830,
                ["y"] = 0.3113873005,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535066382,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Queen Maraya",
                ["preQuest"] = 4936,
                ["name"] = "Favor for the Queen",
                ["x"] = 0.6035054326,
                ["y"] = 0.2218610644,
            },
        },
        ["summerset/dreamingcave01_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535752808,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6109,
                ["name"] = "Lost in Translation",
                ["x"] = 0.5636072755,
                ["y"] = 0.5473768711,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535755815,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Oriandra",
                ["preQuest"] = 6113,
                ["name"] = "A Necessary Alliance",
                ["x"] = 0.3942164779,
                ["y"] = 0.3588981628,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535778626,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Valsirenn",
                ["preQuest"] = 6126,
                ["x"] = 0.7556292415,
                ["name"] = "A New Alliance",
                ["y"] = 0.5018859506,
            },
        },
        ["summerset/lillandrill_base"] = 
        {
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535503983,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Tindoria",
                ["x"] = 0.3591848612,
                ["name"] = "The Perils of Art",
                ["y"] = 0.8553342223,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535493532,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Faralan",
                ["x"] = 0.5875323415,
                ["name"] = "Murder In Lillandril",
                ["y"] = 0.6400873661,
            },
        },
        ["alikr/sentinel_base"] = 
        {
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535068009,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Watch Captain Zafira",
                ["x"] = 0.2063108236,
                ["name"] = "Rise of the Dead",
                ["y"] = 0.5169557929,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535066932,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Captain Albert Marck",
                ["preQuest"] = 4949,
                ["name"] = "Risen From the Depths",
                ["x"] = 0.2926796973,
                ["y"] = 0.1584839523,
            },
        },
        ["summerset/sunhold_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535584965,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Kinlady Helenaere",
                ["x"] = 0.7326334715,
                ["name"] = "Sunhold Sundered",
                ["y"] = 0.7812337875,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534398094,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Darien Gautier",
                ["preQuest"] = 4901,
                ["name"] = "Shornhelm Divided",
                ["x"] = 0.4597792029,
                ["y"] = 0.7394628525,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534398418,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Daribert Hurier",
                ["x"] = 0.4797356725,
                ["name"] = "Under Siege",
                ["y"] = 0.6906269193,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534458595,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Scholar Cantier",
                ["x"] = 0.5490812063,
                ["name"] = "A Traitor's Tale",
                ["y"] = 0.5729492903,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534458893,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Jowan Hinault",
                ["preQuest"] = 3286,
                ["name"] = "Dearly Departed",
                ["x"] = 0.4653404057,
                ["y"] = 0.6188712120,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534547666,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Bumnog",
                ["x"] = 0.3692457676,
                ["name"] = "Rusty Daggers",
                ["y"] = 0.6888028383,
            },
            [6] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534553708,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Nathalye Ervine",
                ["preQuest"] = 5012,
                ["name"] = "In the Doghouse",
                ["x"] = 0.2783106267,
                ["y"] = 0.6280971169,
            },
            [7] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534553764,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Michel Gette",
                ["x"] = 0.2556575239,
                ["name"] = "The Blood-Cursed Town",
                ["y"] = 0.6459167004,
            },
            [8] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534567301,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Count Verandis Ravenwatch",
                ["preQuest"] = 4903,
                ["name"] = "The Blood-Splattered Shield",
                ["x"] = 0.2930417359,
                ["y"] = 0.4514686763,
            },
            [9] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534627281,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Gwendis",
                ["preQuest"] = 465,
                ["name"] = "The Concealing Veil",
                ["x"] = 0.2146217972,
                ["y"] = 0.6468122602,
            },
            [10] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534627498,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Federic Seychelle",
                ["x"] = 0.6914007068,
                ["name"] = "A Change of Heart",
                ["y"] = 0.4664203823,
            },
            [11] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534631512,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Count Verandis Ravenwatch",
                ["preQuest"] = 4857,
                ["name"] = "Northpoint in Peril",
                ["x"] = 0.5995568037,
                ["y"] = 0.4809440672,
            },
            [12] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534631587,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Alvaren Garoutte",
                ["x"] = 0.5871042013,
                ["name"] = "Archaic Relics",
                ["y"] = 0.5149237514,
            },
            [13] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534634478,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Marisette",
                ["x"] = 0.6284329295,
                ["name"] = "Crimes of the Past",
                ["y"] = 0.6254729033,
            },
            [14] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534634772,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Adusa-daro",
                ["x"] = 0.6064910293,
                ["name"] = "Hope Lost",
                ["y"] = 0.6622117758,
            },
            [15] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534651278,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Strange Sapling",
                ["x"] = 0.6333553791,
                ["name"] = "The Price of Longevity",
                ["y"] = 0.5597689748,
            },
            [16] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534736590,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4926,
                ["name"] = "The Assassin's List",
                ["x"] = 0.2959030271,
                ["y"] = 0.4603060186,
            },
            [17] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534737005,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Lieutenant Sgugh",
                ["x"] = 0.2673034668,
                ["name"] = "The Sanctifying Flames",
                ["y"] = 0.6350313425,
            },
            [18] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534737994,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4927,
                ["name"] = "Threat of Death",
                ["x"] = 0.2859297097,
                ["y"] = 0.4686428905,
            },
            [19] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534738422,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Adusa-daro",
                ["preQuest"] = 4928,
                ["name"] = "A Dagger to the Heart",
                ["x"] = 0.2863873839,
                ["y"] = 0.4693705440,
            },
            [20] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534742538,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Constable Agazu",
                ["preQuest"] = 4965,
                ["name"] = "Frightened Folk",
                ["x"] = 0.6877788305,
                ["y"] = 0.4420057237,
            },
            [21] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534810643,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Constable Agazu",
                ["preQuest"] = 4931,
                ["name"] = "Fell's Justice",
                ["x"] = 0.7006397247,
                ["y"] = 0.4126192331,
            },
            [22] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534831726,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Beryn",
                ["preQuest"] = 5312,
                ["name"] = "The Spider's Cocoon",
                ["x"] = 0.1827658564,
                ["y"] = 0.6250448823,
            },
            [23] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534913311,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Lothson Cold-Eye",
                ["x"] = 0.7315177917,
                ["name"] = "The Lady's Keepsake",
                ["y"] = 0.2306008041,
            },
            [24] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534983366,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Lady Clarisse Laurent",
                ["x"] = 0.6774894595,
                ["name"] = "The Emerald Chalice",
                ["y"] = 0.2659831345,
            },
            [25] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534999198,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Gwendis",
                ["preQuest"] = 4884,
                ["name"] = "The Crown of Shornhelm",
                ["x"] = 0.3189841807,
                ["y"] = 0.3771019280,
            },
        },
        ["rivenspire/hoarfrost_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534631769,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Captain Thayer",
                ["x"] = 0.4679913223,
                ["name"] = "The Wayward Son",
                ["y"] = 0.5418079495,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534634333,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Captain Thayer",
                ["preQuest"] = 5020,
                ["name"] = "The Bandit",
                ["x"] = 0.3932930827,
                ["y"] = 0.5901261568,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534650828,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Captain Thayer",
                ["preQuest"] = 5022,
                ["name"] = "The Lover",
                ["x"] = 0.4004475772,
                ["y"] = 0.5798182487,
            },
        },
        ["summerset/dreamingcave03_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535594149,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6112,
                ["name"] = "Buried Memories",
                ["x"] = 0.6542621255,
                ["y"] = 0.7077407837,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535601322,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6132,
                ["name"] = "The Tower Sentinels",
                ["x"] = 0.6307587624,
                ["y"] = 0.7504896522,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535690559,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6142,
                ["name"] = "The Dreaming Cave",
                ["x"] = 0.6557949185,
                ["y"] = 0.6959039569,
            },
        },
        ["rivenspire/erokii_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535001830,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Anenya",
                ["x"] = 0.7498008013,
                ["name"] = "Ancient Power",
                ["y"] = 0.3673306704,
            },
        },
        ["glenumbra/crosswych_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533595782,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Tamien Sellan",
                ["preQuest"] = 3337,
                ["name"] = "The Miners' Lament",
                ["x"] = 0.6166941524,
                ["y"] = 0.6053073406,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533596819,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Tamien Sellan",
                ["preQuest"] = 3302,
                ["name"] = "Crosswych Reclaimed",
                ["x"] = 0.6395968795,
                ["y"] = 0.6034337878,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533608597,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Alessio Guillon",
                ["x"] = 0.6025131345,
                ["name"] = "The Missing Prophecy",
                ["y"] = 0.5922731757,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533608894,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Bera Moorsmith",
                ["x"] = 0.5974093080,
                ["name"] = "Anchors from the Harbour",
                ["y"] = 0.5522983670,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533609272,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Adelle Montagne",
                ["x"] = 0.4721064568,
                ["name"] = "Long Lost Lore",
                ["y"] = 0.6174532175,
            },
        },
        ["glenumbra/badmanscave_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533694067,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Finvir",
                ["x"] = 0.6003810167,
                ["name"] = "Can't Take It With Them",
                ["y"] = 0.5939509273,
            },
        },
        ["rivenspire/tribulationcrypt_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534718973,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ancient Sword",
                ["preQuest"] = 4844,
                ["name"] = "A Past Remembered",
                ["x"] = 0.2981927693,
                ["y"] = 0.1962851435,
            },
        },
        ["summerset/collegeofpsijicsruins_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535331338,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Relicmaster Glenadir",
                ["x"] = 0.5981447697,
                ["name"] = "The Vault of Moawita",
                ["y"] = 0.4317321479,
            },
        },
        ["summerset/shimmerene_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534970964,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Calibar",
                ["x"] = 0.2751390040,
                ["name"] = "The Queen's Decree",
                ["y"] = 0.6924549937,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535086542,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Calibar",
                ["preQuest"] = 5283,
                ["name"] = "The Queen's Decree",
                ["x"] = 0.2323507369,
                ["y"] = 0.6622093320,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535148723,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Lanarie",
                ["x"] = 0.6734209061,
                ["name"] = "A Tale of Two Mothers",
                ["y"] = 0.6188374758,
            },
        },
        ["rivenspire/shroudedpass_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534996733,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Count Verandis Ravenwatch",
                ["preQuest"] = 5024,
                ["name"] = "The Lightless Remnant",
                ["x"] = 0.2278132588,
                ["y"] = 0.2501651645,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533506571,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Recruit Maelle",
                ["preQuest"] = 3379,
                ["name"] = "A Dangerous Dream",
                ["x"] = 0.6233919263,
                ["y"] = 0.2641271353,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533506619,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Garmeg the Ironfinder",
                ["x"] = 0.6356987953,
                ["name"] = "Legitimate Interests",
                ["y"] = 0.2552480102,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533506677,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Provost Piper",
                ["x"] = 0.6614254117,
                ["name"] = "Vines and Villains",
                ["y"] = 0.2836774588,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533506771,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Marley Oris",
                ["x"] = 0.6967237592,
                ["name"] = "Cursed Treasure",
                ["y"] = 0.2603922486,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533526292,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Harald Winvale",
                ["preQuest"] = 6227,
                ["name"] = "Forgotten Ancestry",
                ["x"] = 0.7467461228,
                ["y"] = 0.2198418677,
            },
            [6] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533528128,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Stibbons",
                ["preQuest"] = 3509,
                ["name"] = "The Jeweled Crown of Anton",
                ["x"] = 0.7838526368,
                ["y"] = 0.2978167236,
            },
            [7] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533594760,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "King Donel Deleyn",
                ["preQuest"] = 3050,
                ["name"] = "Servants of Ancient Kings",
                ["x"] = 0.7397236228,
                ["y"] = 0.1833901852,
            },
            [8] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533609896,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Malik Nasir",
                ["x"] = 0.5530404449,
                ["name"] = "The Corpse Horde",
                ["y"] = 0.2773717642,
            },
            [9] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533616621,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Daggerfall Patroller",
                ["preQuest"] = 3314,
                ["name"] = "Farlivere's Gambit",
                ["x"] = 0.4874128997,
                ["y"] = 0.7047001719,
            },
            [10] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533617294,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Lord Arcady Noellaume",
                ["preQuest"] = 3001,
                ["name"] = "Disorganized Crime",
                ["x"] = 0.5088144541,
                ["y"] = 0.6687227488,
            },
            [11] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533617404,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Lady Eloise Noellaume",
                ["x"] = 0.5077500343,
                ["name"] = "Lady Eloise's Lockbox",
                ["y"] = 0.6681137681,
            },
            [12] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533670237,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Erwan Castille",
                ["preQuest"] = 4335,
                ["name"] = "Wicked Trade",
                ["x"] = 0.5817878842,
                ["y"] = 0.4949662387,
            },
            [13] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533670926,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Guy LeBlanc",
                ["preQuest"] = 3023,
                ["name"] = "Wyrd and Coven",
                ["x"] = 0.6777231693,
                ["y"] = 0.5040016770,
            },
            [14] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533671046,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Mercenary",
                ["x"] = 0.6808248162,
                ["name"] = "Crocodile Bounty",
                ["y"] = 0.4546503127,
            },
            [15] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533679671,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Athel Baelborne",
                ["preQuest"] = 3017,
                ["name"] = "Legacy of Baelborne Rock",
                ["x"] = 0.3761095703,
                ["y"] = 0.7100141644,
            },
            [16] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533686910,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Lord Alain Diel",
                ["preQuest"] = 3414,
                ["name"] = "The Dagger's Edge",
                ["x"] = 0.3377877176,
                ["y"] = 0.6140681505,
            },
            [17] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533699922,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Leon Milielle",
                ["x"] = 0.4421305656,
                ["name"] = "The Ghosts of Westtry",
                ["y"] = 0.4058459699,
            },
            [18] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533701453,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Leon Milielle",
                ["preQuest"] = 3019,
                ["name"] = "Memento Mori",
                ["x"] = 0.3977132440,
                ["y"] = 0.4247629941,
            },
            [19] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533702206,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Lieutenant Clarice",
                ["preQuest"] = 3020,
                ["name"] = "Signals of Dominion",
                ["x"] = 0.3257557452,
                ["y"] = 0.3811810613,
            },
            [20] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533702234,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Scout's Orders",
                ["x"] = 0.3128614426,
                ["name"] = "Wayward Scouts",
                ["y"] = 0.3935525715,
            },
        },
        ["rivenspire/northpoint_base"] = 
        {
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534915414,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Blademaster Qariar",
                ["preQuest"] = 4916,
                ["name"] = "The Last of Them",
                ["x"] = 0.3138366342,
                ["y"] = 0.5237141848,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534897233,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Skordo the Knife",
                ["preQuest"] = 4958,
                ["name"] = "The Liberation of Northpoint",
                ["x"] = 0.4576599598,
                ["y"] = 0.1727312952,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534915013,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Baron Alard Dorell",
                ["preQuest"] = 4972,
                ["name"] = "Puzzle of the Pass",
                ["x"] = 0.5080171227,
                ["y"] = 0.5755673051,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534915193,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Short-Tail",
                ["x"] = 0.6390510201,
                ["name"] = "Guar Gone",
                ["y"] = 0.4246223271,
            },
        },
        ["summerset/ui_map"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534294704,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Olorime",
                ["x"] = 0.4132726490,
                ["name"] = "Woe of the Welkynars",
                ["y"] = 0.2734320164,
            },
        },
        ["stormhaven/bonesnapruinssecret_base"] = 
        {
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533871296,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sir Edgard",
                ["x"] = 0.6059898734,
                ["name"] = "Lost Lions",
                ["y"] = 0.6375247836,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533868567,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Battlemage Gaston",
                ["preQuest"] = 1637,
                ["name"] = "Repairing the Cage",
                ["x"] = 0.6948909760,
                ["y"] = 0.8454304934,
            },
        },
        ["grahtwood/eldenrootservices_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534827071,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Undaunted Enclave Invitation",
                ["x"] = 0.6841142774,
                ["name"] = "Taking the Undaunted Pledge",
                ["y"] = 0.4082742929,
            },
        },
        ["rivenspire/hildunessecretrefuge_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534896674,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Nadafa's Journal",
                ["x"] = 0.6928258538,
                ["name"] = "Love Lost",
                ["y"] = 0.3277197778,
            },
        },
        ["stormhaven/wayrest_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534116513,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "M'jaddha",
                ["x"] = 0.4391658008,
                ["name"] = "The Debt Collector's Debts",
                ["y"] = 0.1780604571,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534125955,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Sergeant Stegine",
                ["x"] = 0.2756144106,
                ["name"] = "The Dreugh Threat",
                ["y"] = 0.1300478876,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534127126,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Adiel Charnis",
                ["preQuest"] = 2068,
                ["name"] = "They Dragged Him Away",
                ["x"] = 0.2342794538,
                ["y"] = 0.0535364039,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["name"] = "Clothier Writ",
                ["x"] = 0.3749423027,
                ["y"] = 0.2255538255,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.3749423027,
                ["y"] = 0.2255538255,
            },
            [6] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["name"] = "Woodworker Writ",
                ["x"] = 0.3749423027,
                ["y"] = 0.2255538255,
            },
            [7] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196577,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["preQuest"] = 1527,
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.3749423027,
                ["y"] = 0.2255538255,
            },
            [8] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534283292,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Janne Marolles",
                ["x"] = 1.0325227976,
                ["name"] = "Old Adventurers",
                ["y"] = 0.2736096680,
            },
            [9] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534367222,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Eldrasea Deras",
                ["preQuest"] = 1615,
                ["name"] = "To The Clockwork City",
                ["x"] = 0.6182646751,
                ["y"] = 0.3309824765,
            },
            [10] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534373250,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Abbot Durak",
                ["preQuest"] = 521,
                ["name"] = "Vaermina's Gambit",
                ["x"] = 0.4303103685,
                ["y"] = 0.4614630342,
            },
            [11] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534374724,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "High King Emeric",
                ["preQuest"] = 575,
                ["name"] = "The Road to Rivenspire",
                ["x"] = 0.3795575202,
                ["y"] = 0.4613187909,
            },
            [12] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534387635,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Urgarlag Chief-bane",
                ["x"] = 0.1636523604,
                ["name"] = "Pledge: Moon Hunter Keep",
                ["y"] = 0.5017451048,
            },
            [13] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534903120,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1531094909,
                ["name"] = "Pledge: Fungal Grotto I",
                ["y"] = 0.4949232638,
            },
            [14] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534905260,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1525470167,
                ["name"] = "Pledge: Fungal Grotto I",
                ["y"] = 0.4953559339,
            },
            [15] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535077586,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1517682076,
                ["name"] = "Pledge: Crypt of Hearts I",
                ["y"] = 0.4776739478,
            },
            [16] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535077599,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Maj al-Ragath",
                ["x"] = 0.1553738266,
                ["name"] = "Pledge: Darkshade Caverns I",
                ["y"] = 0.4947213531,
            },
            [17] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535399588,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Glirion the Redbeard",
                ["x"] = 0.1539315730,
                ["name"] = "Pledge: Vaults of Madness",
                ["y"] = 0.4767653048,
            },
        },
        ["grahtwood/eldenrootgroundfloor_base"] = 
        {
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534216360,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Sealed Enchanting Writ",
                ["x"] = 0.7304733396,
                ["name"] = "A Masterful Glyph",
                ["y"] = 0.6416119933,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534216349,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Sealed Woodworking Writ",
                ["preQuest"] = 6022,
                ["name"] = "A Masterful Shield",
                ["x"] = 0.7304733396,
                ["y"] = 0.6416119933,
            },
        },
        ["glenumbra/aldcroft_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533669833,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Captain Vistra",
                ["preQuest"] = 3004,
                ["name"] = "Pride of the Lion Guard",
                ["x"] = 0.5562694669,
                ["y"] = 0.3413914144,
            },
        },
        ["auridon/vulkhelguard_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6363090277,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6363090277,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033477,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2813375592,
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6363090277,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Clothier Writ",
                ["y"] = 0.5947007537,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5947007537,
            },
            [6] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5947007537,
            },
            [7] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2248924077,
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5947007537,
            },
            [8] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6336819530,
            },
            [9] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6336819530,
            },
            [10] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534196952,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2803492844,
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6336819530,
            },
            [11] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Clothier Writ",
                ["y"] = 0.5952637196,
            },
            [12] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.5952637196,
            },
            [13] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Woodworker Writ",
                ["y"] = 0.5952637196,
            },
            [14] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214704,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Equipment Crafting Writs",
                ["x"] = 0.2243419737,
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.5952637196,
            },
            [15] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["name"] = "Provisioner Writ",
                ["y"] = 0.6322933435,
            },
            [16] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["name"] = "Enchanter Writ",
                ["y"] = 0.6322933435,
            },
            [17] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534214742,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Consumables Crafting Writs",
                ["x"] = 0.2811499238,
                ["name"] = "Alchemist Writ",
                ["y"] = 0.6322933435,
            },
            [18] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534215666,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Sealed Clothier Writ",
                ["preQuest"] = 6228,
                ["name"] = "Masterful Leatherwear",
                ["x"] = 0.3380454481,
                ["y"] = 0.5761359334,
            },
            [19] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534215692,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Sealed Alchemy Writ",
                ["x"] = 0.3380454481,
                ["name"] = "A Masterful Concoction",
                ["y"] = 0.5761359334,
            },
            [20] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535167121,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Battlemaster Rivyn",
                ["preQuest"] = 5952,
                ["name"] = "Test of Mettle",
                ["x"] = 0.5293735266,
                ["y"] = 0.5142739415,
            },
            [21] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535169644,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Battlemaster Rivyn",
                ["preQuest"] = 5954,
                ["name"] = "Let the Games Begin",
                ["x"] = 0.5293610096,
                ["y"] = 0.5142739415,
            },
        },
        ["stormhaven/bearclawmine_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534364051,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Hubert",
                ["x"] = 0.3204819262,
                ["name"] = "Next of Kin",
                ["y"] = 0.4829317331,
            },
        },
        ["stormhaven/norvulkruins_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534368364,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Matys Derone",
                ["x"] = 0.5907257795,
                ["name"] = "Word from the Dead",
                ["y"] = 0.8044354916,
            },
        },
        ["glenumbra/ilessantower_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1533684860,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["giver"] = "Red Rook Note",
                ["x"] = 0.5450952053,
                ["name"] = "Red Rook Resources",
                ["y"] = 0.7700323462,
            },
        },
        ["summerset/summerset_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535251241,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Silurie",
                ["preQuest"] = 6170,
                ["name"] = "The Taste of Fear",
                ["x"] = 0.2925261259,
                ["y"] = 0.5346723199,
            },
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535255755,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Celinar",
                ["x"] = 0.5957511067,
                ["name"] = "The Runaway's Tale",
                ["y"] = 0.5206859112,
            },
            [3] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535261874,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Hiranesse",
                ["preQuest"] = 6151,
                ["name"] = "Lost at Sea",
                ["x"] = 0.2685208023,
                ["y"] = 0.5220580101,
            },
            [4] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535263016,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Rinyde",
                ["preQuest"] = 6149,
                ["name"] = "Manor of Masques",
                ["x"] = 0.3724193871,
                ["y"] = 0.4847295582,
            },
            [5] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535317497,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Linwenvar",
                ["preQuest"] = 6114,
                ["name"] = "Old Wounds",
                ["x"] = 0.4583003223,
                ["y"] = 0.4649710059,
            },
            [6] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535320156,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Oriandra",
                ["preQuest"] = 6135,
                ["name"] = "Whispers from the Deep",
                ["x"] = 0.5359108448,
                ["y"] = 0.3748296201,
            },
            [7] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535338816,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Andewen",
                ["x"] = 0.3586560786,
                ["name"] = "The Ebon Sanctum",
                ["y"] = 0.3742801845,
            },
            [8] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535338862,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Merenfire",
                ["x"] = 0.3263515234,
                ["name"] = "Illusions of Grandeur",
                ["y"] = 0.3584633172,
            },
            [9] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535339223,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Amsha",
                ["x"] = 0.2576109469,
                ["name"] = "Wasting Away",
                ["y"] = 0.2951898277,
            },
            [10] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535407539,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Tableau",
                ["x"] = 0.3235512078,
                ["name"] = "The Hulkynd's Heart",
                ["y"] = 0.4748214185,
            },
            [11] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535431714,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Renzir",
                ["preQuest"] = 6146,
                ["name"] = "An Unexpected Betrayal",
                ["x"] = 0.2977776527,
                ["y"] = 0.2113002241,
            },
            [12] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535505848,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Talomar",
                ["x"] = 0.6750555038,
                ["name"] = "Untamed and Unleashed",
                ["y"] = 0.6039851308,
            },
            [13] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535513267,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Igeke Rat-Bite",
                ["preQuest"] = 6121,
                ["name"] = "Gjadil's Legacy",
                ["x"] = 0.7185612917,
                ["y"] = 0.7324187160,
            },
            [14] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535562876,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Manacar",
                ["x"] = 0.2794109285,
                ["name"] = "Bantering with Bandits",
                ["y"] = 0.5546858907,
            },
            [15] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535564644,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Bailiff Erator",
                ["preQuest"] = 6140,
                ["name"] = "Lauriel's Lament",
                ["x"] = 0.5906194448,
                ["y"] = 0.3029791117,
            },
            [16] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535576284,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Miranrel",
                ["x"] = 0.5512996912,
                ["name"] = "Gryphon Grievance",
                ["y"] = 0.2825572789,
            },
            [17] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535577799,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Kinlady Ilunsare",
                ["preQuest"] = 6179,
                ["name"] = "Obedience Issues",
                ["x"] = 0.4651895463,
                ["y"] = 0.7353738546,
            },
            [18] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535660442,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Pandermalion",
                ["x"] = 0.2621946633,
                ["name"] = "Storming the Walls",
                ["y"] = 0.4188621342,
            },
        },
        ["rivenspire/crestshademine_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534624071,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Troll Socialization Research Notes",
                ["x"] = 0.4132508039,
                ["name"] = "Friend of Trolls",
                ["y"] = 0.3638949394,
            },
        },
        ["summerset/artaeum_base"] = 
        {
            [2] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535594843,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ulliceta gra-Kogg",
                ["x"] = 0.3989331722,
                ["name"] = "Half-Formed Understandings",
                ["y"] = 0.4446600974,
            },
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1535331163,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Ritemaster Iachesis",
                ["preQuest"] = 6096,
                ["name"] = "A Pearl of Great Price",
                ["x"] = 0.6434336305,
                ["y"] = 0.2702807188,
            },
        },
        ["stonefalls/fungalgrotto_base"] = 
        {
            [1] = 
            {
                ["otherInfo"] = 
                {
                    ["time"] = 1534903204,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["giver"] = "Vila Theran",
                ["x"] = 0.3413615227,
                ["name"] = "Kings of the Grotto",
                ["y"] = 0.7768288851,
            },
        },
    },
    ["questInfo"] = 
    {
        [1536] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5377] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6146] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2564] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1541] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2566] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2567] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3337] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [523] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5388] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5389] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [3343] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5392] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5394] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5395] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5396] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [6165] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5400] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [6170] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4379] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [6172] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 10,
                [3] = 1,
            },
        },
        [5406] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5407] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [1568] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5409] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [6179] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5412] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5413] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [4902] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4903] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5416] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5417] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [5418] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [4401] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4403] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4916] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3637] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1591] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4920] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1339] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1341] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4926] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [575] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4928] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4929] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1346] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4931] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4934] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4936] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4937] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6218] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [6153] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [2552] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4942] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1615] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4944] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4945] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5952] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
        },
        [6227] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [6228] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5973] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [3414] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6150] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3416] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6142] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2046] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4443] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2556] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6149] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4958] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5983] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [4858] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1633] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4857] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6136] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1527] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4965] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [614] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1639] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1384] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1637] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4202] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5954] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
        },
        [3436] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6180] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6131] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6130] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3440] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6177] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6174] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6127] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [499] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6176] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5171] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6151] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3192] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4473] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2538] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2537] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4840] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4839] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3302] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5247] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6162] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [6144] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4930] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4834] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2436] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6113] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
        },
        [6022] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [6112] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3039] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6145] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1554] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4949] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4145] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [1529] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1678] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4884] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4927] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [657] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2450] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2451] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5012] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5014] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4246] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [1687] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4822] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [3993] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5274] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4565] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5020] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1437] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5022] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4767] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5024] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3379] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [5021] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5283] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [4516] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5018] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [465] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [4519] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2576] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5027] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4901] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5368] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [2578] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1709] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [521] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2569] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3412] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2481] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2504] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4531] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3783] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3509] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3286] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4535] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4533] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3001] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5303] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3003] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3004] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5309] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [2494] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2495] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5312] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2497] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5051] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3011] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2496] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4952] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4529] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1735] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3784] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3017] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [1383] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3019] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3020] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [1485] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2068] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3023] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6096] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6097] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4923] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [467] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2558] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3285] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6102] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2561] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [728] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [4472] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [5976] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
        },
        [3035] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4888] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6109] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4972] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [6111] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [736] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [737] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6114] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6115] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6116] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6117] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6118] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6119] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [2536] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6121] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [3050] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4843] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4844] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6125] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 1,
            },
        },
        [6126] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 9,
                [4] = 1,
            },
        },
        [4335] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4080] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6129] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
        },
        [3314] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [3059] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6132] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
        },
        [2549] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [2550] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6135] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [4088] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6137] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6138] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
        },
        [6139] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6140] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [6141] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
        [5374] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
        },
        [2047] = 
        {
            ["repeatType"] = 0,
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
        },
    },
    ["subZones"] = 
    {
        ["rivenspire/rivenspire_base"] = 
        {
            ["rivenspire/northpoint_base"] = 
            {
                ["x"] = 0.4192044437,
                ["y"] = 0.6977521181,
            },
            ["rivenspire/doomcragshroudedpass_base"] = 
            {
                ["x"] = 0.4524268210,
                ["y"] = 0.2928013802,
            },
            ["rivenspire/rivenspireoutlaw_base"] = 
            {
                ["x"] = 0.5317950249,
                ["y"] = 0.4735883772,
            },
            ["rivenspire/obsidianscar_base"] = 
            {
                ["x"] = 0.4192044437,
                ["y"] = 0.6977521181,
            },
            ["rivenspire/flyleafcatacombs_base"] = 
            {
                ["x"] = 0.5922636986,
                ["y"] = 0.1450490803,
            },
            ["rivenspire/edraldundercroftdomed_base"] = 
            {
                ["x"] = 0.5017006397,
                ["y"] = 0.7009591460,
            },
            ["rivenspire/breaghafinupper_base"] = 
            {
                ["x"] = 0.2418812662,
                ["y"] = 0.6513264179,
            },
            ["rivenspire/shadowfatecavern_base"] = 
            {
                ["x"] = 0.7164837718,
                ["y"] = 0.2099232525,
            },
            ["rivenspire/hildunessecretrefuge_base"] = 
            {
                ["x"] = 0.1964630783,
                ["y"] = 0.7363085151,
            },
            ["rivenspire/tribulationcrypt_base"] = 
            {
                ["x"] = 0.6021974683,
                ["y"] = 0.6716846228,
            },
            ["rivenspire/lorkrataruinsa_base"] = 
            {
                ["x"] = 0.4828965664,
                ["y"] = 0.5993559957,
            },
            ["rivenspire/doomcragtop_base"] = 
            {
                ["x"] = 0.3759659529,
                ["y"] = 0.3183684349,
            },
            ["rivenspire/erokii_base"] = 
            {
                ["x"] = 0.3114539683,
                ["y"] = 0.4000349045,
            },
            ["rivenspire/orcsfingerruins_base"] = 
            {
                ["x"] = 0.3507380486,
                ["y"] = 0.8094767928,
            },
        },
        ["alikr/alikr_base"] = 
        {
            ["alikr/sentinel_base"] = 
            {
                ["x"] = 0.3627234399,
                ["y"] = 0.5104555488,
            },
        },
        ["summerset/summerset_base"] = 
        {
            ["summerset/ebonstadmont03_base"] = 
            {
                ["x"] = 0.3468613625,
                ["y"] = 0.3874606490,
            },
            ["summerset/russafeldredtemple01_base"] = 
            {
                ["x"] = 0.4843394756,
                ["y"] = 0.4995644093,
            },
            ["summerset/etonnir_01"] = 
            {
                ["x"] = 0.3271756768,
                ["y"] = 0.5096121430,
            },
            ["summerset/sq4sapiarch02_base"] = 
            {
                ["x"] = 0.3934149444,
                ["y"] = 0.1052494198,
            },
            ["summerset/archonsgrove_base"] = 
            {
                ["x"] = 0.5836012363,
                ["y"] = 0.5790919065,
            },
            ["summerset/ceytarncaveext01_base"] = 
            {
                ["x"] = 0.5518673062,
                ["y"] = 0.3494780362,
            },
            ["summerset/sunhold_base"] = 
            {
                ["x"] = 0.3633111417,
                ["y"] = 0.3487282395,
            },
            ["summerset/collegeofpsijicsruins_btm"] = 
            {
                ["x"] = 0.4623057544,
                ["y"] = 0.4480006099,
            },
            ["summerset/sq7courtofbedlamruins_base"] = 
            {
                ["x"] = 0.3114149868,
                ["y"] = 0.2188724726,
            },
            ["summerset/ui_map"] = 
            {
                ["x"] = 0.3561471999,
                ["y"] = 0.4230011404,
            },
            ["summerset/lillandrilcave_base"] = 
            {
                ["x"] = 0.4480309784,
                ["y"] = 0.1849195659,
            },
            ["summerset/corgradwastehigher2_base"] = 
            {
                ["x"] = 0.2811351120,
                ["y"] = 0.2448797524,
            },
            ["summerset/wastencoraldale_base"] = 
            {
                ["x"] = 0.5220731497,
                ["y"] = 0.2665567696,
            },
            ["summerset/artaeum_base"] = 
            {
                ["x"] = 0.4623057544,
                ["y"] = 0.4480006099,
            },
            ["summerset/kingshavenext_base"] = 
            {
                ["x"] = 0.2751277089,
                ["y"] = 0.4893906713,
            },
            ["summerset/seakeep_03"] = 
            {
                ["x"] = 0.4341204464,
                ["y"] = 0.2106248140,
            },
            ["summerset/karndar_03"] = 
            {
                ["x"] = 0.3199555576,
                ["y"] = 0.6266152859,
            },
            ["summerset/russafeldredtemple02_base"] = 
            {
                ["x"] = 0.4036326706,
                ["y"] = 0.4386571348,
            },
            ["summerset/sinkhole_base"] = 
            {
                ["x"] = 0.4278960228,
                ["y"] = 0.4365155399,
            },
            ["summerset/eldbursanctuary02_base"] = 
            {
                ["x"] = 0.3709714115,
                ["y"] = 0.5544005036,
            },
            ["summerset/illuminationacademy_01"] = 
            {
                ["x"] = 0.3232491612,
                ["y"] = 0.3171582818,
            },
            ["summerset/ceytarncaveint03_base"] = 
            {
                ["x"] = 0.5509521365,
                ["y"] = 0.3513980210,
            },
            ["summerset/sum_karnwasten"] = 
            {
                ["x"] = 0.2091100663,
                ["y"] = 0.3010985851,
            },
            ["summerset/torhamekhard_01"] = 
            {
                ["x"] = 0.5443542600,
                ["y"] = 0.4963967800,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            ["stormhaven/wayrest_base"] = 
            {
                ["x"] = 0.6020143032,
                ["y"] = 0.3844971359,
            },
            ["stormhaven/alcairecastle_base"] = 
            {
                ["x"] = 0.2951657176,
                ["y"] = 0.3298285604,
            },
            ["stormhaven/windridgecave_base"] = 
            {
                ["x"] = 0.2765971422,
                ["y"] = 0.2868742943,
            },
            ["stormhaven/portdunwatch_base"] = 
            {
                ["x"] = 0.3236285746,
                ["y"] = 0.3078914285,
            },
            ["stormhaven/bearclawmine_base"] = 
            {
                ["x"] = 0.4329885840,
                ["y"] = 0.7857285738,
            },
            ["stormhaven/godrunsdream_base"] = 
            {
                ["x"] = 0.4834085703,
                ["y"] = 0.7412771583,
            },
            ["stormhaven/aphrenshold_base"] = 
            {
                ["x"] = 0.4917228520,
                ["y"] = 0.6410685778,
            },
            ["stormhaven/pariahcatacombs_base"] = 
            {
                ["x"] = 0.4301457107,
                ["y"] = 0.4577028453,
            },
            ["stormhaven/norvulkruins_base"] = 
            {
                ["x"] = 0.3670828640,
                ["y"] = 0.6055743098,
            },
            ["stormhaven/bonesnapruinssecret_base"] = 
            {
                ["x"] = 0.4975742996,
                ["y"] = 0.3175171316,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            ["glenumbra/cryptwatchfort_base"] = 
            {
                ["x"] = 0.2532835305,
                ["y"] = 0.6058680415,
            },
            ["glenumbra/daggerfall_base"] = 
            {
                ["x"] = 0.7309818864,
                ["y"] = 0.3731749952,
            },
            ["glenumbra/tomboflostkings_base"] = 
            {
                ["x"] = 0.2866012454,
                ["y"] = 0.7805057764,
            },
            ["glenumbra/eboncrypt_base"] = 
            {
                ["x"] = 0.3692837954,
                ["y"] = 0.4798353016,
            },
            ["glenumbra/silumm_base"] = 
            {
                ["x"] = 0.6779845357,
                ["y"] = 0.2721574605,
            },
            ["glenumbra/ilessantower_base"] = 
            {
                ["x"] = 0.7259832025,
                ["y"] = 0.3480412066,
            },
            ["glenumbra/spindleclutch_base"] = 
            {
                ["x"] = 0.3366774917,
                ["y"] = 0.7143661976,
            },
        },
    },
}
