QM_Scout =
{
    ["subZones"] = 
    {
        ["alikr/alikr_base"] = 
        {
            ["alikr/volenfell_base"] = 
            {
                ["x"] = 0.4628429115,
                ["y"] = 0.8726661801,
            },
            ["alikr/suturahs_crypt"] = 
            {
                ["x"] = 0.2986557186,
                ["y"] = 0.7747572660,
            },
            ["alikr/sandblownmine_base"] = 
            {
                ["x"] = 0.5083644390,
                ["y"] = 0.8309459686,
            },
            ["alikr/yokudanpalace02_base"] = 
            {
                ["x"] = 0.6587777138,
                ["y"] = 0.2947149575,
            },
            ["alikr/lostcity_base"] = 
            {
                ["x"] = 0.2899029255,
                ["y"] = 0.6729325652,
            },
            ["alikr/yldzuun_base"] = 
            {
                ["x"] = 0.5083644390,
                ["y"] = 0.8309459686,
            },
            ["alikr/divadschagrinmine_base"] = 
            {
                ["x"] = 0.4622105956,
                ["y"] = 0.2483669370,
            },
            ["alikr/kulatimines-a_base"] = 
            {
                ["x"] = 0.5081379414,
                ["y"] = 0.4977097213,
            },
            ["alikr/salasen_base"] = 
            {
                ["x"] = 0.6820662022,
                ["y"] = 0.2205028683,
            },
            ["alikr/aldunz_base"] = 
            {
                ["x"] = 0.6422330141,
                ["y"] = 0.6404904127,
            },
            ["alikr/sentinel_base"] = 
            {
                ["x"] = 0.3627234399,
                ["y"] = 0.5104555488,
            },
            ["alikr/coldrockdiggings_base"] = 
            {
                ["x"] = 0.5001991391,
                ["y"] = 0.7188598514,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            ["rivenspire/hildunessecretrefuge_base"] = 
            {
                ["x"] = 0.1964630783,
                ["y"] = 0.7363085151,
            },
            ["rivenspire/lorkrataruinsa_base"] = 
            {
                ["x"] = 0.4828965664,
                ["y"] = 0.5993559957,
            },
            ["rivenspire/tribulationcrypt_base"] = 
            {
                ["x"] = 0.6021974683,
                ["y"] = 0.6716846228,
            },
            ["rivenspire/rivenspireoutlaw_base"] = 
            {
                ["x"] = 0.5317950249,
                ["y"] = 0.4735883772,
            },
            ["rivenspire/doomcragshroudedpass_base"] = 
            {
                ["x"] = 0.4524268210,
                ["y"] = 0.2928013802,
            },
            ["rivenspire/shroudedpass2_base"] = 
            {
                ["x"] = 0.4239128530,
                ["y"] = 0.4067715704,
            },
            ["rivenspire/orcsfingerruins_base"] = 
            {
                ["x"] = 0.3507380486,
                ["y"] = 0.8094767928,
            },
            ["rivenspire/doomcragtop_base"] = 
            {
                ["x"] = 0.3759659529,
                ["y"] = 0.3183684349,
            },
            ["rivenspire/shadowfatecavern_base"] = 
            {
                ["x"] = 0.7164837718,
                ["y"] = 0.2099232525,
            },
            ["rivenspire/erokii_base"] = 
            {
                ["x"] = 0.3114539683,
                ["y"] = 0.4000349045,
            },
            ["rivenspire/breaghafinupper_base"] = 
            {
                ["x"] = 0.2418812662,
                ["y"] = 0.6513264179,
            },
            ["rivenspire/flyleafcatacombs_base"] = 
            {
                ["x"] = 0.5922636986,
                ["y"] = 0.1450490803,
            },
            ["rivenspire/northpoint_base"] = 
            {
                ["x"] = 0.4192044437,
                ["y"] = 0.6977521181,
            },
            ["rivenspire/edraldundercroftdomed_base"] = 
            {
                ["x"] = 0.5017006397,
                ["y"] = 0.7009591460,
            },
            ["rivenspire/obsidianscar_base"] = 
            {
                ["x"] = 0.4192044437,
                ["y"] = 0.6977521181,
            },
        },
        ["vvardenfell/vvardenfell_base"] = 
        {
            ["vvardenfell/odirniran_base"] = 
            {
                ["x"] = 0.7728256583,
                ["y"] = 0.8294625878,
            },
            ["vvardenfell/andrano_base"] = 
            {
                ["x"] = 0.7930721641,
                ["y"] = 0.4316285551,
            },
            ["vvardenfell/ashurnibibi_base"] = 
            {
                ["x"] = 0.6915417910,
                ["y"] = 0.2803797722,
            },
            ["vvardenfell/zaintiraris_base"] = 
            {
                ["x"] = 0.8212261796,
                ["y"] = 0.7254741788,
            },
            ["vvardenfell/khartagpoint_base"] = 
            {
                ["x"] = 0.4993799329,
                ["y"] = 0.2454762012,
            },
            ["vvardenfell/ramimilk_base"] = 
            {
                ["x"] = 0.5086320043,
                ["y"] = 0.4155180454,
            },
            ["vvardenfell/balur_base"] = 
            {
                ["x"] = 0.6206278801,
                ["y"] = 0.6600874662,
            },
            ["vvardenfell/arkngthunch_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/balmora_base"] = 
            {
                ["x"] = 0.6807340384,
                ["y"] = 0.3892686665,
            },
            ["vvardenfell/nchuleftingth1_base"] = 
            {
                ["x"] = 0.6591807008,
                ["y"] = 0.6729421020,
            },
            ["vvardenfell/inanius_base"] = 
            {
                ["x"] = 0.7456139922,
                ["y"] = 0.6141583323,
            },
            ["vvardenfell/nchuleftdepths_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/matusakin_base"] = 
            {
                ["x"] = 0.6896594167,
                ["y"] = 0.7982082367,
            },
            ["vvardenfell/vivechow01a_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/molagmarglassmine_base"] = 
            {
                ["x"] = 0.7482542396,
                ["y"] = 0.7141730189,
            },
            ["vvardenfell/ashalmawia02_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/zalkinsul01_base"] = 
            {
                ["x"] = 0.5960587263,
                ["y"] = 0.6608186364,
            },
            ["vvardenfell/gnisiseggmine_base"] = 
            {
                ["x"] = 0.3351431489,
                ["y"] = 0.2259497643,
            },
            ["vvardenfell/forgottenwastesext_base"] = 
            {
                ["x"] = 0.2571662962,
                ["y"] = 0.5191664100,
            },
            ["vvardenfell/hlaren_base"] = 
            {
                ["x"] = 0.4824426472,
                ["y"] = 0.3646239340,
            },
            ["vvardenfell/firemothisland_base"] = 
            {
                ["x"] = 0.8348253369,
                ["y"] = 0.4202829599,
            },
            ["vvardenfell/nchuleftingth6_base"] = 
            {
                ["x"] = 0.8018486500,
                ["y"] = 0.3991185725,
            },
            ["vvardenfell/shulk_base"] = 
            {
                ["x"] = 0.6750468016,
                ["y"] = 0.3416326940,
            },
            ["vvardenfell/ashimanu01_base"] = 
            {
                ["x"] = 0.4824426472,
                ["y"] = 0.3646239340,
            },
            ["vvardenfell/zainsipilu_base"] = 
            {
                ["x"] = 0.7515901923,
                ["y"] = 0.3583010733,
            },
            ["vvardenfell/kudanat_base"] = 
            {
                ["x"] = 0.6807340384,
                ["y"] = 0.3892686665,
            },
            ["vvardenfell/galomdaeus_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/tusenend_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/ashalmawia_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/kaushtarari02_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/nchuleftingth7_base"] = 
            {
                ["x"] = 0.6729398966,
                ["y"] = 0.6730310321,
            },
            ["vvardenfell/pulklower_base"] = 
            {
                ["x"] = 0.3130408823,
                ["y"] = 0.6740599871,
            },
            ["vvardenfell/skar_base"] = 
            {
                ["x"] = 0.4552309811,
                ["y"] = 0.3969361186,
            },
            ["vvardenfell/cavernoftheincarnate_base"] = 
            {
                ["x"] = 0.2982215881,
                ["y"] = 0.5858443379,
            },
            ["vvardenfell/vassirdidanat01_base"] = 
            {
                ["x"] = 0.7204691768,
                ["y"] = 0.3831925094,
            },
            ["vvardenfell/pinsun_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/libraryofandule02_base"] = 
            {
                ["x"] = 0.2578419149,
                ["y"] = 0.2611378133,
            },
            ["vvardenfell/vassamsigrotto_base"] = 
            {
                ["x"] = 0.4418340623,
                ["y"] = 0.7821643949,
            },
            ["vvardenfell/nchuleft_base"] = 
            {
                ["x"] = 0.3294314444,
                ["y"] = 0.6121292114,
            },
            ["vvardenfell/prisonofxykenaz_base"] = 
            {
                ["x"] = 0.2845602036,
                ["y"] = 0.7320503592,
            },
            ["vvardenfell/viviccity_base"] = 
            {
                ["x"] = 0.8583722115,
                ["y"] = 0.4753374755,
            },
            ["vvardenfell/mallapi_base"] = 
            {
                ["x"] = 0.5194997787,
                ["y"] = 0.3272490203,
            },
            ["vvardenfell/sadrithmora_base"] = 
            {
                ["x"] = 0.3869528770,
                ["y"] = 0.1882548034,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            ["stormhaven/pariahcatacombs_base"] = 
            {
                ["x"] = 0.4301457107,
                ["y"] = 0.4577028453,
            },
            ["stormhaven/alcairecastle_base"] = 
            {
                ["x"] = 0.2951657176,
                ["y"] = 0.3298285604,
            },
            ["stormhaven/bonesnapruinssecret_base"] = 
            {
                ["x"] = 0.4975742996,
                ["y"] = 0.3175171316,
            },
            ["stormhaven/godrunsdream_base"] = 
            {
                ["x"] = 0.4834085703,
                ["y"] = 0.7412771583,
            },
            ["stormhaven/windridgecave_base"] = 
            {
                ["x"] = 0.2765971422,
                ["y"] = 0.2868742943,
            },
            ["stormhaven/portdunwatch_base"] = 
            {
                ["x"] = 0.3236285746,
                ["y"] = 0.3078914285,
            },
            ["stormhaven/aphrenshold_base"] = 
            {
                ["x"] = 0.4917228520,
                ["y"] = 0.6410685778,
            },
            ["stormhaven/bearclawmine_base"] = 
            {
                ["x"] = 0.4329885840,
                ["y"] = 0.7857285738,
            },
            ["stormhaven/wayrest_base"] = 
            {
                ["x"] = 0.6020143032,
                ["y"] = 0.3844971359,
            },
            ["stormhaven/norvulkruins_base"] = 
            {
                ["x"] = 0.3670828640,
                ["y"] = 0.6055743098,
            },
        },
        ["deshaan/deshaan_base"] = 
        {
            ["deshaan/bthanual_base"] = 
            {
                ["x"] = 0.4069559872,
                ["y"] = 0.8298749328,
            },
        },
        ["summerset/summerset_base"] = 
        {
            ["summerset/ebonstadmont03_base"] = 
            {
                ["x"] = 0.3468613625,
                ["y"] = 0.3874606490,
            },
            ["summerset/etonnir_01"] = 
            {
                ["x"] = 0.3271756768,
                ["y"] = 0.5096121430,
            },
            ["summerset/sunhold_base"] = 
            {
                ["x"] = 0.3633111417,
                ["y"] = 0.3487282395,
            },
            ["summerset/wastencoraldale_base"] = 
            {
                ["x"] = 0.5220731497,
                ["y"] = 0.2665567696,
            },
            ["summerset/illuminationacademy_01"] = 
            {
                ["x"] = 0.3232491612,
                ["y"] = 0.3171582818,
            },
            ["summerset/ceytarncaveint03_base"] = 
            {
                ["x"] = 0.5509521365,
                ["y"] = 0.3513980210,
            },
            ["summerset/archonsgrove_base"] = 
            {
                ["x"] = 0.5836012363,
                ["y"] = 0.5790919065,
            },
            ["summerset/sq7courtofbedlamruins_base"] = 
            {
                ["x"] = 0.3114149868,
                ["y"] = 0.2188724726,
            },
            ["summerset/sinkhole_base"] = 
            {
                ["x"] = 0.4278960228,
                ["y"] = 0.4365155399,
            },
            ["summerset/sq4sapiarch02_base"] = 
            {
                ["x"] = 0.3934149444,
                ["y"] = 0.1052494198,
            },
            ["summerset/traitorsvault01_base"] = 
            {
                ["x"] = 0.5844435692,
                ["y"] = 0.6670005918,
            },
            ["summerset/russafeldredtemple02_base"] = 
            {
                ["x"] = 0.4036326706,
                ["y"] = 0.4386571348,
            },
            ["summerset/mindtrap_base"] = 
            {
                ["x"] = 0.5049934983,
                ["y"] = 0.5749726295,
            },
            ["summerset/ceytarncaveext01_base"] = 
            {
                ["x"] = 0.5518673062,
                ["y"] = 0.3494780362,
            },
            ["summerset/ui_map"] = 
            {
                ["x"] = 0.3561471999,
                ["y"] = 0.4230011404,
            },
            ["summerset/kingshavenext_base"] = 
            {
                ["x"] = 0.2751277089,
                ["y"] = 0.4893906713,
            },
            ["summerset/corgradwastehigher2_base"] = 
            {
                ["x"] = 0.2811351120,
                ["y"] = 0.2448797524,
            },
            ["summerset/karndar_03"] = 
            {
                ["x"] = 0.3199555576,
                ["y"] = 0.6266152859,
            },
            ["summerset/eldbursanctuary02_base"] = 
            {
                ["x"] = 0.3709714115,
                ["y"] = 0.5544005036,
            },
            ["summerset/sum_karnwasten"] = 
            {
                ["x"] = 0.2091100663,
                ["y"] = 0.3010985851,
            },
            ["summerset/lillandrilcave_base"] = 
            {
                ["x"] = 0.4480309784,
                ["y"] = 0.1849195659,
            },
            ["summerset/torhamekhard_01"] = 
            {
                ["x"] = 0.5443542600,
                ["y"] = 0.4963967800,
            },
            ["summerset/russafeldredtemple01_base"] = 
            {
                ["x"] = 0.4843394756,
                ["y"] = 0.4995644093,
            },
            ["summerset/seakeep_03"] = 
            {
                ["x"] = 0.4341204464,
                ["y"] = 0.2106248140,
            },
            ["summerset/lillandrill_base"] = 
            {
                ["x"] = 0.2625741065,
                ["y"] = 0.5346389413,
            },
            ["summerset/artaeum_base"] = 
            {
                ["x"] = 0.4623057544,
                ["y"] = 0.4480006099,
            },
            ["summerset/alinor_base"] = 
            {
                ["x"] = 0.6571653485,
                ["y"] = 0.6258260608,
            },
            ["summerset/collegeofpsijicsruins_btm"] = 
            {
                ["x"] = 0.4623057544,
                ["y"] = 0.4480006099,
            },
        },
        ["greenshade/greenshade_base"] = 
        {
            ["greenshade/marbruk_base"] = 
            {
                ["x"] = 0.4128727615,
                ["y"] = 0.5915572643,
            },
        },
        ["auridon/auridon_base"] = 
        {
            ["auridon/khenarthisroost_base"] = 
            {
                ["x"] = 0.2228444815,
                ["y"] = 0.3501114547,
            },
        },
        ["grahtwood/grahtwood_base"] = 
        {
            ["grahtwood/eldenrootservices_base"] = 
            {
                ["x"] = 0.3965311348,
                ["y"] = 0.6190371513,
            },
        },
        ["stonefalls/stonefalls_base"] = 
        {
            ["stonefalls/davonswatch_base"] = 
            {
                ["x"] = 0.4937464893,
                ["y"] = 0.5806365609,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            ["glenumbra/spindleclutch_base"] = 
            {
                ["x"] = 0.3366774917,
                ["y"] = 0.7143661976,
            },
            ["glenumbra/silumm_base"] = 
            {
                ["x"] = 0.6779845357,
                ["y"] = 0.2721574605,
            },
            ["glenumbra/tomboflostkings_base"] = 
            {
                ["x"] = 0.2866012454,
                ["y"] = 0.7805057764,
            },
            ["glenumbra/ilessantower_base"] = 
            {
                ["x"] = 0.7259832025,
                ["y"] = 0.3480412066,
            },
            ["glenumbra/cryptwatchfort_base"] = 
            {
                ["x"] = 0.2532835305,
                ["y"] = 0.6058680415,
            },
            ["glenumbra/eboncrypt_base"] = 
            {
                ["x"] = 0.3692837954,
                ["y"] = 0.4798353016,
            },
            ["glenumbra/daggerfall_base"] = 
            {
                ["x"] = 0.7309818864,
                ["y"] = 0.3731749952,
            },
        },
        ["bangkorai/bangkorai_base"] = 
        {
            ["bangkorai/evermore_base"] = 
            {
                ["x"] = 0.5381813645,
                ["y"] = 0.4622465670,
            },
        },
        ["clockwork/clockwork_base"] = 
        {
            ["clockwork/oasis_map2"] = 
            {
                ["x"] = 0.5304951072,
                ["y"] = 0.8646495342,
            },
            ["clockwork/planisphere_1st"] = 
            {
                ["x"] = 0.6010622382,
                ["y"] = 0.5897510052,
            },
            ["clockwork/hallsofregulation_base"] = 
            {
                ["x"] = 0.6411322355,
                ["y"] = 0.8290095329,
            },
            ["clockwork/ccunderground_base"] = 
            {
                ["x"] = 0.5379291177,
                ["y"] = 0.7225139737,
            },
            ["clockwork/ventralterminus01_base"] = 
            {
                ["x"] = 0.6784785986,
                ["y"] = 0.2272743732,
            },
            ["clockwork/ccq1_map3"] = 
            {
                ["x"] = 0.7557187080,
                ["y"] = 0.7180359364,
            },
            ["clockwork/brassfortress_base"] = 
            {
                ["x"] = 0.4424764514,
                ["y"] = 0.4953917861,
            },
        },
    },
    ["quests"] = 
    {
        ["clockwork/clockworkoutlawsrefuge_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Brengolin",
                ["y"] = 0.3236269057,
                ["otherInfo"] = 
                {
                    ["time"] = 1536034433,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Tarnished Truffles",
                ["x"] = 0.8880208135,
            },
            [2] = 
            {
                ["giver"] = "Brengolin",
                ["y"] = 0.3177083433,
                ["preQuest"] = 6059,
                ["otherInfo"] = 
                {
                    ["time"] = 1536097307,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Tasty Tongue Varnish",
                ["x"] = 0.8927556872,
            },
            [3] = 
            {
                ["giver"] = "Brengolin",
                ["y"] = 0.3283617496,
                ["preQuest"] = 6060,
                ["otherInfo"] = 
                {
                    ["time"] = 1536098581,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Matter of Tenderness",
                ["x"] = 0.8754734993,
            },
            [4] = 
            {
                ["giver"] = "Brengolin",
                ["y"] = 0.3283617496,
                ["preQuest"] = 6074,
                ["otherInfo"] = 
                {
                    ["time"] = 1538439895,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Tarnished Truffles",
                ["x"] = 0.8863636255,
            },
            [5] = 
            {
                ["giver"] = "Brengolin",
                ["y"] = 0.3257575631,
                ["preQuest"] = 6059,
                ["otherInfo"] = 
                {
                    ["time"] = 1538443123,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Tasty Tongue Varnish",
                ["x"] = 0.9019886255,
            },
            [6] = 
            {
                ["giver"] = "Brengolin",
                ["y"] = 0.3293087184,
                ["preQuest"] = 6060,
                ["otherInfo"] = 
                {
                    ["time"] = 1538455504,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Matter of Tenderness",
                ["x"] = 0.8813920617,
            },
        },
        ["summerset/sunhold_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Kinlady Helenaere",
                ["y"] = 0.7812337875,
                ["otherInfo"] = 
                {
                    ["time"] = 1535584965,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Sunhold Sundered",
                ["x"] = 0.7326334715,
            },
        },
        ["rivenspire/tribulationcrypt_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Ancient Sword",
                ["y"] = 0.1962851435,
                ["preQuest"] = 4844,
                ["otherInfo"] = 
                {
                    ["time"] = 1534718973,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Past Remembered",
                ["x"] = 0.2981927693,
            },
        },
        ["clockwork/basilica_01"] = 
        {
            [4] = 
            {
                ["giver"] = "Sotha Sil",
                ["y"] = 0.2434875369,
                ["preQuest"] = 6047,
                ["otherInfo"] = 
                {
                    ["time"] = 1538504633,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Light of Knowledge",
                ["x"] = 0.5245828629,
            },
            [1] = 
            {
                ["giver"] = "Provost Varuni Arvel",
                ["y"] = 0.3126277924,
                ["preQuest"] = 6063,
                ["otherInfo"] = 
                {
                    ["time"] = 1538258874,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Deepening Shadows",
                ["x"] = 0.5268352032,
            },
            [2] = 
            {
                ["giver"] = "Provost Varuni Arvel",
                ["y"] = 0.5384524465,
                ["preQuest"] = 6025,
                ["otherInfo"] = 
                {
                    ["time"] = 1538262514,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Lost in the Gloam",
                ["x"] = 0.8605933189,
            },
            [3] = 
            {
                ["giver"] = "Proctor Luciana Pullo",
                ["y"] = 0.4670301974,
                ["preQuest"] = 6052,
                ["otherInfo"] = 
                {
                    ["time"] = 1538364995,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Unto the Dark",
                ["x"] = 0.3012476563,
            },
        },
        ["stormhaven/norvulkruins_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Matys Derone",
                ["y"] = 0.8044354916,
                ["otherInfo"] = 
                {
                    ["time"] = 1534368364,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Word from the Dead",
                ["x"] = 0.5907257795,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Darien Gautier",
                ["y"] = 0.7394628525,
                ["preQuest"] = 4901,
                ["otherInfo"] = 
                {
                    ["time"] = 1534398094,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Shornhelm Divided",
                ["x"] = 0.4597792029,
            },
            [2] = 
            {
                ["giver"] = "Daribert Hurier",
                ["y"] = 0.6906269193,
                ["otherInfo"] = 
                {
                    ["time"] = 1534398418,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Under Siege",
                ["x"] = 0.4797356725,
            },
            [3] = 
            {
                ["giver"] = "Scholar Cantier",
                ["y"] = 0.5729492903,
                ["otherInfo"] = 
                {
                    ["time"] = 1534458595,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Traitor's Tale",
                ["x"] = 0.5490812063,
            },
            [4] = 
            {
                ["giver"] = "Jowan Hinault",
                ["y"] = 0.6188712120,
                ["preQuest"] = 3286,
                ["otherInfo"] = 
                {
                    ["time"] = 1534458893,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Dearly Departed",
                ["x"] = 0.4653404057,
            },
            [5] = 
            {
                ["giver"] = "Bumnog",
                ["y"] = 0.6888028383,
                ["otherInfo"] = 
                {
                    ["time"] = 1534547666,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Rusty Daggers",
                ["x"] = 0.3692457676,
            },
            [6] = 
            {
                ["giver"] = "Nathalye Ervine",
                ["y"] = 0.6280971169,
                ["preQuest"] = 5012,
                ["otherInfo"] = 
                {
                    ["time"] = 1534553708,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "In the Doghouse",
                ["x"] = 0.2783106267,
            },
            [7] = 
            {
                ["giver"] = "Michel Gette",
                ["y"] = 0.6459167004,
                ["otherInfo"] = 
                {
                    ["time"] = 1534553764,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Blood-Cursed Town",
                ["x"] = 0.2556575239,
            },
            [8] = 
            {
                ["giver"] = "Count Verandis Ravenwatch",
                ["y"] = 0.4514686763,
                ["preQuest"] = 4903,
                ["otherInfo"] = 
                {
                    ["time"] = 1534567301,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Blood-Splattered Shield",
                ["x"] = 0.2930417359,
            },
            [9] = 
            {
                ["giver"] = "Gwendis",
                ["y"] = 0.6468122602,
                ["preQuest"] = 465,
                ["otherInfo"] = 
                {
                    ["time"] = 1534627281,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Concealing Veil",
                ["x"] = 0.2146217972,
            },
            [10] = 
            {
                ["giver"] = "Federic Seychelle",
                ["y"] = 0.4664203823,
                ["otherInfo"] = 
                {
                    ["time"] = 1534627498,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Change of Heart",
                ["x"] = 0.6914007068,
            },
            [11] = 
            {
                ["giver"] = "Count Verandis Ravenwatch",
                ["y"] = 0.4809440672,
                ["preQuest"] = 4857,
                ["otherInfo"] = 
                {
                    ["time"] = 1534631512,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Northpoint in Peril",
                ["x"] = 0.5995568037,
            },
            [12] = 
            {
                ["giver"] = "Alvaren Garoutte",
                ["y"] = 0.5149237514,
                ["otherInfo"] = 
                {
                    ["time"] = 1534631587,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Archaic Relics",
                ["x"] = 0.5871042013,
            },
            [13] = 
            {
                ["giver"] = "Marisette",
                ["y"] = 0.6254729033,
                ["otherInfo"] = 
                {
                    ["time"] = 1534634478,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Crimes of the Past",
                ["x"] = 0.6284329295,
            },
            [14] = 
            {
                ["giver"] = "Adusa-daro",
                ["y"] = 0.6622117758,
                ["otherInfo"] = 
                {
                    ["time"] = 1534634772,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Hope Lost",
                ["x"] = 0.6064910293,
            },
            [15] = 
            {
                ["giver"] = "Strange Sapling",
                ["y"] = 0.5597689748,
                ["otherInfo"] = 
                {
                    ["time"] = 1534651278,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Price of Longevity",
                ["x"] = 0.6333553791,
            },
            [16] = 
            {
                ["giver"] = "Adusa-daro",
                ["y"] = 0.4603060186,
                ["preQuest"] = 4926,
                ["otherInfo"] = 
                {
                    ["time"] = 1534736590,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Assassin's List",
                ["x"] = 0.2959030271,
            },
            [17] = 
            {
                ["giver"] = "Lieutenant Sgugh",
                ["y"] = 0.6350313425,
                ["otherInfo"] = 
                {
                    ["time"] = 1534737005,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Sanctifying Flames",
                ["x"] = 0.2673034668,
            },
            [18] = 
            {
                ["giver"] = "Adusa-daro",
                ["y"] = 0.4686428905,
                ["preQuest"] = 4927,
                ["otherInfo"] = 
                {
                    ["time"] = 1534737994,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Threat of Death",
                ["x"] = 0.2859297097,
            },
            [19] = 
            {
                ["giver"] = "Adusa-daro",
                ["y"] = 0.4693705440,
                ["preQuest"] = 4928,
                ["otherInfo"] = 
                {
                    ["time"] = 1534738422,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Dagger to the Heart",
                ["x"] = 0.2863873839,
            },
            [20] = 
            {
                ["giver"] = "Constable Agazu",
                ["y"] = 0.4420057237,
                ["preQuest"] = 4965,
                ["otherInfo"] = 
                {
                    ["time"] = 1534742538,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Frightened Folk",
                ["x"] = 0.6877788305,
            },
            [21] = 
            {
                ["giver"] = "Constable Agazu",
                ["y"] = 0.4126192331,
                ["preQuest"] = 4931,
                ["otherInfo"] = 
                {
                    ["time"] = 1534810643,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Fell's Justice",
                ["x"] = 0.7006397247,
            },
            [22] = 
            {
                ["giver"] = "Beryn",
                ["y"] = 0.6250448823,
                ["preQuest"] = 5312,
                ["otherInfo"] = 
                {
                    ["time"] = 1534831726,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Spider's Cocoon",
                ["x"] = 0.1827658564,
            },
            [23] = 
            {
                ["giver"] = "Lothson Cold-Eye",
                ["y"] = 0.2306008041,
                ["otherInfo"] = 
                {
                    ["time"] = 1534913311,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Lady's Keepsake",
                ["x"] = 0.7315177917,
            },
            [24] = 
            {
                ["giver"] = "Lady Clarisse Laurent",
                ["y"] = 0.2659831345,
                ["otherInfo"] = 
                {
                    ["time"] = 1534983366,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Emerald Chalice",
                ["x"] = 0.6774894595,
            },
            [25] = 
            {
                ["giver"] = "Gwendis",
                ["y"] = 0.3771019280,
                ["preQuest"] = 4884,
                ["otherInfo"] = 
                {
                    ["time"] = 1534999198,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Crown of Shornhelm",
                ["x"] = 0.3189841807,
            },
        },
        ["vvardenfell/sadrithmora_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Eoki",
                ["y"] = 0.4552703798,
                ["otherInfo"] = 
                {
                    ["time"] = 1536778382,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Hireling of House Telvanni",
                ["x"] = 0.2976600230,
            },
            [2] = 
            {
                ["giver"] = "Llonas Givyn",
                ["y"] = 0.5542289615,
                ["otherInfo"] = 
                {
                    ["time"] = 1536778413,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Bound by Love",
                ["x"] = 0.3116475642,
            },
            [3] = 
            {
                ["giver"] = "Eoki",
                ["y"] = 0.3695585728,
                ["preQuest"] = 5799,
                ["otherInfo"] = 
                {
                    ["time"] = 1536896431,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Rising to Retainer",
                ["x"] = 0.3429779112,
            },
            [4] = 
            {
                ["giver"] = "Eoki",
                ["y"] = 0.3551135063,
                ["preQuest"] = 5859,
                ["otherInfo"] = 
                {
                    ["time"] = 1537668902,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Objections and Obstacles",
                ["x"] = 0.3371606469,
            },
            [5] = 
            {
                ["giver"] = "Sun-in-Shadow",
                ["y"] = 0.3918471336,
                ["preQuest"] = 5901,
                ["otherInfo"] = 
                {
                    ["time"] = 1537744209,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Magister Makes a Move",
                ["x"] = 0.3435879648,
            },
        },
        ["vvardenfell/vivechow01a_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Librarian Bradyn",
                ["y"] = 0.5169770122,
                ["otherInfo"] = 
                {
                    ["time"] = 1537857516,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Lost Library",
                ["x"] = 0.7569060922,
            },
            [1] = 
            {
                ["giver"] = "Librarian Bradyn",
                ["y"] = 0.4151149988,
                ["preQuest"] = 5885,
                ["otherInfo"] = 
                {
                    ["time"] = 1537504216,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Ancestral Tombs",
                ["x"] = 0.7845304012,
            },
        },
        ["vvardenfell/forgottenwastesext_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Tythis Nirith",
                ["y"] = 0.2666381299,
                ["preQuest"] = 5886,
                ["otherInfo"] = 
                {
                    ["time"] = 1537568779,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Echoes of a Fallen House",
                ["x"] = 0.8313843012,
            },
        },
        ["glenumbra/ilessantower_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Red Rook Note",
                ["y"] = 0.7700323462,
                ["otherInfo"] = 
                {
                    ["time"] = 1533684860,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Red Rook Resources",
                ["x"] = 0.5450952053,
            },
        },
        ["glenumbra/badmanscave_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Finvir",
                ["y"] = 0.5939509273,
                ["otherInfo"] = 
                {
                    ["time"] = 1533694067,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Can't Take It With Them",
                ["x"] = 0.6003810167,
            },
        },
        ["alikr/salasen_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Gurlak",
                ["y"] = 0.7185712457,
                ["otherInfo"] = 
                {
                    ["time"] = 1536021367,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Oldest Orc",
                ["x"] = 0.2225854546,
            },
        },
        ["glenumbra/minesofkhuras_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Guifford Vinielle's Sketchbook",
                ["y"] = 0.7706518769,
                ["preQuest"] = 3440,
                ["otherInfo"] = 
                {
                    ["time"] = 1533705261,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "A Brush With Death",
                ["x"] = 0.3869094849,
            },
        },
        ["bangkorai/jaggerjaw_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Pelorrah's Research Notes",
                ["y"] = 0.4742585421,
                ["otherInfo"] = 
                {
                    ["time"] = 1538277527,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Urenenya's Lament",
                ["x"] = 0.4443200827,
            },
        },
        ["glenumbra/badmansstart_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Curator Nicholas",
                ["y"] = 0.6460055113,
                ["preQuest"] = 4767,
                ["otherInfo"] = 
                {
                    ["time"] = 1533693555,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Season of Harvest",
                ["x"] = 0.4435261786,
            },
        },
        ["stormhaven/portdunwatch_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Remy Berard",
                ["y"] = 0.3056835532,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943190,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Do as I Say",
                ["x"] = 0.4718382061,
            },
        },
        ["grahtwood/eldenrootcrafting_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8027322292,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167461,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.5290710330,
            },
            [2] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8027322292,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167461,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.5290710330,
            },
            [3] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8027322292,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167462,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.5290710330,
            },
            [4] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8027322292,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167462,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.5290710330,
            },
            [5] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.4062841535,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167478,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.7377595901,
            },
            [6] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.4062841535,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167478,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.7377595901,
            },
            [7] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.4062841535,
                ["otherInfo"] = 
                {
                    ["time"] = 1536167479,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.7377595901,
            },
        },
        ["alikr/bergama_base"] = 
        {
            [4] = 
            {
                ["giver"] = "Jarrod",
                ["y"] = 0.2626455426,
                ["preQuest"] = 2344,
                ["otherInfo"] = 
                {
                    ["time"] = 1536381627,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Trapped in the Bluffs",
                ["x"] = 0.7893781066,
            },
            [1] = 
            {
                ["giver"] = "Qadim",
                ["y"] = 0.5567598939,
                ["preQuest"] = 3344,
                ["otherInfo"] = 
                {
                    ["time"] = 1536373428,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Gone Missing",
                ["x"] = 0.1632595807,
            },
            [2] = 
            {
                ["giver"] = "Jagnas",
                ["y"] = 0.4496798813,
                ["otherInfo"] = 
                {
                    ["time"] = 1536376454,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Left at the Altar",
                ["x"] = 0.5938260555,
            },
            [3] = 
            {
                ["giver"] = "Meriq",
                ["y"] = 0.4399827719,
                ["preQuest"] = 2251,
                ["otherInfo"] = 
                {
                    ["time"] = 1536378812,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Trouble at Tava's Blessing",
                ["x"] = 0.5318244696,
            },
        },
        ["vvardenfell/vivecthroneroom01_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Vivec",
                ["y"] = 0.6491472721,
                ["preQuest"] = 5803,
                ["otherInfo"] = 
                {
                    ["time"] = 1536777197,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Divine Inquiries",
                ["x"] = 0.4857364297,
            },
            [2] = 
            {
                ["giver"] = "Archcanon Tarvus",
                ["y"] = 0.5897674561,
                ["preQuest"] = 5880,
                ["otherInfo"] = 
                {
                    ["time"] = 1537504564,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Divine Delusions",
                ["x"] = 0.5446511507,
            },
            [3] = 
            {
                ["giver"] = "Archcanon Tarvus",
                ["y"] = 0.6257364154,
                ["preQuest"] = 5888,
                ["otherInfo"] = 
                {
                    ["time"] = 1537926477,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Divine Intervention",
                ["x"] = 0.4765891433,
            },
        },
        ["glenumbra/cryptwatchfort_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Hastily Scribbled Note",
                ["y"] = 0.3049505055,
                ["preQuest"] = 4080,
                ["otherInfo"] = 
                {
                    ["time"] = 1533695799,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Fortune in Failure",
                ["x"] = 0.3861386180,
            },
        },
        ["deshaan/deshaan_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Raynor Vanos",
                ["y"] = 0.5501175523,
                ["preQuest"] = 4925,
                ["otherInfo"] = 
                {
                    ["time"] = 1538282433,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Dungeon Delvers",
                ["x"] = 0.3450325131,
            },
            [1] = 
            {
                ["giver"] = "Risa's Journal",
                ["y"] = 0.5704402328,
                ["otherInfo"] = 
                {
                    ["time"] = 1536986793,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Remembering Risa",
                ["x"] = 0.6753426790,
            },
        },
        ["glenumbra/crosswych_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Tamien Sellan",
                ["y"] = 0.6053073406,
                ["preQuest"] = 3337,
                ["otherInfo"] = 
                {
                    ["time"] = 1533595782,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Miners' Lament",
                ["x"] = 0.6166941524,
            },
            [2] = 
            {
                ["giver"] = "Tamien Sellan",
                ["y"] = 0.6034337878,
                ["preQuest"] = 3302,
                ["otherInfo"] = 
                {
                    ["time"] = 1533596819,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Crosswych Reclaimed",
                ["x"] = 0.6395968795,
            },
            [3] = 
            {
                ["giver"] = "Alessio Guillon",
                ["y"] = 0.5922731757,
                ["otherInfo"] = 
                {
                    ["time"] = 1533608597,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Missing Prophecy",
                ["x"] = 0.6025131345,
            },
            [4] = 
            {
                ["giver"] = "Bera Moorsmith",
                ["y"] = 0.5522983670,
                ["otherInfo"] = 
                {
                    ["time"] = 1533608894,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Anchors from the Harbour",
                ["x"] = 0.5974093080,
            },
            [5] = 
            {
                ["giver"] = "Adelle Montagne",
                ["y"] = 0.6174532175,
                ["otherInfo"] = 
                {
                    ["time"] = 1533609272,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Long Lost Lore",
                ["x"] = 0.4721064568,
            },
        },
        ["rivenspire/shornhelm_base"] = 
        {
            [1] = 
            {
                ["giver"] = "High King Emeric",
                ["y"] = 0.2087104321,
                ["preQuest"] = 4902,
                ["otherInfo"] = 
                {
                    ["time"] = 1534547100,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Dream-Walk Into Darkness",
                ["x"] = 0.5924155712,
            },
            [2] = 
            {
                ["giver"] = "Adusa-daro",
                ["y"] = 0.3165285885,
                ["preQuest"] = 4834,
                ["otherInfo"] = 
                {
                    ["time"] = 1534720776,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Spy in Shornhelm",
                ["x"] = 0.5225196481,
            },
            [3] = 
            {
                ["giver"] = "Nicolene",
                ["y"] = 0.6325260401,
                ["otherInfo"] = 
                {
                    ["time"] = 1534724812,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Children of Yokuda",
                ["x"] = 0.4601444602,
            },
            [4] = 
            {
                ["giver"] = "Adusa-daro",
                ["y"] = 0.3113873005,
                ["preQuest"] = 4945,
                ["otherInfo"] = 
                {
                    ["time"] = 1534735695,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Assassin Hunter",
                ["x"] = 0.5138304830,
            },
            [5] = 
            {
                ["giver"] = "Queen Maraya",
                ["y"] = 0.2218610644,
                ["preQuest"] = 4936,
                ["otherInfo"] = 
                {
                    ["time"] = 1535066382,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Favor for the Queen",
                ["x"] = 0.6035054326,
            },
            [6] = 
            {
                ["giver"] = "Arch-Mage Shalidor",
                ["y"] = 0.6464839578,
                ["preQuest"] = 3918,
                ["otherInfo"] = 
                {
                    ["time"] = 1535870022,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Chateau of the Ravenous Rodent",
                ["x"] = 0.3513490558,
            },
        },
        ["eastmarch/eastmarch_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Raynor Vanos",
                ["y"] = 0.5120099783,
                ["preQuest"] = 3721,
                ["otherInfo"] = 
                {
                    ["time"] = 1538347686,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "In Search of Kireth Vanos",
                ["x"] = 0.6498125196,
            },
        },
        ["alikr/alikr_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Herminius Sophus",
                ["y"] = 0.4980856478,
                ["otherInfo"] = 
                {
                    ["time"] = 1535068408,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Past in Ruins",
                ["x"] = 0.1420014948,
            },
            [2] = 
            {
                ["giver"] = "Lady Clarisse Laurent",
                ["y"] = 0.6744162440,
                ["otherInfo"] = 
                {
                    ["time"] = 1536019893,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Thwarting the Aldmeri Dominion",
                ["x"] = 0.2751331925,
            },
            [3] = 
            {
                ["giver"] = "Stibbons",
                ["y"] = 0.6599228382,
                ["otherInfo"] = 
                {
                    ["time"] = 1536020090,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Lady Laurent's Favor",
                ["x"] = 0.2463007271,
            },
            [4] = 
            {
                ["giver"] = "Marimah",
                ["y"] = 0.6580856442,
                ["preQuest"] = 4672,
                ["otherInfo"] = 
                {
                    ["time"] = 1536178583,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Initiation",
                ["x"] = 0.2971570790,
            },
            [5] = 
            {
                ["giver"] = "Talia at-Marimah",
                ["y"] = 0.6594074965,
                ["preQuest"] = 4686,
                ["otherInfo"] = 
                {
                    ["time"] = 1536180217,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ash'abah Rising",
                ["x"] = 0.2966592014,
            },
            [6] = 
            {
                ["giver"] = "Anjan",
                ["y"] = 0.6000323892,
                ["otherInfo"] = 
                {
                    ["time"] = 1536180330,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Nature of Fate",
                ["x"] = 0.3212123513,
            },
            [7] = 
            {
                ["giver"] = "Throne Keeper Farvad",
                ["y"] = 0.5750286579,
                ["otherInfo"] = 
                {
                    ["time"] = 1536279743,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Tu'whacca's Breath",
                ["x"] = 0.3972641230,
            },
            [8] = 
            {
                ["giver"] = "Ramati at-Gar",
                ["y"] = 0.5544087887,
                ["preQuest"] = 3190,
                ["otherInfo"] = 
                {
                    ["time"] = 1536279855,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Revered Ancestors",
                ["x"] = 0.4091062844,
            },
            [9] = 
            {
                ["giver"] = "Throne Keeper Farvad",
                ["y"] = 0.5306970477,
                ["preQuest"] = 2184,
                ["otherInfo"] = 
                {
                    ["time"] = 1536352135,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Reckoning with Uwafa",
                ["x"] = 0.4021185040,
            },
            [10] = 
            {
                ["giver"] = "Throne Keeper Farvad",
                ["y"] = 0.5306920409,
                ["preQuest"] = 2192,
                ["otherInfo"] = 
                {
                    ["time"] = 1536352628,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Scholar of Bergama",
                ["x"] = 0.4317500591,
            },
            [11] = 
            {
                ["giver"] = "Samsi af-Bazra",
                ["y"] = 0.5347821712,
                ["otherInfo"] = 
                {
                    ["time"] = 1536372240,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Badwater Mine",
                ["x"] = 0.3236694038,
            },
            [12] = 
            {
                ["giver"] = "Hayazzin",
                ["y"] = 0.6404829621,
                ["preQuest"] = 3383,
                ["otherInfo"] = 
                {
                    ["time"] = 1536372763,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Satak was the First Serpent",
                ["x"] = 0.3955812752,
            },
            [13] = 
            {
                ["giver"] = "Letta",
                ["y"] = 0.5868707895,
                ["otherInfo"] = 
                {
                    ["time"] = 1536381303,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Snakes in the Sands",
                ["x"] = 0.5881976485,
            },
            [14] = 
            {
                ["giver"] = "Darius",
                ["y"] = 0.5111326575,
                ["otherInfo"] = 
                {
                    ["time"] = 1536428264,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Honoring the Dishonored",
                ["x"] = 0.8310804367,
            },
            [15] = 
            {
                ["giver"] = "Onwyn",
                ["y"] = 0.6113567352,
                ["preQuest"] = 3970,
                ["otherInfo"] = 
                {
                    ["time"] = 1536447037,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Winner for Onwyn",
                ["x"] = 0.4959322810,
            },
            [16] = 
            {
                ["giver"] = "Kasal",
                ["y"] = 0.5169479847,
                ["otherInfo"] = 
                {
                    ["time"] = 1536457310,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Crawling Chaos",
                ["x"] = 0.5143863559,
            },
            [17] = 
            {
                ["giver"] = "Leki's Disciple",
                ["y"] = 0.5050261617,
                ["preQuest"] = 2255,
                ["otherInfo"] = 
                {
                    ["time"] = 1536458167,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Master of Leki's Blade",
                ["x"] = 0.5780732036,
            },
            [18] = 
            {
                ["giver"] = "Musi",
                ["y"] = 0.5162708759,
                ["otherInfo"] = 
                {
                    ["time"] = 1536458202,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Undying Loyalty",
                ["x"] = 0.5640453100,
            },
            [19] = 
            {
                ["giver"] = "Hadoon",
                ["y"] = 0.5207567811,
                ["preQuest"] = 4754,
                ["otherInfo"] = 
                {
                    ["time"] = 1536461018,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Nature of Fate: Part Two",
                ["x"] = 0.6632511616,
            },
            [20] = 
            {
                ["giver"] = "Throne Keeper Farvad",
                ["y"] = 0.5130893588,
                ["preQuest"] = 3367,
                ["otherInfo"] = 
                {
                    ["time"] = 1536463157,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "March of the Ra Gada",
                ["x"] = 0.7338088155,
            },
            [21] = 
            {
                ["giver"] = "Throne Keeper Farvad",
                ["y"] = 0.5679935217,
                ["preQuest"] = 2356,
                ["otherInfo"] = 
                {
                    ["time"] = 1536467785,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Trials of the Hero",
                ["x"] = 0.7541349530,
            },
            [22] = 
            {
                ["giver"] = "Uhrih",
                ["y"] = 0.4839780927,
                ["preQuest"] = 3296,
                ["otherInfo"] = 
                {
                    ["time"] = 1536468477,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Malignant Militia",
                ["x"] = 0.6972267628,
            },
            [23] = 
            {
                ["giver"] = "Aqabi of the Ungodly",
                ["y"] = 0.4343739152,
                ["preQuest"] = 4731,
                ["otherInfo"] = 
                {
                    ["time"] = 1536469203,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Whose Wedding?",
                ["x"] = 0.5570375919,
            },
            [24] = 
            {
                ["giver"] = "Talia at-Marimah",
                ["y"] = 0.3558725417,
                ["preQuest"] = 4760,
                ["otherInfo"] = 
                {
                    ["time"] = 1536535974,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alasan's Plot",
                ["x"] = 0.5669330359,
            },
            [25] = 
            {
                ["giver"] = "Jeromec Lemal",
                ["y"] = 0.3352153301,
                ["otherInfo"] = 
                {
                    ["time"] = 1536536153,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Warship Designs",
                ["x"] = 0.5701867342,
            },
            [26] = 
            {
                ["giver"] = "Shiri",
                ["y"] = 0.3564052880,
                ["preQuest"] = 2222,
                ["otherInfo"] = 
                {
                    ["time"] = 1536554353,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Shiri's Research",
                ["x"] = 0.5660890937,
            },
            [27] = 
            {
                ["giver"] = "Captain Rawan",
                ["y"] = 0.5097684860,
                ["preQuest"] = 2240,
                ["otherInfo"] = 
                {
                    ["time"] = 1536617240,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Search for Shiri",
                ["x"] = 0.7369155884,
            },
            [28] = 
            {
                ["giver"] = "General Thoda",
                ["y"] = 0.3919790983,
                ["otherInfo"] = 
                {
                    ["time"] = 1536617590,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Imperial Incursion",
                ["x"] = 0.8402663469,
            },
            [29] = 
            {
                ["giver"] = "High Priest Zuladr",
                ["y"] = 0.3394672573,
                ["otherInfo"] = 
                {
                    ["time"] = 1536618662,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Temple's Treasures",
                ["x"] = 0.8084615469,
            },
            [30] = 
            {
                ["giver"] = "General Thoda",
                ["y"] = 0.3409484625,
                ["preQuest"] = 2404,
                ["otherInfo"] = 
                {
                    ["time"] = 1536622233,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Amputating the Hand",
                ["x"] = 0.8407717347,
            },
            [31] = 
            {
                ["giver"] = "Ansei Halelah",
                ["y"] = 0.2969753444,
                ["preQuest"] = 2997,
                ["otherInfo"] = 
                {
                    ["time"] = 1536637029,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Restoring the Ansei Wards",
                ["x"] = 0.7744261622,
            },
        },
        ["summerset/etonnir_01"] = 
        {
            [1] = 
            {
                ["giver"] = "Seeks-the-Dark",
                ["y"] = 0.3739441335,
                ["preQuest"] = 6174,
                ["otherInfo"] = 
                {
                    ["time"] = 1535321772,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Looting the Light",
                ["x"] = 0.9197530746,
            },
        },
        ["alikr/sandblownmine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Letter to Fadeel",
                ["y"] = 0.4986650050,
                ["otherInfo"] = 
                {
                    ["time"] = 1536431569,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Real Snake",
                ["x"] = 0.5561488867,
            },
        },
        ["summerset/artaeum_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Ulliceta gra-Kogg",
                ["y"] = 0.4446600974,
                ["otherInfo"] = 
                {
                    ["time"] = 1535594843,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Half-Formed Understandings",
                ["x"] = 0.3989331722,
            },
            [1] = 
            {
                ["giver"] = "Ritemaster Iachesis",
                ["y"] = 0.2702807188,
                ["preQuest"] = 6096,
                ["otherInfo"] = 
                {
                    ["time"] = 1535331163,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Pearl of Great Price",
                ["x"] = 0.6434336305,
            },
        },
        ["summerset/alinor_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Vandoril",
                ["y"] = 0.6473568082,
                ["preQuest"] = 6097,
                ["otherInfo"] = 
                {
                    ["time"] = 1535250228,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Checking on Cloudrest",
                ["x"] = 0.2997643054,
            },
            [2] = 
            {
                ["giver"] = "Roguzog",
                ["y"] = 0.4404526651,
                ["otherInfo"] = 
                {
                    ["time"] = 1535250333,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Duelist's Dilemma",
                ["x"] = 0.2337974161,
            },
            [3] = 
            {
                ["giver"] = "Battlereeve Tanerline",
                ["y"] = 0.5066245198,
                ["otherInfo"] = 
                {
                    ["time"] = 1535602223,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Abyssal Cabal",
                ["x"] = 0.6147393584,
            },
            [4] = 
            {
                ["giver"] = "Rigurt the Brash",
                ["y"] = 0.5052776337,
                ["otherInfo"] = 
                {
                    ["time"] = 1535602261,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Culture Clash",
                ["x"] = 0.6475471258,
            },
            [5] = 
            {
                ["giver"] = "Battlereeve Tanerline",
                ["y"] = 0.7019631863,
                ["preQuest"] = 6165,
                ["otherInfo"] = 
                {
                    ["time"] = 1535676619,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Sinking Summerset",
                ["x"] = 0.4284041226,
            },
            [6] = 
            {
                ["giver"] = "Millenith",
                ["y"] = 0.6079903841,
                ["preQuest"] = 4961,
                ["otherInfo"] = 
                {
                    ["time"] = 1536297803,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Crafting Certification",
                ["x"] = 0.5599572659,
            },
            [7] = 
            {
                ["giver"] = "Millenith",
                ["y"] = 0.6079903841,
                ["preQuest"] = 5259,
                ["otherInfo"] = 
                {
                    ["time"] = 1536297818,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Certification",
                ["x"] = 0.5599572659,
            },
            [8] = 
            {
                ["giver"] = "Millenith",
                ["y"] = 0.6068924069,
                ["preQuest"] = 5249,
                ["otherInfo"] = 
                {
                    ["time"] = 1536369985,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Certification",
                ["x"] = 0.5654178858,
            },
            [9] = 
            {
                ["giver"] = "Justiciar Farowel",
                ["y"] = 0.5967177749,
                ["preQuest"] = 6084,
                ["otherInfo"] = 
                {
                    ["time"] = 1537826615,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Run Aground",
                ["x"] = 0.4304976165,
            },
            [10] = 
            {
                ["giver"] = "Justiciar Tanorian",
                ["y"] = 0.5856354237,
                ["preQuest"] = 6159,
                ["otherInfo"] = 
                {
                    ["time"] = 1537829054,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Struck from Memory",
                ["x"] = 0.4253297746,
            },
            [11] = 
            {
                ["giver"] = "Justiciar Tanorian",
                ["y"] = 0.5778324604,
                ["otherInfo"] = 
                {
                    ["time"] = 1538104582,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Rose's Beauty",
                ["x"] = 0.4276574850,
            },
            [12] = 
            {
                ["giver"] = "Justiciar Tanorian",
                ["y"] = 0.5779202580,
                ["otherInfo"] = 
                {
                    ["time"] = 1538104658,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Rose's Beauty",
                ["x"] = 0.4279502928,
            },
            [13] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8094924092,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167766,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.3138917089,
            },
            [14] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8094924092,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167766,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.3138917089,
            },
            [15] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8094924092,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167766,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.3138917089,
            },
            [16] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.8094924092,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167766,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.3138917089,
            },
            [17] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.8114981055,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167770,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.3212994337,
            },
            [18] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.8114981055,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167771,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.3212994337,
            },
            [19] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.8114981055,
                ["otherInfo"] = 
                {
                    ["time"] = 1538167771,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.3212994337,
            },
        },
        ["clockwork/clockwork_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Neramo",
                ["y"] = 0.4488490522,
                ["preQuest"] = 6050,
                ["otherInfo"] = 
                {
                    ["time"] = 1538090124,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "In Search of a Sponsor",
                ["x"] = 0.4996975958,
            },
            [2] = 
            {
                ["giver"] = "CCHW-04",
                ["y"] = 0.4961888492,
                ["otherInfo"] = 
                {
                    ["time"] = 1538368120,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Registrar's Request",
                ["x"] = 0.8266223073,
            },
            [3] = 
            {
                ["giver"] = "Sherizar",
                ["y"] = 0.5282200575,
                ["otherInfo"] = 
                {
                    ["time"] = 1538368262,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Oasis in a Metal Desert",
                ["x"] = 0.7896364331,
            },
            [4] = 
            {
                ["giver"] = "Tilelle the Mender",
                ["y"] = 0.6384005547,
                ["otherInfo"] = 
                {
                    ["time"] = 1538440674,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Halls of Regulation",
                ["x"] = 0.8291336894,
            },
            [5] = 
            {
                ["giver"] = "Adjunct Daro",
                ["y"] = 0.5775425434,
                ["otherInfo"] = 
                {
                    ["time"] = 1538457311,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Shadow Cleft",
                ["x"] = 0.2695233226,
            },
            [6] = 
            {
                ["giver"] = "Inactive Brassilisk",
                ["y"] = 0.4767026007,
                ["preQuest"] = 6092,
                ["otherInfo"] = 
                {
                    ["time"] = 1538521653,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Broken Brassilisk",
                ["x"] = 0.2180058658,
            },
        },
        ["rivenspire/hildunessecretrefuge_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Nadafa's Journal",
                ["y"] = 0.3277197778,
                ["otherInfo"] = 
                {
                    ["time"] = 1534896674,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Love Lost",
                ["x"] = 0.6928258538,
            },
        },
        ["rivenspire/northpoint_base"] = 
        {
            [4] = 
            {
                ["giver"] = "Blademaster Qariar",
                ["y"] = 0.5237141848,
                ["preQuest"] = 4916,
                ["otherInfo"] = 
                {
                    ["time"] = 1534915414,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Last of Them",
                ["x"] = 0.3138366342,
            },
            [1] = 
            {
                ["giver"] = "Skordo the Knife",
                ["y"] = 0.1727312952,
                ["preQuest"] = 4958,
                ["otherInfo"] = 
                {
                    ["time"] = 1534897233,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Liberation of Northpoint",
                ["x"] = 0.4576599598,
            },
            [2] = 
            {
                ["giver"] = "Baron Alard Dorell",
                ["y"] = 0.5755673051,
                ["preQuest"] = 4972,
                ["otherInfo"] = 
                {
                    ["time"] = 1534915013,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Puzzle of the Pass",
                ["x"] = 0.5080171227,
            },
            [3] = 
            {
                ["giver"] = "Short-Tail",
                ["y"] = 0.4246223271,
                ["otherInfo"] = 
                {
                    ["time"] = 1534915193,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Guar Gone",
                ["x"] = 0.6390510201,
            },
        },
        ["rivenspire/obsidianscar_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Lashgikh",
                ["y"] = 0.8949609399,
                ["preQuest"] = 4923,
                ["otherInfo"] = 
                {
                    ["time"] = 1534833619,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Foul Deeds in the Deep",
                ["x"] = 0.3315152228,
            },
        },
        ["rivenspire/flyleafcatacombs_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Handre's Last Will",
                ["y"] = 0.1988012046,
                ["preQuest"] = 4942,
                ["otherInfo"] = 
                {
                    ["time"] = 1534832824,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Fadeel's Freedom",
                ["x"] = 0.3211788237,
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Recruit Maelle",
                ["y"] = 0.2641271353,
                ["preQuest"] = 3379,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506571,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "A Dangerous Dream",
                ["x"] = 0.6233919263,
            },
            [2] = 
            {
                ["giver"] = "Garmeg the Ironfinder",
                ["y"] = 0.2552480102,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506619,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Legitimate Interests",
                ["x"] = 0.6356987953,
            },
            [3] = 
            {
                ["giver"] = "Provost Piper",
                ["y"] = 0.2836774588,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506677,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Vines and Villains",
                ["x"] = 0.6614254117,
            },
            [4] = 
            {
                ["giver"] = "Sir Marley Oris",
                ["y"] = 0.2603922486,
                ["otherInfo"] = 
                {
                    ["time"] = 1533506771,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Cursed Treasure",
                ["x"] = 0.6967237592,
            },
            [5] = 
            {
                ["giver"] = "Harald Winvale",
                ["y"] = 0.2198418677,
                ["preQuest"] = 6227,
                ["otherInfo"] = 
                {
                    ["time"] = 1533526292,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Forgotten Ancestry",
                ["x"] = 0.7467461228,
            },
            [6] = 
            {
                ["giver"] = "Stibbons",
                ["y"] = 0.2978167236,
                ["preQuest"] = 3509,
                ["otherInfo"] = 
                {
                    ["time"] = 1533528128,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Jeweled Crown of Anton",
                ["x"] = 0.7838526368,
            },
            [7] = 
            {
                ["giver"] = "King Donel Deleyn",
                ["y"] = 0.1833901852,
                ["preQuest"] = 3050,
                ["otherInfo"] = 
                {
                    ["time"] = 1533594760,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Servants of Ancient Kings",
                ["x"] = 0.7397236228,
            },
            [8] = 
            {
                ["giver"] = "Sir Malik Nasir",
                ["y"] = 0.2773717642,
                ["otherInfo"] = 
                {
                    ["time"] = 1533609896,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Corpse Horde",
                ["x"] = 0.5530404449,
            },
            [9] = 
            {
                ["giver"] = "Daggerfall Patroller",
                ["y"] = 0.7047001719,
                ["preQuest"] = 3314,
                ["otherInfo"] = 
                {
                    ["time"] = 1533616621,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Farlivere's Gambit",
                ["x"] = 0.4874128997,
            },
            [10] = 
            {
                ["giver"] = "Lord Arcady Noellaume",
                ["y"] = 0.6687227488,
                ["preQuest"] = 3001,
                ["otherInfo"] = 
                {
                    ["time"] = 1533617294,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Disorganized Crime",
                ["x"] = 0.5088144541,
            },
            [11] = 
            {
                ["giver"] = "Lady Eloise Noellaume",
                ["y"] = 0.6681137681,
                ["otherInfo"] = 
                {
                    ["time"] = 1533617404,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Lady Eloise's Lockbox",
                ["x"] = 0.5077500343,
            },
            [12] = 
            {
                ["giver"] = "Erwan Castille",
                ["y"] = 0.4949662387,
                ["preQuest"] = 4335,
                ["otherInfo"] = 
                {
                    ["time"] = 1533670237,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Wicked Trade",
                ["x"] = 0.5817878842,
            },
            [13] = 
            {
                ["giver"] = "Guy LeBlanc",
                ["y"] = 0.5040016770,
                ["preQuest"] = 3023,
                ["otherInfo"] = 
                {
                    ["time"] = 1533670926,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Wyrd and Coven",
                ["x"] = 0.6777231693,
            },
            [14] = 
            {
                ["giver"] = "Mercenary",
                ["y"] = 0.4546503127,
                ["otherInfo"] = 
                {
                    ["time"] = 1533671046,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Crocodile Bounty",
                ["x"] = 0.6808248162,
            },
            [15] = 
            {
                ["giver"] = "Athel Baelborne",
                ["y"] = 0.7100141644,
                ["preQuest"] = 3017,
                ["otherInfo"] = 
                {
                    ["time"] = 1533679671,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Legacy of Baelborne Rock",
                ["x"] = 0.3761095703,
            },
            [16] = 
            {
                ["giver"] = "Lord Alain Diel",
                ["y"] = 0.6140681505,
                ["preQuest"] = 3414,
                ["otherInfo"] = 
                {
                    ["time"] = 1533686910,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Dagger's Edge",
                ["x"] = 0.3377877176,
            },
            [17] = 
            {
                ["giver"] = "Leon Milielle",
                ["y"] = 0.4058459699,
                ["otherInfo"] = 
                {
                    ["time"] = 1533699922,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Ghosts of Westtry",
                ["x"] = 0.4421305656,
            },
            [18] = 
            {
                ["giver"] = "Leon Milielle",
                ["y"] = 0.4247629941,
                ["preQuest"] = 3019,
                ["otherInfo"] = 
                {
                    ["time"] = 1533701453,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Memento Mori",
                ["x"] = 0.3977132440,
            },
            [19] = 
            {
                ["giver"] = "Lieutenant Clarice",
                ["y"] = 0.3811810613,
                ["preQuest"] = 3020,
                ["otherInfo"] = 
                {
                    ["time"] = 1533702206,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Signals of Dominion",
                ["x"] = 0.3257557452,
            },
            [20] = 
            {
                ["giver"] = "Scout's Orders",
                ["y"] = 0.3935525715,
                ["otherInfo"] = 
                {
                    ["time"] = 1533702234,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Wayward Scouts",
                ["x"] = 0.3128614426,
            },
        },
        ["alikr/sentinel_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Captain Albert Marck",
                ["y"] = 0.1584839523,
                ["preQuest"] = 4949,
                ["otherInfo"] = 
                {
                    ["time"] = 1535066932,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Risen From the Depths",
                ["x"] = 0.2926796973,
            },
            [2] = 
            {
                ["giver"] = "Watch Captain Zafira",
                ["y"] = 0.5169557929,
                ["otherInfo"] = 
                {
                    ["time"] = 1535068009,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Rise of the Dead",
                ["x"] = 0.2063108236,
            },
            [3] = 
            {
                ["giver"] = "Suspicious Monkey",
                ["y"] = 0.5333856940,
                ["otherInfo"] = 
                {
                    ["time"] = 1535919356,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Monkey Magic",
                ["x"] = 0.3683007956,
            },
            [4] = 
            {
                ["giver"] = "Ildani",
                ["y"] = 0.5817687511,
                ["preQuest"] = 3333,
                ["otherInfo"] = 
                {
                    ["time"] = 1535922375,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Seize the Moment",
                ["x"] = 0.2022365928,
            },
            [5] = 
            {
                ["giver"] = "King Fahara'jad",
                ["y"] = 0.6957021356,
                ["preQuest"] = 2146,
                ["otherInfo"] = 
                {
                    ["time"] = 1535930876,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "In Search of the Ash'abah",
                ["x"] = 0.6791270971,
            },
        },
        ["vvardenfell/balmora_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Sergeant Faldrus",
                ["y"] = 0.6759822965,
                ["preQuest"] = 5862,
                ["otherInfo"] = 
                {
                    ["time"] = 1537387483,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Fleeing the Past",
                ["x"] = 0.5449072719,
            },
            [2] = 
            {
                ["giver"] = "Gilan Lerano",
                ["y"] = 0.3449721038,
                ["otherInfo"] = 
                {
                    ["time"] = 1537410326,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Memory Stone",
                ["x"] = 0.4018615782,
            },
            [3] = 
            {
                ["giver"] = "Councilor Eris",
                ["y"] = 0.4479381442,
                ["preQuest"] = 5887,
                ["otherInfo"] = 
                {
                    ["time"] = 1537414217,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Of Faith and Family",
                ["x"] = 0.2424459904,
            },
            [4] = 
            {
                ["giver"] = "Ashur",
                ["y"] = 0.4948019087,
                ["preQuest"] = 5919,
                ["otherInfo"] = 
                {
                    ["time"] = 1537472082,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Purposeful Writ",
                ["x"] = 0.2891708612,
            },
            [5] = 
            {
                ["giver"] = "Veya Releth",
                ["y"] = 0.4762555361,
                ["preQuest"] = 5933,
                ["otherInfo"] = 
                {
                    ["time"] = 1537483647,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Family Reunion",
                ["x"] = 0.3086434007,
            },
        },
        ["alikr/coldrockdiggings_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Promissory Note",
                ["y"] = 0.3042840362,
                ["otherInfo"] = 
                {
                    ["time"] = 1536546333,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Past Due",
                ["x"] = 0.6747359037,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Merthyval Lort",
                ["y"] = 0.3512257040,
                ["otherInfo"] = 
                {
                    ["time"] = 1533765724,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "A Family Affair",
                ["x"] = 0.1734942794,
            },
            [2] = 
            {
                ["giver"] = "William Nurin",
                ["y"] = 0.3290571570,
                ["preQuest"] = 2561,
                ["otherInfo"] = 
                {
                    ["time"] = 1533766855,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Scamp Invasion",
                ["x"] = 0.1847085655,
            },
            [3] = 
            {
                ["giver"] = "Phinis Vanne",
                ["y"] = 0.4067914188,
                ["preQuest"] = 2578,
                ["otherInfo"] = 
                {
                    ["time"] = 1533767983,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Can't Leave Without Her",
                ["x"] = 0.2047742903,
            },
            [4] = 
            {
                ["giver"] = "Brother Perry",
                ["y"] = 0.3682714403,
                ["otherInfo"] = 
                {
                    ["time"] = 1533768092,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Slumbering Farmer",
                ["x"] = 0.2087714225,
            },
            [5] = 
            {
                ["giver"] = "Ingride Vanne",
                ["y"] = 0.3650457263,
                ["preQuest"] = 1678,
                ["otherInfo"] = 
                {
                    ["time"] = 1533776633,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Rozenn's Dream",
                ["x"] = 0.2702714205,
            },
            [6] = 
            {
                ["giver"] = "Attack Plans",
                ["y"] = 0.4724285603,
                ["preQuest"] = 1709,
                ["otherInfo"] = 
                {
                    ["time"] = 1533846079,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Lighthouse Attack Plans",
                ["x"] = 0.1770542860,
            },
            [7] = 
            {
                ["giver"] = "Tyree Marence",
                ["y"] = 0.5024399757,
                ["otherInfo"] = 
                {
                    ["time"] = 1533846248,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Repair Koeglin Lighthouse",
                ["x"] = 0.1766742915,
            },
            [8] = 
            {
                ["giver"] = "Tyree Marence",
                ["y"] = 0.5064542890,
                ["otherInfo"] = 
                {
                    ["time"] = 1533846986,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Repair Koeglin Lighthouse",
                ["x"] = 0.1754028499,
            },
            [9] = 
            {
                ["giver"] = "Attack Plans",
                ["y"] = 0.4726114273,
                ["otherInfo"] = 
                {
                    ["time"] = 1533847046,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Lighthouse Attack Plans",
                ["x"] = 0.1770028621,
            },
            [10] = 
            {
                ["giver"] = "Captain Albert Marck",
                ["y"] = 0.5501142740,
                ["otherInfo"] = 
                {
                    ["time"] = 1533851768,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Captive Crewmembers",
                ["x"] = 0.1617742926,
            },
            [11] = 
            {
                ["giver"] = "First Mate Elvira Derre",
                ["y"] = 0.5126199722,
                ["preQuest"] = 728,
                ["otherInfo"] = 
                {
                    ["time"] = 1533853374,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Divert and Deliver",
                ["x"] = 0.2323114276,
            },
            [12] = 
            {
                ["giver"] = "Sir Graham",
                ["y"] = 0.3264142871,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943284,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "False Knights",
                ["x"] = 0.2869457006,
            },
            [13] = 
            {
                ["giver"] = "Sir Graham",
                ["y"] = 0.3274685740,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943891,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "False Knights",
                ["x"] = 0.2859799862,
            },
            [14] = 
            {
                ["giver"] = "Sir Edmund",
                ["y"] = 0.3046999872,
                ["otherInfo"] = 
                {
                    ["time"] = 1533943921,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Flame of Dissent",
                ["x"] = 0.2963399887,
            },
            [15] = 
            {
                ["giver"] = "Sir Edmund",
                ["y"] = 0.3039971292,
                ["preQuest"] = 736,
                ["otherInfo"] = 
                {
                    ["time"] = 1533944379,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Retaking Firebrand Keep",
                ["x"] = 0.2970771492,
            },
            [16] = 
            {
                ["giver"] = "Sir Edmund",
                ["y"] = 0.3003971577,
                ["preQuest"] = 737,
                ["otherInfo"] = 
                {
                    ["time"] = 1533944995,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Army at the Gates",
                ["x"] = 0.3258914351,
            },
            [17] = 
            {
                ["giver"] = "Weather-Beaten Trunk",
                ["y"] = 0.2786599994,
                ["otherInfo"] = 
                {
                    ["time"] = 1533956133,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Legacy of the Three",
                ["x"] = 0.2456285655,
            },
            [18] = 
            {
                ["giver"] = "Sir Edmund",
                ["y"] = 0.3008942902,
                ["preQuest"] = 2576,
                ["otherInfo"] = 
                {
                    ["time"] = 1534024196,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Sir Hughes' Fate",
                ["x"] = 0.3260971308,
            },
            [19] = 
            {
                ["giver"] = "Duke Nathaniel",
                ["y"] = 0.2973114252,
                ["preQuest"] = 467,
                ["otherInfo"] = 
                {
                    ["time"] = 1534032366,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Unanswered Questions",
                ["x"] = 0.3323028684,
            },
            [20] = 
            {
                ["giver"] = "Brother Zacharie",
                ["y"] = 0.4025200009,
                ["preQuest"] = 1735,
                ["otherInfo"] = 
                {
                    ["time"] = 1534035243,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Fire in the Fields",
                ["x"] = 0.4674942791,
            },
            [21] = 
            {
                ["giver"] = "Brother Perry",
                ["y"] = 0.4018571377,
                ["otherInfo"] = 
                {
                    ["time"] = 1534040985,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Dreams to Nightmares",
                ["x"] = 0.4949942827,
            },
            [22] = 
            {
                ["giver"] = "Master Muzgu",
                ["y"] = 0.3202342987,
                ["preQuest"] = 2046,
                ["otherInfo"] = 
                {
                    ["time"] = 1534041930,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Gate to Quagmire",
                ["x"] = 0.5474256873,
            },
            [23] = 
            {
                ["giver"] = "Sister Safia",
                ["y"] = 0.3711885810,
                ["preQuest"] = 1536,
                ["otherInfo"] = 
                {
                    ["time"] = 1534043081,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Azura's Guardian",
                ["x"] = 0.4313657284,
            },
            [24] = 
            {
                ["giver"] = "Master Altien",
                ["y"] = 0.3937314153,
                ["preQuest"] = 1529,
                ["otherInfo"] = 
                {
                    ["time"] = 1534110562,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "A Prison of Sleep",
                ["x"] = 0.4481828511,
            },
            [25] = 
            {
                ["giver"] = "Falice Menoit",
                ["y"] = 0.3914342821,
                ["otherInfo"] = 
                {
                    ["time"] = 1534110585,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Injured Spirit Wardens",
                ["x"] = 0.4417657256,
            },
            [26] = 
            {
                ["giver"] = "Abbot Durak",
                ["y"] = 0.4171828628,
                ["preQuest"] = 1541,
                ["otherInfo"] = 
                {
                    ["time"] = 1534115232,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Pursuing the Shard",
                ["x"] = 0.4508599937,
            },
            [27] = 
            {
                ["giver"] = "Arcady Charnis",
                ["y"] = 0.5928171277,
                ["preQuest"] = 1485,
                ["otherInfo"] = 
                {
                    ["time"] = 1534127785,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Sower Reaps",
                ["x"] = 0.4334171414,
            },
            [28] = 
            {
                ["giver"] = "Priestess Pietine",
                ["y"] = 0.5902314186,
                ["otherInfo"] = 
                {
                    ["time"] = 1534128064,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Abominations from Beyond",
                ["x"] = 0.4062657058,
            },
            [29] = 
            {
                ["giver"] = "Cursed Skull",
                ["y"] = 0.6093199849,
                ["otherInfo"] = 
                {
                    ["time"] = 1534128145,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Curse of Skulls",
                ["x"] = 0.3788971305,
            },
            [30] = 
            {
                ["giver"] = "Hosni at-Tura",
                ["y"] = 0.6113514304,
                ["preQuest"] = 499,
                ["otherInfo"] = 
                {
                    ["time"] = 1534132043,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Signet Ring",
                ["x"] = 0.3172799945,
            },
            [31] = 
            {
                ["giver"] = "Lady Sirali at-Tura",
                ["y"] = 0.5777771473,
                ["preQuest"] = 2495,
                ["otherInfo"] = 
                {
                    ["time"] = 1534132624,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Evidence Against Adima",
                ["x"] = 0.2957200110,
            },
            [32] = 
            {
                ["giver"] = "Lady Sirali at-Tura",
                ["y"] = 0.5778542757,
                ["preQuest"] = 2496,
                ["otherInfo"] = 
                {
                    ["time"] = 1534133322,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Saving Hosni",
                ["x"] = 0.2950657010,
            },
            [33] = 
            {
                ["giver"] = "Hosni at-Tura",
                ["y"] = 0.6140800118,
                ["preQuest"] = 2497,
                ["otherInfo"] = 
                {
                    ["time"] = 1534133785,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Return of the Dream Shard",
                ["x"] = 0.3099485636,
            },
            [34] = 
            {
                ["giver"] = "Abbot Durak",
                ["y"] = 0.4175542891,
                ["preQuest"] = 1633,
                ["otherInfo"] = 
                {
                    ["time"] = 1534134224,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Another Omen",
                ["x"] = 0.4502457082,
            },
            [35] = 
            {
                ["giver"] = "Watch Captain Rama",
                ["y"] = 0.4397457242,
                ["otherInfo"] = 
                {
                    ["time"] = 1534134527,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Blood Revenge",
                ["x"] = 0.5220771432,
            },
            [36] = 
            {
                ["giver"] = "Pierre Lanier",
                ["y"] = 0.4184857011,
                ["otherInfo"] = 
                {
                    ["time"] = 1534135047,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Rat in a Trap",
                ["x"] = 0.5551342964,
            },
            [37] = 
            {
                ["giver"] = "Watch Commander Kurt",
                ["y"] = 0.4466885626,
                ["preQuest"] = 1554,
                ["otherInfo"] = 
                {
                    ["time"] = 1534135245,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "A Means to an End",
                ["x"] = 0.5594199896,
            },
            [38] = 
            {
                ["giver"] = "Watch Captain Ernard",
                ["y"] = 0.4467457235,
                ["preQuest"] = 1568,
                ["otherInfo"] = 
                {
                    ["time"] = 1534136855,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Revenge Against Rama",
                ["x"] = 0.5594199896,
            },
            [39] = 
            {
                ["giver"] = "Dro-Dara",
                ["y"] = 0.5452857018,
                ["preQuest"] = 1384,
                ["otherInfo"] = 
                {
                    ["time"] = 1534284908,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Plowshares to Swords",
                ["x"] = 0.7167114019,
            },
            [40] = 
            {
                ["giver"] = "Sister Tabakah",
                ["y"] = 0.4731028676,
                ["otherInfo"] = 
                {
                    ["time"] = 1534285563,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Azura's Relics",
                ["x"] = 0.8102228642,
            },
            [41] = 
            {
                ["giver"] = "Knarstygg",
                ["y"] = 0.5479228497,
                ["preQuest"] = 2536,
                ["otherInfo"] = 
                {
                    ["time"] = 1534289013,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Predator's Heart",
                ["x"] = 0.7230571508,
            },
            [42] = 
            {
                ["giver"] = "General Godrun",
                ["y"] = 0.4852257073,
                ["otherInfo"] = 
                {
                    ["time"] = 1534292650,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "General Godrun's Orders",
                ["x"] = 0.7429599762,
            },
            [43] = 
            {
                ["giver"] = "Captain Dugakh",
                ["y"] = 0.4715114236,
                ["otherInfo"] = 
                {
                    ["time"] = 1534292860,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ogre Teeth",
                ["x"] = 0.7367143035,
            },
            [44] = 
            {
                ["giver"] = "General Godrun",
                ["y"] = 0.4308257103,
                ["preQuest"] = 1437,
                ["otherInfo"] = 
                {
                    ["time"] = 1534293441,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ending the Ogre Threat",
                ["x"] = 0.7524114251,
            },
            [45] = 
            {
                ["giver"] = "Abbot Durak",
                ["y"] = 0.4839485586,
                ["preQuest"] = 1346,
                ["otherInfo"] = 
                {
                    ["time"] = 1534304400,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Godrun's Dream",
                ["x"] = 0.7416971326,
            },
            [46] = 
            {
                ["giver"] = "Abbot Durak",
                ["y"] = 0.4835257232,
                ["preQuest"] = 3637,
                ["otherInfo"] = 
                {
                    ["time"] = 1534304982,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Azura's Aid",
                ["x"] = 0.7431628704,
            },
            [47] = 
            {
                ["giver"] = "Mathias Raiment",
                ["y"] = 0.4296885729,
                ["otherInfo"] = 
                {
                    ["time"] = 1534365486,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Look in the Mirror",
                ["x"] = 0.6858485937,
            },
            [48] = 
            {
                ["giver"] = "Countess Ilise Manteau",
                ["y"] = 0.4326257110,
                ["preQuest"] = 614,
                ["otherInfo"] = 
                {
                    ["time"] = 1534365750,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Gift from a Suitor",
                ["x"] = 0.6523114443,
            },
            [49] = 
            {
                ["giver"] = "Michel Helomaine",
                ["y"] = 0.4065999985,
                ["otherInfo"] = 
                {
                    ["time"] = 1534368712,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Perfect Burial",
                ["x"] = 0.6221686006,
            },
            [50] = 
            {
                ["giver"] = "Blaise Pamarc",
                ["y"] = 0.5167885423,
                ["preQuest"] = 2538,
                ["otherInfo"] = 
                {
                    ["time"] = 1534370713,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "King Aphren's Sword",
                ["x"] = 0.6690571308,
            },
            [51] = 
            {
                ["giver"] = "Serge Arcole",
                ["y"] = 0.6117914319,
                ["otherInfo"] = 
                {
                    ["time"] = 1534395263,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Ransom for Miranda",
                ["x"] = 0.4425742924,
            },
            [52] = 
            {
                ["giver"] = "Serge Arcole",
                ["y"] = 0.6594685912,
                ["preQuest"] = 2451,
                ["otherInfo"] = 
                {
                    ["time"] = 1534396158,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Woman Wronged",
                ["x"] = 0.4409771562,
            },
        },
        ["deshaan/bthanual_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Kireth Vanos",
                ["y"] = 0.1382754892,
                ["preQuest"] = 3864,
                ["otherInfo"] = 
                {
                    ["time"] = 1538344791,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Light Fantastic",
                ["x"] = 0.6919742227,
            },
        },
        ["reapersmarch/reapersmarch_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Ancient Scroll",
                ["y"] = 0.2042936236,
                ["otherInfo"] = 
                {
                    ["time"] = 1536288690,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Hircine's Gift",
                ["x"] = 0.6639211178,
            },
        },
        ["grahtwood/eldenrootservices_base"] = 
        {
            [4] = 
            {
                ["giver"] = "Sealed Blacksmithing Writ",
                ["y"] = 0.3603200018,
                ["otherInfo"] = 
                {
                    ["time"] = 1538437821,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Plate",
                ["x"] = 0.7639314532,
            },
            [1] = 
            {
                ["giver"] = "Undaunted Enclave Invitation",
                ["y"] = 0.4082742929,
                ["otherInfo"] = 
                {
                    ["time"] = 1534827071,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Taking the Undaunted Pledge",
                ["x"] = 0.6841142774,
            },
            [2] = 
            {
                ["giver"] = "Sealed Alchemy Writ",
                ["y"] = 0.3603200018,
                ["otherInfo"] = 
                {
                    ["time"] = 1538437798,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Concoction",
                ["x"] = 0.7639314532,
            },
            [3] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["y"] = 0.3603200018,
                ["otherInfo"] = 
                {
                    ["time"] = 1538437806,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Glyph",
                ["x"] = 0.7639314532,
            },
        },
        ["stormhaven/bonesnapruinssecret_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Sir Edgard",
                ["y"] = 0.6375247836,
                ["otherInfo"] = 
                {
                    ["time"] = 1533871296,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Lost Lions",
                ["x"] = 0.6059898734,
            },
            [1] = 
            {
                ["giver"] = "Battlemage Gaston",
                ["y"] = 0.8454304934,
                ["preQuest"] = 1637,
                ["otherInfo"] = 
                {
                    ["time"] = 1533868567,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Repairing the Cage",
                ["x"] = 0.6948909760,
            },
        },
        ["grahtwood/eldenhollow_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Bakkhara",
                ["y"] = 0.5466459394,
                ["preQuest"] = 4107,
                ["otherInfo"] = 
                {
                    ["time"] = 1536199213,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ancient Remains",
                ["x"] = 0.3663927019,
            },
        },
        ["rivenspire/orcsfingerruins_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Teeba-Ja",
                ["y"] = 0.5621206164,
                ["otherInfo"] = 
                {
                    ["time"] = 1534990861,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Shedding the Past",
                ["x"] = 0.6867665052,
            },
        },
        ["auridon/vulkhelguard_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6363090277,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2813375592,
            },
            [2] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6363090277,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2813375592,
            },
            [3] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6363090277,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033477,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2813375592,
            },
            [4] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947007537,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2248924077,
            },
            [5] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947007537,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2248924077,
            },
            [6] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947007537,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2248924077,
            },
            [7] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947007537,
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2248924077,
            },
            [8] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6336819530,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2803492844,
            },
            [9] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6336819530,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2803492844,
            },
            [10] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6336819530,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196952,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2803492844,
            },
            [11] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5952637196,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2243419737,
            },
            [12] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5952637196,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2243419737,
            },
            [13] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5952637196,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2243419737,
            },
            [14] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5952637196,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214704,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2243419737,
            },
            [15] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6322933435,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2811499238,
            },
            [16] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6322933435,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2811499238,
            },
            [17] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6322933435,
                ["otherInfo"] = 
                {
                    ["time"] = 1534214742,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2811499238,
            },
            [18] = 
            {
                ["giver"] = "Sealed Clothier Writ",
                ["y"] = 0.5761359334,
                ["preQuest"] = 6228,
                ["otherInfo"] = 
                {
                    ["time"] = 1534215666,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Masterful Leatherwear",
                ["x"] = 0.3380454481,
            },
            [19] = 
            {
                ["giver"] = "Sealed Alchemy Writ",
                ["y"] = 0.5761359334,
                ["otherInfo"] = 
                {
                    ["time"] = 1534215692,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Concoction",
                ["x"] = 0.3380454481,
            },
            [20] = 
            {
                ["giver"] = "Battlemaster Rivyn",
                ["y"] = 0.5142739415,
                ["preQuest"] = 5952,
                ["otherInfo"] = 
                {
                    ["time"] = 1535167121,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Test of Mettle",
                ["x"] = 0.5293735266,
            },
            [21] = 
            {
                ["giver"] = "Battlemaster Rivyn",
                ["y"] = 0.5142739415,
                ["preQuest"] = 5954,
                ["otherInfo"] = 
                {
                    ["time"] = 1535169644,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Let the Games Begin",
                ["x"] = 0.5293610096,
            },
            [22] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5972027779,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2266438156,
            },
            [23] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5972027779,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2266438156,
            },
            [24] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5972027779,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165505,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2266438156,
            },
            [25] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5972027779,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165506,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2266438156,
            },
            [26] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6320431232,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2808997333,
            },
            [27] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6320431232,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2808997333,
            },
            [28] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6320431232,
                ["otherInfo"] = 
                {
                    ["time"] = 1536165544,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2808997333,
            },
            [29] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276305,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2246547192,
            },
            [30] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2246547192,
            },
            [31] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2246547192,
            },
            [32] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5947132707,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276306,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2246547192,
            },
            [33] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6298664212,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2842649221,
            },
            [34] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6298664212,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2842649221,
            },
            [35] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6298664212,
                ["otherInfo"] = 
                {
                    ["time"] = 1536276327,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2842649221,
            },
            [36] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5956890583,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724534,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2244795859,
            },
            [37] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5956890583,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2244795859,
            },
            [38] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5956890583,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2244795859,
            },
            [39] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5956890583,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724535,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2244795859,
            },
            [40] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6317679286,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2820006013,
            },
            [41] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6317679286,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2820006013,
            },
            [42] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6317679286,
                ["otherInfo"] = 
                {
                    ["time"] = 1536724562,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2820006013,
            },
            [43] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5962395072,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725827,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2239916921,
            },
            [44] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5962395072,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725827,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2239916921,
            },
            [45] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5962395072,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725828,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2239916921,
            },
            [46] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5962395072,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725828,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2239916921,
            },
            [47] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6304793954,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725860,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2839646637,
            },
            [48] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6304793954,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725861,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2839646637,
            },
            [49] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6304793954,
                ["otherInfo"] = 
                {
                    ["time"] = 1536725861,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2839646637,
            },
            [50] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6361964345,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2822132707,
            },
            [51] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6361964345,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2822132707,
            },
            [52] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6361964345,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806138,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2822132707,
            },
            [53] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950009823,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2263310701,
            },
            [54] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950009823,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2263310701,
            },
            [55] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950009823,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2263310701,
            },
            [56] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950009823,
                ["otherInfo"] = 
                {
                    ["time"] = 1536806160,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2263310701,
            },
            [57] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6284778118,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188847,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2834767699,
            },
            [58] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6284778118,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188848,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2834767699,
            },
            [59] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6284778118,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188848,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2834767699,
            },
            [60] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973403454,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188869,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2262685150,
            },
            [61] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973403454,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188869,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2262685150,
            },
            [62] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973403454,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188870,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2262685150,
            },
            [63] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973403454,
                ["otherInfo"] = 
                {
                    ["time"] = 1538188870,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2262685150,
            },
            [64] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6318304539,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190378,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2821882367,
            },
            [65] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6318304539,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190379,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2821882367,
            },
            [66] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6318304539,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190379,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2821882367,
            },
            [67] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973028541,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190408,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2262559980,
            },
            [68] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973028541,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190408,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2262559980,
            },
            [69] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973028541,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190408,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2262559980,
            },
            [70] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5973028541,
                ["otherInfo"] = 
                {
                    ["time"] = 1538190409,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2262559980,
            },
            [71] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5958766937,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342456,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2260058075,
            },
            [72] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5958766937,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342456,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2260058075,
            },
            [73] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5958766937,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342457,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2260058075,
            },
            [74] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5958766937,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342457,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2260058075,
            },
            [75] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6312674880,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342500,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2828763127,
            },
            [76] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6312674880,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342501,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2828763127,
            },
            [77] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6312674880,
                ["otherInfo"] = 
                {
                    ["time"] = 1538342501,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2828763127,
            },
            [78] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6336944699,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432373,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Provisioner Writ",
                ["x"] = 0.2819880843,
            },
            [79] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6336944699,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432373,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Enchanter Writ",
                ["x"] = 0.2819880843,
            },
            [80] = 
            {
                ["giver"] = "Consumables Crafting Writs",
                ["y"] = 0.6336944699,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432374,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Alchemist Writ",
                ["x"] = 0.2819880843,
            },
            [81] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950385332,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432389,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.2256430089,
            },
            [82] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950385332,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432389,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.2256430089,
            },
            [83] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950385332,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432390,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.2256430089,
            },
            [84] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.5950385332,
                ["otherInfo"] = 
                {
                    ["time"] = 1538432390,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.2256430089,
            },
        },
        ["stormhaven/farangelsdelve_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Tomb Urn",
                ["y"] = 0.4242919385,
                ["preQuest"] = 2550,
                ["otherInfo"] = 
                {
                    ["time"] = 1534129561,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Stolen Ashes",
                ["x"] = 0.4327341914,
            },
        },
        ["coldharbor/vaultsofmadness1_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Gasteau Chamrond",
                ["y"] = 0.8147234321,
                ["otherInfo"] = 
                {
                    ["time"] = 1535399791,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Mind of Madness",
                ["x"] = 0.1713191420,
            },
        },
        ["clockwork/ccunderground02_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Proctor Luciana Pullo",
                ["y"] = 0.0607857667,
                ["preQuest"] = 6046,
                ["otherInfo"] = 
                {
                    ["time"] = 1538502061,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Where Shadows Lie",
                ["x"] = 0.6665543318,
            },
        },
        ["wrothgar/wrothgar_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Sealed Woodworking Writ",
                ["y"] = 0.4133314192,
                ["otherInfo"] = 
                {
                    ["time"] = 1538435256,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Weapon",
                ["x"] = 0.9051114321,
            },
        },
        ["auridon/thebanishedcells_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Keeper Cirion",
                ["y"] = 0.8494246006,
                ["preQuest"] = 4841,
                ["otherInfo"] = 
                {
                    ["time"] = 1536197347,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Banishing the Banished",
                ["x"] = 0.4782767594,
            },
        },
        ["alikr/imperviousvault_base"] = 
        {
            [1] = 
            {
                ["giver"] = "King Fahara'jad",
                ["y"] = 0.5337469578,
                ["preQuest"] = 2998,
                ["otherInfo"] = 
                {
                    ["time"] = 1536637446,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Kingdom in Mourning",
                ["x"] = 0.7415758967,
            },
        },
        ["clockwork/brassfortress_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Palbatan",
                ["y"] = 0.4491144717,
                ["otherInfo"] = 
                {
                    ["time"] = 1538099753,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Cogs of Fate",
                ["x"] = 0.5698403716,
            },
            [2] = 
            {
                ["giver"] = "Divayth Fyr",
                ["y"] = 0.5334723592,
                ["preQuest"] = 6057,
                ["otherInfo"] = 
                {
                    ["time"] = 1538179164,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Strangeness of Seht",
                ["x"] = 0.3695443869,
            },
            [3] = 
            {
                ["giver"] = "Proctor Sovor Saryoni",
                ["y"] = 0.5926411748,
                ["otherInfo"] = 
                {
                    ["time"] = 1538179967,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Most Complicated Machine",
                ["x"] = 0.4219856262,
            },
            [4] = 
            {
                ["giver"] = "Razgurug",
                ["y"] = 0.5042411685,
                ["otherInfo"] = 
                {
                    ["time"] = 1538184326,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Sticky Solution",
                ["x"] = 0.6113886237,
            },
            [5] = 
            {
                ["giver"] = "Associate Zanon",
                ["y"] = 0.7095379829,
                ["otherInfo"] = 
                {
                    ["time"] = 1538351363,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Oscillating Son",
                ["x"] = 0.2396129370,
            },
            [6] = 
            {
                ["giver"] = "Kireth Vanos",
                ["y"] = 0.6101272106,
                ["preQuest"] = 6075,
                ["otherInfo"] = 
                {
                    ["time"] = 1538353290,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Family Feud",
                ["x"] = 0.5443990231,
            },
        },
        ["summerset/ui_map"] = 
        {
            [1] = 
            {
                ["giver"] = "Olorime",
                ["y"] = 0.2734320164,
                ["otherInfo"] = 
                {
                    ["time"] = 1534294704,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woe of the Welkynars",
                ["x"] = 0.4132726490,
            },
        },
        ["summerset/collegeofpsijicsruins_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Relicmaster Glenadir",
                ["y"] = 0.4317321479,
                ["otherInfo"] = 
                {
                    ["time"] = 1535331338,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Vault of Moawita",
                ["x"] = 0.5981447697,
            },
        },
        ["stormhaven/koeglinvillage_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Dame Dabienne",
                ["y"] = 0.3335759938,
                ["preQuest"] = 3412,
                ["otherInfo"] = 
                {
                    ["time"] = 1533765631,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "False Accusations",
                ["x"] = 0.3885127902,
            },
            [2] = 
            {
                ["giver"] = "Margot Oscent",
                ["y"] = 0.5187935233,
                ["preQuest"] = 2494,
                ["otherInfo"] = 
                {
                    ["time"] = 1533769172,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Slavers",
                ["x"] = 0.6060275435,
            },
            [3] = 
            {
                ["giver"] = "Dame Dabienne",
                ["y"] = 0.3445196748,
                ["preQuest"] = 2556,
                ["otherInfo"] = 
                {
                    ["time"] = 1533775980,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "To Alcaire Castle",
                ["x"] = 0.3553662896,
            },
        },
        ["summerset/kingshavenext_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Mehdze",
                ["y"] = 0.4646966457,
                ["preQuest"] = 6137,
                ["otherInfo"] = 
                {
                    ["time"] = 1535322698,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Savage Truths",
                ["x"] = 0.8305439353,
            },
        },
        ["darkbrotherhood/anvilcity_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Speaker Terenus",
                ["y"] = 0.6872546673,
                ["preQuest"] = 5538,
                ["otherInfo"] = 
                {
                    ["time"] = 1537674191,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Signed in Blood",
                ["x"] = 0.2361459881,
            },
            [1] = 
            {
                ["giver"] = "Amelie Crowe",
                ["y"] = 0.4991512597,
                ["otherInfo"] = 
                {
                    ["time"] = 1537673741,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Voices in the Dark",
                ["x"] = 0.3620963991,
            },
        },
        ["summerset/dreamingcave03_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Ritemaster Iachesis",
                ["y"] = 0.7077407837,
                ["preQuest"] = 6112,
                ["otherInfo"] = 
                {
                    ["time"] = 1535594149,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Buried Memories",
                ["x"] = 0.6542621255,
            },
            [2] = 
            {
                ["giver"] = "Ritemaster Iachesis",
                ["y"] = 0.7504896522,
                ["preQuest"] = 6132,
                ["otherInfo"] = 
                {
                    ["time"] = 1535601322,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Tower Sentinels",
                ["x"] = 0.6307587624,
            },
            [3] = 
            {
                ["giver"] = "Ritemaster Iachesis",
                ["y"] = 0.6959039569,
                ["preQuest"] = 6142,
                ["otherInfo"] = 
                {
                    ["time"] = 1535690559,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Dreaming Cave",
                ["x"] = 0.6557949185,
            },
        },
        ["rivenspire/hoarfrost_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Captain Thayer",
                ["y"] = 0.5418079495,
                ["otherInfo"] = 
                {
                    ["time"] = 1534631769,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Wayward Son",
                ["x"] = 0.4679913223,
            },
            [2] = 
            {
                ["giver"] = "Captain Thayer",
                ["y"] = 0.5901261568,
                ["preQuest"] = 5020,
                ["otherInfo"] = 
                {
                    ["time"] = 1534634333,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Bandit",
                ["x"] = 0.3932930827,
            },
            [3] = 
            {
                ["giver"] = "Captain Thayer",
                ["y"] = 0.5798182487,
                ["preQuest"] = 5022,
                ["otherInfo"] = 
                {
                    ["time"] = 1534650828,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Lover",
                ["x"] = 0.4004475772,
            },
        },
        ["rivenspire/crestshademine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Troll Socialization Research Notes",
                ["y"] = 0.3638949394,
                ["otherInfo"] = 
                {
                    ["time"] = 1534624071,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Friend of Trolls",
                ["x"] = 0.4132508039,
            },
        },
        ["auridon/bewan_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Altmeri Relic",
                ["y"] = 0.6983050704,
                ["otherInfo"] = 
                {
                    ["time"] = 1535248036,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Lost Bet",
                ["x"] = 0.5038520694,
            },
        },
        ["glenumbra/aldcroft_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Captain Vistra",
                ["y"] = 0.3413914144,
                ["preQuest"] = 3004,
                ["otherInfo"] = 
                {
                    ["time"] = 1533669833,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Pride of the Lion Guard",
                ["x"] = 0.5562694669,
            },
        },
        ["stormhaven/bearclawmine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Hubert",
                ["y"] = 0.4829317331,
                ["otherInfo"] = 
                {
                    ["time"] = 1534364051,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Next of Kin",
                ["x"] = 0.3204819262,
            },
        },
        ["stonefalls/fungalgrotto_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Vila Theran",
                ["y"] = 0.7768288851,
                ["otherInfo"] = 
                {
                    ["time"] = 1534903204,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Kings of the Grotto",
                ["x"] = 0.3413615227,
            },
        },
        ["rivenspire/shroudedpass_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Count Verandis Ravenwatch",
                ["y"] = 0.2501651645,
                ["preQuest"] = 5024,
                ["otherInfo"] = 
                {
                    ["time"] = 1534996733,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Lightless Remnant",
                ["x"] = 0.2278132588,
            },
        },
        ["vvardenfell/vivecthroneroom02_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Canon Llevule",
                ["y"] = 0.6120930314,
                ["preQuest"] = 5893,
                ["otherInfo"] = 
                {
                    ["time"] = 1538012100,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Divine Disaster",
                ["x"] = 0.3975193799,
            },
            [2] = 
            {
                ["giver"] = "Vivec",
                ["y"] = 0.3184496164,
                ["preQuest"] = 5902,
                ["otherInfo"] = 
                {
                    ["time"] = 1538013900,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Divine Restoration",
                ["x"] = 0.4530232549,
            },
            [3] = 
            {
                ["giver"] = "Vivec",
                ["y"] = 0.3364340961,
                ["preQuest"] = 5905,
                ["otherInfo"] = 
                {
                    ["time"] = 1538022047,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Divine Blessings",
                ["x"] = 0.4849612415,
            },
        },
        ["stormhaven/wayrest_base"] = 
        {
            [1] = 
            {
                ["giver"] = "M'jaddha",
                ["y"] = 0.1780604571,
                ["otherInfo"] = 
                {
                    ["time"] = 1534116513,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Debt Collector's Debts",
                ["x"] = 0.4391658008,
            },
            [2] = 
            {
                ["giver"] = "Sergeant Stegine",
                ["y"] = 0.1300478876,
                ["otherInfo"] = 
                {
                    ["time"] = 1534125955,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Dreugh Threat",
                ["x"] = 0.2756144106,
            },
            [3] = 
            {
                ["giver"] = "Adiel Charnis",
                ["y"] = 0.0535364039,
                ["preQuest"] = 2068,
                ["otherInfo"] = 
                {
                    ["time"] = 1534127126,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "They Dragged Him Away",
                ["x"] = 0.2342794538,
            },
            [4] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.2255538255,
                ["preQuest"] = 1527,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Clothier Writ",
                ["x"] = 0.3749423027,
            },
            [5] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.2255538255,
                ["preQuest"] = 1527,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Blacksmith Writ",
                ["x"] = 0.3749423027,
            },
            [6] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.2255538255,
                ["preQuest"] = 1527,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Woodworker Writ",
                ["x"] = 0.3749423027,
            },
            [7] = 
            {
                ["giver"] = "Equipment Crafting Writs",
                ["y"] = 0.2255538255,
                ["preQuest"] = 1527,
                ["otherInfo"] = 
                {
                    ["time"] = 1534196577,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Jewelry Crafting Writ",
                ["x"] = 0.3749423027,
            },
            [8] = 
            {
                ["giver"] = "Janne Marolles",
                ["y"] = 0.2736096680,
                ["otherInfo"] = 
                {
                    ["time"] = 1534283292,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Old Adventurers",
                ["x"] = 1.0325227976,
            },
            [9] = 
            {
                ["giver"] = "Eldrasea Deras",
                ["y"] = 0.3309824765,
                ["preQuest"] = 1615,
                ["otherInfo"] = 
                {
                    ["time"] = 1534367222,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "To The Clockwork City",
                ["x"] = 0.6182646751,
            },
            [10] = 
            {
                ["giver"] = "Abbot Durak",
                ["y"] = 0.4614630342,
                ["preQuest"] = 521,
                ["otherInfo"] = 
                {
                    ["time"] = 1534373250,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Vaermina's Gambit",
                ["x"] = 0.4303103685,
            },
            [11] = 
            {
                ["giver"] = "High King Emeric",
                ["y"] = 0.4613187909,
                ["preQuest"] = 575,
                ["otherInfo"] = 
                {
                    ["time"] = 1534374724,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Road to Rivenspire",
                ["x"] = 0.3795575202,
            },
            [12] = 
            {
                ["giver"] = "Urgarlag Chief-bane",
                ["y"] = 0.5017451048,
                ["otherInfo"] = 
                {
                    ["time"] = 1534387635,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Moon Hunter Keep",
                ["x"] = 0.1636523604,
            },
            [13] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["y"] = 0.4949232638,
                ["otherInfo"] = 
                {
                    ["time"] = 1534903120,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Fungal Grotto I",
                ["x"] = 0.1531094909,
            },
            [14] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["y"] = 0.4953559339,
                ["otherInfo"] = 
                {
                    ["time"] = 1534905260,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Fungal Grotto I",
                ["x"] = 0.1525470167,
            },
            [15] = 
            {
                ["giver"] = "Glirion the Redbeard",
                ["y"] = 0.4776739478,
                ["otherInfo"] = 
                {
                    ["time"] = 1535077586,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Crypt of Hearts I",
                ["x"] = 0.1517682076,
            },
            [16] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["y"] = 0.4947213531,
                ["otherInfo"] = 
                {
                    ["time"] = 1535077599,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Darkshade Caverns I",
                ["x"] = 0.1553738266,
            },
            [17] = 
            {
                ["giver"] = "Glirion the Redbeard",
                ["y"] = 0.4767653048,
                ["otherInfo"] = 
                {
                    ["time"] = 1535399588,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Vaults of Madness",
                ["x"] = 0.1539315730,
            },
            [18] = 
            {
                ["giver"] = "Alvur Baren",
                ["y"] = 0.4954713285,
                ["otherInfo"] = 
                {
                    ["time"] = 1535850518,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Madness in Reaper's March",
                ["x"] = 0.5489355922,
            },
            [19] = 
            {
                ["giver"] = "Arch-Mage Shalidor",
                ["y"] = 0.4661936164,
                ["preQuest"] = 4435,
                ["otherInfo"] = 
                {
                    ["time"] = 1535851711,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Circus of Cheerful Slaughter",
                ["x"] = 0.5344698429,
            },
            [20] = 
            {
                ["giver"] = "Glirion the Redbeard",
                ["y"] = 0.4758134186,
                ["otherInfo"] = 
                {
                    ["time"] = 1536110391,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Crypt of Hearts I",
                ["x"] = 0.1524027884,
            },
            [21] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["y"] = 0.4946204126,
                ["otherInfo"] = 
                {
                    ["time"] = 1536110402,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Darkshade Caverns I",
                ["x"] = 0.1557199657,
            },
            [22] = 
            {
                ["giver"] = "Urgarlag Chief-bane",
                ["y"] = 0.5108312964,
                ["otherInfo"] = 
                {
                    ["time"] = 1536470819,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: White-Gold Tower",
                ["x"] = 0.1639984995,
            },
            [23] = 
            {
                ["giver"] = "Maj al-Ragath",
                ["y"] = 0.4965241849,
                ["otherInfo"] = 
                {
                    ["time"] = 1537996570,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Pledge: Fungal Grotto I",
                ["x"] = 0.1599890441,
            },
        },
        ["summerset/shimmerene_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Calibar",
                ["y"] = 0.6924549937,
                ["otherInfo"] = 
                {
                    ["time"] = 1534970964,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Queen's Decree",
                ["x"] = 0.2751390040,
            },
            [2] = 
            {
                ["giver"] = "Calibar",
                ["y"] = 0.6622093320,
                ["preQuest"] = 5283,
                ["otherInfo"] = 
                {
                    ["time"] = 1535086542,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Queen's Decree",
                ["x"] = 0.2323507369,
            },
            [3] = 
            {
                ["giver"] = "Lanarie",
                ["y"] = 0.6188374758,
                ["otherInfo"] = 
                {
                    ["time"] = 1535148723,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Tale of Two Mothers",
                ["x"] = 0.6734209061,
            },
        },
        ["summerset/dreamingcave01_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Ritemaster Iachesis",
                ["y"] = 0.5473768711,
                ["preQuest"] = 6109,
                ["otherInfo"] = 
                {
                    ["time"] = 1535752808,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Lost in Translation",
                ["x"] = 0.5636072755,
            },
            [2] = 
            {
                ["giver"] = "Oriandra",
                ["y"] = 0.3588981628,
                ["preQuest"] = 6113,
                ["otherInfo"] = 
                {
                    ["time"] = 1535755815,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Necessary Alliance",
                ["x"] = 0.3942164779,
            },
            [3] = 
            {
                ["giver"] = "Valsirenn",
                ["y"] = 0.5018859506,
                ["preQuest"] = 6126,
                ["otherInfo"] = 
                {
                    ["time"] = 1535778626,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A New Alliance",
                ["x"] = 0.7556292415,
            },
        },
        ["stormhaven/alcairecastle_base"] = 
        {
            [4] = 
            {
                ["giver"] = "Duke Nathaniel",
                ["y"] = 0.4368499517,
                ["preQuest"] = 2567,
                ["otherInfo"] = 
                {
                    ["time"] = 1533955857,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Tracking Sir Hughes",
                ["x"] = 0.4016301334,
            },
            [1] = 
            {
                ["giver"] = "Sir Hughes",
                ["y"] = 0.3651475012,
                ["preQuest"] = 2552,
                ["otherInfo"] = 
                {
                    ["time"] = 1533950269,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Two Sides to Every Coin",
                ["x"] = 0.4701412022,
            },
            [2] = 
            {
                ["giver"] = "Duchess Lakana",
                ["y"] = 0.4338193238,
                ["preQuest"] = 2564,
                ["otherInfo"] = 
                {
                    ["time"] = 1533951481,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Life of the Duchess",
                ["x"] = 0.4061531425,
            },
            [3] = 
            {
                ["giver"] = "Sir Hughes",
                ["y"] = 0.5228102207,
                ["preQuest"] = 2566,
                ["otherInfo"] = 
                {
                    ["time"] = 1533955422,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "The Safety of the Kingdom",
                ["x"] = 0.3367925584,
            },
        },
        ["vvardenfell/vvardenfell_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Avo Elarven",
                ["y"] = 0.7837001085,
                ["otherInfo"] = 
                {
                    ["time"] = 1536797695,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Scarlet Judge",
                ["x"] = 0.6053663492,
            },
            [2] = 
            {
                ["giver"] = "Buoyant Armiger",
                ["y"] = 0.7866915464,
                ["otherInfo"] = 
                {
                    ["time"] = 1536863121,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "An Armiger's Duty",
                ["x"] = 0.7578663826,
            },
            [3] = 
            {
                ["giver"] = "Halinjirr",
                ["y"] = 0.7889339924,
                ["otherInfo"] = 
                {
                    ["time"] = 1536963658,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Hidden Harvest",
                ["x"] = 0.3934557736,
            },
            [4] = 
            {
                ["giver"] = "Deminah Salvi",
                ["y"] = 0.8341385722,
                ["preQuest"] = 5881,
                ["otherInfo"] = 
                {
                    ["time"] = 1536966177,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Breaking Through the Fog",
                ["x"] = 0.4003142416,
            },
            [5] = 
            {
                ["giver"] = "Ridena Devani",
                ["y"] = 0.6888682246,
                ["preQuest"] = 5864,
                ["otherInfo"] = 
                {
                    ["time"] = 1537330242,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Dangerous Breed",
                ["x"] = 0.8033443689,
            },
            [6] = 
            {
                ["giver"] = "Malur Rethan",
                ["y"] = 0.6943665147,
                ["otherInfo"] = 
                {
                    ["time"] = 1537396609,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Like Blood from a Stone",
                ["x"] = 0.3774208128,
            },
            [7] = 
            {
                ["giver"] = "Drelyth Hleran",
                ["y"] = 0.4763798118,
                ["otherInfo"] = 
                {
                    ["time"] = 1537472520,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ancestral Ties",
                ["x"] = 0.3748249710,
            },
            [8] = 
            {
                ["giver"] = "Nakhul",
                ["y"] = 0.5050449371,
                ["otherInfo"] = 
                {
                    ["time"] = 1537474561,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Smuggler's Last Stand",
                ["x"] = 0.2451094985,
            },
            [9] = 
            {
                ["giver"] = "Gray-Skies",
                ["y"] = 0.3093760610,
                ["otherInfo"] = 
                {
                    ["time"] = 1537589497,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Reclaiming Vos",
                ["x"] = 0.6810652018,
            },
            [10] = 
            {
                ["giver"] = "Mistress Dratha",
                ["y"] = 0.2882005572,
                ["preQuest"] = 5840,
                ["otherInfo"] = 
                {
                    ["time"] = 1537743325,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "At Any Cost",
                ["x"] = 0.7347040176,
            },
            [11] = 
            {
                ["giver"] = "Sun-in-Shadow",
                ["y"] = 0.4824226499,
                ["otherInfo"] = 
                {
                    ["time"] = 1537753641,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Heart of a Telvanni",
                ["x"] = 0.7749658823,
            },
            [12] = 
            {
                ["giver"] = "Udami",
                ["y"] = 0.2399889827,
                ["preQuest"] = 5922,
                ["otherInfo"] = 
                {
                    ["time"] = 1537853268,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ashlander Relations",
                ["x"] = 0.2678785026,
            },
            [13] = 
            {
                ["giver"] = "Manore Mobaner",
                ["y"] = 0.3704912066,
                ["otherInfo"] = 
                {
                    ["time"] = 1537856422,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Melodic Mistake",
                ["x"] = 0.1932953149,
            },
            [14] = 
            {
                ["giver"] = "Theyo Prevette",
                ["y"] = 0.3698467016,
                ["otherInfo"] = 
                {
                    ["time"] = 1537930194,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Haunted Grounds",
                ["x"] = 0.2214670777,
            },
            [15] = 
            {
                ["giver"] = "Foreman Lathdar",
                ["y"] = 0.3652084470,
                ["preQuest"] = 5872,
                ["otherInfo"] = 
                {
                    ["time"] = 1537933312,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Hatching a Plan",
                ["x"] = 0.1909684092,
            },
        },
        ["alikr/lostcity_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Letter to Tavo",
                ["y"] = 0.5315229297,
                ["otherInfo"] = 
                {
                    ["time"] = 1536444856,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "An Ill-Fated Venture",
                ["x"] = 0.3969942033,
            },
            [1] = 
            {
                ["giver"] = "Paldeen",
                ["y"] = 0.9049382806,
                ["preQuest"] = 2364,
                ["otherInfo"] = 
                {
                    ["time"] = 1536443214,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Secrets of the Lost City",
                ["x"] = 0.4905205965,
            },
        },
        ["alikr/kozanset_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Hamza",
                ["y"] = 0.4487309158,
                ["otherInfo"] = 
                {
                    ["time"] = 1536432173,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Feathered Fiends",
                ["x"] = 0.5800043941,
            },
        },
        ["glenumbra/daggerfall_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Swineherd Wickton",
                ["y"] = 0.3237193525,
                ["preQuest"] = 3039,
                ["otherInfo"] = 
                {
                    ["time"] = 1533677832,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Swine Thief",
                ["x"] = 0.4550656676,
            },
            [2] = 
            {
                ["giver"] = "Mighty Mordra",
                ["y"] = 0.2878405750,
                ["otherInfo"] = 
                {
                    ["time"] = 1533677886,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "One of the Undaunted",
                ["x"] = 0.5131012201,
            },
            [3] = 
            {
                ["giver"] = "Felande Demarie",
                ["y"] = 0.2740499675,
                ["otherInfo"] = 
                {
                    ["time"] = 1533678341,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Room to Spare",
                ["x"] = 0.4846858084,
            },
            [4] = 
            {
                ["giver"] = "Beggar Matthew",
                ["y"] = 0.5736614466,
                ["preQuest"] = 3011,
                ["otherInfo"] = 
                {
                    ["time"] = 1533679195,
                    ["lang"] = "en",
                    ["api"] = 100023,
                },
                ["name"] = "Back-Alley Murders",
                ["x"] = 0.5158903599,
            },
            [5] = 
            {
                ["giver"] = "Vanus Galerion",
                ["y"] = 0.4101165533,
                ["otherInfo"] = 
                {
                    ["time"] = 1535244755,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Through a Veil Darkly",
                ["x"] = 0.4713554382,
            },
            [6] = 
            {
                ["giver"] = "Arch-Mage Shalidor",
                ["y"] = 0.3904083073,
                ["preQuest"] = 3916,
                ["otherInfo"] = 
                {
                    ["time"] = 1535850142,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Simply Misplaced",
                ["x"] = 0.5207746625,
            },
            [7] = 
            {
                ["giver"] = "Arch-Mage Shalidor",
                ["y"] = 0.3899323344,
                ["preQuest"] = 3953,
                ["otherInfo"] = 
                {
                    ["time"] = 1535871355,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Mad God's Bargain",
                ["x"] = 0.5224900842,
            },
        },
        ["bangkorai/evermore_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Sergeant Antieve",
                ["y"] = 0.5988582373,
                ["otherInfo"] = 
                {
                    ["time"] = 1536637763,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A City in Black",
                ["x"] = 0.2374275327,
            },
            [2] = 
            {
                ["giver"] = "Llotha Nelvani",
                ["y"] = 0.2207296342,
                ["otherInfo"] = 
                {
                    ["time"] = 1536639113,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Grave Matter",
                ["x"] = 0.6538221240,
            },
            [3] = 
            {
                ["giver"] = "Zaag",
                ["y"] = 0.3479261398,
                ["preQuest"] = 4980,
                ["otherInfo"] = 
                {
                    ["time"] = 1536712003,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Conflicted Emotions",
                ["x"] = 0.5188118815,
            },
        },
        ["summerset/summerset_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Silurie",
                ["y"] = 0.5346723199,
                ["preQuest"] = 6170,
                ["otherInfo"] = 
                {
                    ["time"] = 1535251241,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Taste of Fear",
                ["x"] = 0.2925261259,
            },
            [2] = 
            {
                ["giver"] = "Celinar",
                ["y"] = 0.5206859112,
                ["otherInfo"] = 
                {
                    ["time"] = 1535255755,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Runaway's Tale",
                ["x"] = 0.5957511067,
            },
            [3] = 
            {
                ["giver"] = "Hiranesse",
                ["y"] = 0.5220580101,
                ["preQuest"] = 6151,
                ["otherInfo"] = 
                {
                    ["time"] = 1535261874,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Lost at Sea",
                ["x"] = 0.2685208023,
            },
            [4] = 
            {
                ["giver"] = "Rinyde",
                ["y"] = 0.4847295582,
                ["preQuest"] = 6149,
                ["otherInfo"] = 
                {
                    ["time"] = 1535263016,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Manor of Masques",
                ["x"] = 0.3724193871,
            },
            [5] = 
            {
                ["giver"] = "Linwenvar",
                ["y"] = 0.4649710059,
                ["preQuest"] = 6114,
                ["otherInfo"] = 
                {
                    ["time"] = 1535317497,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Old Wounds",
                ["x"] = 0.4583003223,
            },
            [6] = 
            {
                ["giver"] = "Oriandra",
                ["y"] = 0.3748296201,
                ["preQuest"] = 6135,
                ["otherInfo"] = 
                {
                    ["time"] = 1535320156,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Whispers from the Deep",
                ["x"] = 0.5359108448,
            },
            [7] = 
            {
                ["giver"] = "Andewen",
                ["y"] = 0.3742801845,
                ["otherInfo"] = 
                {
                    ["time"] = 1535338816,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Ebon Sanctum",
                ["x"] = 0.3586560786,
            },
            [8] = 
            {
                ["giver"] = "Merenfire",
                ["y"] = 0.3584633172,
                ["otherInfo"] = 
                {
                    ["time"] = 1535338862,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Illusions of Grandeur",
                ["x"] = 0.3263515234,
            },
            [9] = 
            {
                ["giver"] = "Amsha",
                ["y"] = 0.2951898277,
                ["otherInfo"] = 
                {
                    ["time"] = 1535339223,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Wasting Away",
                ["x"] = 0.2576109469,
            },
            [10] = 
            {
                ["giver"] = "Tableau",
                ["y"] = 0.4748214185,
                ["otherInfo"] = 
                {
                    ["time"] = 1535407539,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Hulkynd's Heart",
                ["x"] = 0.3235512078,
            },
            [11] = 
            {
                ["giver"] = "Renzir",
                ["y"] = 0.2113002241,
                ["preQuest"] = 6146,
                ["otherInfo"] = 
                {
                    ["time"] = 1535431714,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "An Unexpected Betrayal",
                ["x"] = 0.2977776527,
            },
            [12] = 
            {
                ["giver"] = "Talomar",
                ["y"] = 0.6039851308,
                ["otherInfo"] = 
                {
                    ["time"] = 1535505848,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Untamed and Unleashed",
                ["x"] = 0.6750555038,
            },
            [13] = 
            {
                ["giver"] = "Igeke Rat-Bite",
                ["y"] = 0.7324187160,
                ["preQuest"] = 6121,
                ["otherInfo"] = 
                {
                    ["time"] = 1535513267,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Gjadil's Legacy",
                ["x"] = 0.7185612917,
            },
            [14] = 
            {
                ["giver"] = "Manacar",
                ["y"] = 0.5546858907,
                ["otherInfo"] = 
                {
                    ["time"] = 1535562876,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Bantering with Bandits",
                ["x"] = 0.2794109285,
            },
            [15] = 
            {
                ["giver"] = "Bailiff Erator",
                ["y"] = 0.3029791117,
                ["preQuest"] = 6140,
                ["otherInfo"] = 
                {
                    ["time"] = 1535564644,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Lauriel's Lament",
                ["x"] = 0.5906194448,
            },
            [16] = 
            {
                ["giver"] = "Miranrel",
                ["y"] = 0.2825572789,
                ["otherInfo"] = 
                {
                    ["time"] = 1535576284,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Gryphon Grievance",
                ["x"] = 0.5512996912,
            },
            [17] = 
            {
                ["giver"] = "Kinlady Ilunsare",
                ["y"] = 0.7353738546,
                ["preQuest"] = 6179,
                ["otherInfo"] = 
                {
                    ["time"] = 1535577799,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Obedience Issues",
                ["x"] = 0.4651895463,
            },
            [18] = 
            {
                ["giver"] = "Pandermalion",
                ["y"] = 0.4188621342,
                ["otherInfo"] = 
                {
                    ["time"] = 1535660442,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Storming the Walls",
                ["x"] = 0.2621946633,
            },
        },
        ["deshaan/mzithumz_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Bedyni the Artificer",
                ["y"] = 0.8867078424,
                ["preQuest"] = 3874,
                ["otherInfo"] = 
                {
                    ["time"] = 1538345943,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Dissonant Commands",
                ["x"] = 0.3381104469,
            },
        },
        ["rivenspire/erokii_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Anenya",
                ["y"] = 0.3673306704,
                ["otherInfo"] = 
                {
                    ["time"] = 1535001830,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Ancient Power",
                ["x"] = 0.7498008013,
            },
        },
        ["alikr/divadschagrinmine_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Armin",
                ["y"] = 0.5220297575,
                ["otherInfo"] = 
                {
                    ["time"] = 1536357513,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Search is Over",
                ["x"] = 0.1543603837,
            },
        },
        ["grahtwood/eldenrootgroundfloor_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Sealed Woodworking Writ",
                ["y"] = 0.6416119933,
                ["preQuest"] = 6022,
                ["otherInfo"] = 
                {
                    ["time"] = 1534216349,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Shield",
                ["x"] = 0.7304733396,
            },
            [2] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["y"] = 0.6416119933,
                ["otherInfo"] = 
                {
                    ["time"] = 1534216360,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Glyph",
                ["x"] = 0.7304733396,
            },
            [3] = 
            {
                ["giver"] = "Sealed Alchemy Writ",
                ["y"] = 0.6324936152,
                ["preQuest"] = 6228,
                ["otherInfo"] = 
                {
                    ["time"] = 1536277342,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Concoction",
                ["x"] = 0.7366622090,
            },
            [4] = 
            {
                ["giver"] = "Sealed Blacksmithing Writ",
                ["y"] = 0.6324936152,
                ["otherInfo"] = 
                {
                    ["time"] = 1536277352,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Weapon",
                ["x"] = 0.7366622090,
            },
            [5] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["y"] = 0.6324936152,
                ["otherInfo"] = 
                {
                    ["time"] = 1536277364,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Glyph",
                ["x"] = 0.7366622090,
            },
            [6] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["y"] = 0.6388408542,
                ["preQuest"] = 5973,
                ["otherInfo"] = 
                {
                    ["time"] = 1536278199,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Glyph",
                ["x"] = 0.7290217876,
            },
            [7] = 
            {
                ["giver"] = "Sealed Alchemy Writ",
                ["y"] = 0.6386429071,
                ["preQuest"] = 5984,
                ["otherInfo"] = 
                {
                    ["time"] = 1538437992,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Concoction",
                ["x"] = 0.7304205298,
            },
            [8] = 
            {
                ["giver"] = "Sealed Blacksmithing Writ",
                ["y"] = 0.6386429071,
                ["preQuest"] = 5990,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438019,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Weapon",
                ["x"] = 0.7304205298,
            },
            [9] = 
            {
                ["giver"] = "Sealed Clothier Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438034,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Masterful Tailoring",
                ["x"] = 0.7304205298,
            },
            [10] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438043,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Glyph",
                ["x"] = 0.7304205298,
            },
            [11] = 
            {
                ["giver"] = "Sealed Provisioning Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438054,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Feast",
                ["x"] = 0.7304205298,
            },
            [12] = 
            {
                ["giver"] = "Sealed Woodworking Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438067,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Shield",
                ["x"] = 0.7304205298,
            },
            [13] = 
            {
                ["giver"] = "Sealed Provisioning Writ",
                ["y"] = 0.6386429071,
                ["preQuest"] = 5978,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438116,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Feast",
                ["x"] = 0.7304205298,
            },
            [14] = 
            {
                ["giver"] = "Sealed Clothier Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438125,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Masterful Tailoring",
                ["x"] = 0.7304205298,
            },
            [15] = 
            {
                ["giver"] = "Sealed Blacksmithing Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438134,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Weapon",
                ["x"] = 0.7304205298,
            },
            [16] = 
            {
                ["giver"] = "Sealed Enchanting Writ",
                ["y"] = 0.6386429071,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438144,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Masterful Glyph",
                ["x"] = 0.7304205298,
            },
            [17] = 
            {
                ["giver"] = "Sealed Clothier Writ",
                ["y"] = 0.6386429071,
                ["preQuest"] = 5978,
                ["otherInfo"] = 
                {
                    ["time"] = 1538438210,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Masterful Leatherwear",
                ["x"] = 0.7304205298,
            },
        },
        ["summerset/dreamingcave02_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.4740376472,
                ["otherInfo"] = 
                {
                    ["time"] = 1535410158,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Psijics' Calling",
                ["x"] = 0.4700719118,
            },
            [2] = 
            {
                ["giver"] = "Josajeh",
                ["y"] = 0.6987097859,
                ["preQuest"] = 6172,
                ["otherInfo"] = 
                {
                    ["time"] = 1535593687,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Breaches On the Bay",
                ["x"] = 0.2159475535,
            },
            [3] = 
            {
                ["giver"] = "Valsirenn",
                ["y"] = 0.4301501811,
                ["preQuest"] = 6125,
                ["otherInfo"] = 
                {
                    ["time"] = 1535773627,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Crystal Tower",
                ["x"] = 0.4051924646,
            },
            [4] = 
            {
                ["giver"] = "Josajeh",
                ["y"] = 0.6967005134,
                ["preQuest"] = 6181,
                ["otherInfo"] = 
                {
                    ["time"] = 1536722193,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Breaches of Frost and Fire",
                ["x"] = 0.2083333284,
            },
            [5] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.4353320599,
                ["preQuest"] = 6185,
                ["otherInfo"] = 
                {
                    ["time"] = 1536983304,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Shattered Staff",
                ["x"] = 0.7799809575,
            },
            [6] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.3812923133,
                ["preQuest"] = 6197,
                ["otherInfo"] = 
                {
                    ["time"] = 1536987133,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Breach Amid the Trees",
                ["x"] = 0.7763853669,
            },
            [7] = 
            {
                ["giver"] = "Josajeh",
                ["y"] = 0.8366116881,
                ["preQuest"] = 6194,
                ["otherInfo"] = 
                {
                    ["time"] = 1537064293,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Time for Mud and Mushrooms",
                ["x"] = 0.2544944882,
            },
            [8] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.4661061764,
                ["preQuest"] = 6190,
                ["otherInfo"] = 
                {
                    ["time"] = 1537150686,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Towers' Remains",
                ["x"] = 0.8109136820,
            },
            [9] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.4019670188,
                ["preQuest"] = 6198,
                ["otherInfo"] = 
                {
                    ["time"] = 1537156099,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Time in Doomcrag's Shadow",
                ["x"] = 0.7952094078,
            },
            [10] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.3982656598,
                ["preQuest"] = 6195,
                ["otherInfo"] = 
                {
                    ["time"] = 1537158261,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Breach Beyond the Crags",
                ["x"] = 0.8043041229,
            },
            [11] = 
            {
                ["giver"] = "Loremaster Celarus",
                ["y"] = 0.3783840835,
                ["preQuest"] = 6196,
                ["otherInfo"] = 
                {
                    ["time"] = 1537239403,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Towers' Fall",
                ["x"] = 0.7910321355,
            },
        },
        ["vvardenfell/viviccity_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Edryno Giryon",
                ["y"] = 0.4175760448,
                ["preQuest"] = 6007,
                ["otherInfo"] = 
                {
                    ["time"] = 1536777892,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "A Late Delivery",
                ["x"] = 0.5224552155,
            },
        },
        ["summerset/lillandrill_base"] = 
        {
            [2] = 
            {
                ["giver"] = "Tindoria",
                ["y"] = 0.8553342223,
                ["otherInfo"] = 
                {
                    ["time"] = 1535503983,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "The Perils of Art",
                ["x"] = 0.3591848612,
            },
            [1] = 
            {
                ["giver"] = "Faralan",
                ["y"] = 0.6400873661,
                ["otherInfo"] = 
                {
                    ["time"] = 1535493532,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Murder In Lillandril",
                ["x"] = 0.5875323415,
            },
        },
        ["alikr/santaki_base"] = 
        {
            [1] = 
            {
                ["giver"] = "Tharayya Journal Entry: 2",
                ["y"] = 0.4405688643,
                ["preQuest"] = 4659,
                ["otherInfo"] = 
                {
                    ["time"] = 1536024066,
                    ["lang"] = "en",
                    ["api"] = 100024,
                },
                ["name"] = "Tharayya's Trail",
                ["x"] = 0.5429641008,
            },
        },
    },
    ["startTime"] = 1533505942,
    ["questInfo"] = 
    {
        [6144] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2561] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6146] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2564] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6149] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6150] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6151] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6152] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2569] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [523] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6157] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4622] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6159] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2576] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2578] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2068] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6165] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6166] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4631] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6170] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6172] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 10,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6174] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6176] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6177] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6179] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6180] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6181] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6185] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6190] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4656] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4145] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6194] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5171] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6196] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3637] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6198] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [1591] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [575] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4672] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6218] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4686] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1615] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2130] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6227] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6228] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1633] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2146] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3172] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1637] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [614] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1639] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4202] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2161] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3187] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3190] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3192] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4731] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5247] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5249] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2184] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3721] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5259] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1678] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4751] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2192] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [657] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4754] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4246] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [1687] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4760] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4761] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5274] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4767] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5283] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5799] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5803] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1709] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2222] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5303] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5309] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5312] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6093] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 1,
            },
            ["repeatType"] = 0,
        },
        [2344] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6143] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 9,
                [3] = 10,
            },
            ["repeatType"] = 0,
        },
        [2558] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1554] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6140] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1735] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3784] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4107] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6145] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2251] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5836] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6137] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4088] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2255] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5840] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5841] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6135] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6142] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3286] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3285] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4822] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4659] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [728] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3059] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6160] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6162] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6131] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5857] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5342] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6126] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
            ["repeatType"] = 0,
        },
        [736] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [737] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4834] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5859] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3302] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4336] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5862] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5863] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4840] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3305] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5832] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4843] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4844] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3050] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6121] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4335] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5872] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6197] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3314] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5368] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5876] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5877] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4857] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3783] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5880] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5881] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4858] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5883] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5374] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5885] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5886] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5887] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5888] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5377] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6199] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 7,
            },
            ["repeatType"] = 0,
        },
        [4839] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5893] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3333] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3296] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6111] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5900] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3337] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5392] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5903] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5388] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5901] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5902] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3343] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3344] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5905] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5394] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5395] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4884] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2567] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2240] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5919] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3864] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3353] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5914] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4379] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4903] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5431] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5406] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5407] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5920] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5409] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3874] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5923] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5412] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4901] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4902] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3367] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5416] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5417] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5418] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4054] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3029] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5933] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4923] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6099] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1341] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4401] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [465] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3379] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4916] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3381] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4926] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3383] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4920] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3385] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6095] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1339] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2364] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4925] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5950] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4927] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5952] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
            ["repeatType"] = 0,
        },
        [4929] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4930] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4931] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4638] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2187] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4934] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3020] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4936] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4937] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4841] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5972] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [3916] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3414] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3918] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3416] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4944] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4945] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4443] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4435] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3412] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4949] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5974] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [5975] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [4952] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5977] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [5978] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [5979] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [1346] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5981] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [4958] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5983] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [5984] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [4961] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 10,
            },
            ["repeatType"] = 0,
        },
        [5400] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2403] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2404] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4965] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5990] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [1383] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1384] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4972] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3011] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4971] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3436] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2193] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3438] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5413] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3440] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3953] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4980] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6003] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 7,
                [4] = 9,
                [5] = 1,
            },
            ["repeatType"] = 0,
        },
        [6004] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1541] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6078] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6007] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6008] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4473] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4403] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1536] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3964] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6075] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4942] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6136] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2566] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5976] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [3970] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6153] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2436] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3509] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6022] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [5973] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [2408] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6025] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5051] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2481] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5954] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 2,
            },
            ["repeatType"] = 0,
        },
        [521] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1437] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6036] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5021] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5022] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2450] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2451] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5012] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6048] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
            ["repeatType"] = 0,
        },
        [5014] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6050] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6040] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3993] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3482] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6052] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
            ["repeatType"] = 0,
        },
        [5020] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6045] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6046] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6047] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
            ["repeatType"] = 0,
        },
        [5024] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6049] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5538] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 10,
            },
            ["repeatType"] = 0,
        },
        [5027] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4516] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5018] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2997] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4519] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6056] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6057] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6058] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6059] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6060] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6061] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3997] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6063] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4928] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4529] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6066] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4531] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5396] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4533] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2998] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4535] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4565] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3001] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6074] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3003] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3004] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4472] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2494] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2495] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2496] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2497] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1568] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6083] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6084] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5415] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6086] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6087] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2504] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3017] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4721] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3019] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6092] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1485] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6094] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 1,
            },
            ["repeatType"] = 0,
        },
        [3023] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6096] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6097] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5948] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 7,
                [4] = 9,
                [5] = 1,
            },
            ["repeatType"] = 0,
        },
        [467] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6100] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6101] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6102] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6103] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2356] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5922] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
            ["repeatType"] = 0,
        },
        [4888] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3035] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6195] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6109] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5389] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3039] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6112] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6113] = 
        {
            ["rewardTypes"] = 
            {
                [4] = 1,
                [1] = 7,
                [2] = 7,
                [3] = 9,
            },
            ["repeatType"] = 0,
        },
        [6114] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6115] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6116] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6117] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6118] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6119] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2536] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2537] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2538] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5864] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3303] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6125] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3566] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6127] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4080] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6129] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6130] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [499] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6132] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2549] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2550] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1527] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2552] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1529] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6138] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6139] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2556] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6141] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2046] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2047] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
    },
}
