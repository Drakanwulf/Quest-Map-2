QM_Scout =
{
    ["subZones"] = 
    {
        ["glenumbra/glenumbra_base"] = 
        {
            ["glenumbra/daggerfall_base"] = 
            {
                ["x"] = 0.7309818864,
                ["y"] = 0.3731749952,
            },
            ["glenumbra/cryptwatchfort_base"] = 
            {
                ["x"] = 0.2532835305,
                ["y"] = 0.6058680415,
            },
            ["glenumbra/silumm_base"] = 
            {
                ["x"] = 0.6779845357,
                ["y"] = 0.2721574605,
            },
            ["glenumbra/spindleclutch_base"] = 
            {
                ["x"] = 0.3366774917,
                ["y"] = 0.7143661976,
            },
            ["glenumbra/eboncrypt_base"] = 
            {
                ["x"] = 0.3692837954,
                ["y"] = 0.4798353016,
            },
            ["glenumbra/tomboflostkings_base"] = 
            {
                ["x"] = 0.2866012454,
                ["y"] = 0.7805057764,
            },
            ["glenumbra/ilessantower_base"] = 
            {
                ["x"] = 0.7259832025,
                ["y"] = 0.3480412066,
            },
        },
        ["summerset/summerset_base"] = 
        {
            ["summerset/ui_map"] = 
            {
                ["x"] = 0.3561471999,
                ["y"] = 0.4230011404,
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            ["stormhaven/aphrenshold_base"] = 
            {
                ["x"] = 0.4917228520,
                ["y"] = 0.6410685778,
            },
            ["stormhaven/godrunsdream_base"] = 
            {
                ["x"] = 0.4834085703,
                ["y"] = 0.7412771583,
            },
            ["stormhaven/pariahcatacombs_base"] = 
            {
                ["x"] = 0.4301457107,
                ["y"] = 0.4577028453,
            },
            ["stormhaven/bearclawmine_base"] = 
            {
                ["x"] = 0.4329885840,
                ["y"] = 0.7857285738,
            },
            ["stormhaven/alcairecastle_base"] = 
            {
                ["x"] = 0.2951657176,
                ["y"] = 0.3298285604,
            },
            ["stormhaven/wayrest_base"] = 
            {
                ["x"] = 0.6020143032,
                ["y"] = 0.3844971359,
            },
            ["stormhaven/norvulkruins_base"] = 
            {
                ["x"] = 0.3670828640,
                ["y"] = 0.6055743098,
            },
            ["stormhaven/windridgecave_base"] = 
            {
                ["x"] = 0.2765971422,
                ["y"] = 0.2868742943,
            },
            ["stormhaven/portdunwatch_base"] = 
            {
                ["x"] = 0.3236285746,
                ["y"] = 0.3078914285,
            },
            ["stormhaven/bonesnapruinssecret_base"] = 
            {
                ["x"] = 0.4975742996,
                ["y"] = 0.3175171316,
            },
        },
        ["alikr/alikr_base"] = 
        {
            ["alikr/sentinel_base"] = 
            {
                ["x"] = 0.3627234399,
                ["y"] = 0.5104555488,
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            ["rivenspire/tribulationcrypt_base"] = 
            {
                ["x"] = 0.6021974683,
                ["y"] = 0.6716846228,
            },
            ["rivenspire/shadowfatecavern_base"] = 
            {
                ["x"] = 0.7164837718,
                ["y"] = 0.2099232525,
            },
            ["rivenspire/lorkrataruinsa_base"] = 
            {
                ["x"] = 0.4828965664,
                ["y"] = 0.5993559957,
            },
            ["rivenspire/doomcragshroudedpass_base"] = 
            {
                ["x"] = 0.4524268210,
                ["y"] = 0.2928013802,
            },
            ["rivenspire/edraldundercroftdomed_base"] = 
            {
                ["x"] = 0.5017006397,
                ["y"] = 0.7009591460,
            },
        },
    },
    ["quests"] = 
    {
        ["rivenspire/tribulationcrypt_base"] = 
        {
            [1] = 
            {
                ["name"] = "A Past Remembered",
                ["y"] = 0.1962851435,
                ["x"] = 0.2981927693,
                ["preQuest"] = 4844,
                ["giver"] = "Ancient Sword",
                ["otherInfo"] = 
                {
                    ["time"] = 1534718973,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["summerset/ui_map"] = 
        {
            [1] = 
            {
                ["y"] = 0.2734320164,
                ["x"] = 0.4132726490,
                ["name"] = "Woe of the Welkynars",
                ["giver"] = "Olorime",
                ["otherInfo"] = 
                {
                    ["time"] = 1534294704,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/farangelsdelve_base"] = 
        {
            [1] = 
            {
                ["name"] = "Stolen Ashes",
                ["y"] = 0.4242919385,
                ["x"] = 0.4327341914,
                ["preQuest"] = 2550,
                ["giver"] = "Tomb Urn",
                ["otherInfo"] = 
                {
                    ["time"] = 1534129561,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/koeglinvillage_base"] = 
        {
            [1] = 
            {
                ["name"] = "False Accusations",
                ["y"] = 0.3335759938,
                ["x"] = 0.3885127902,
                ["preQuest"] = 3412,
                ["giver"] = "Dame Dabienne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533765631,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "The Slavers",
                ["y"] = 0.5187935233,
                ["x"] = 0.6060275435,
                ["preQuest"] = 2494,
                ["giver"] = "Margot Oscent",
                ["otherInfo"] = 
                {
                    ["time"] = 1533769172,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "To Alcaire Castle",
                ["y"] = 0.3445196748,
                ["x"] = 0.3553662896,
                ["preQuest"] = 2556,
                ["giver"] = "Dame Dabienne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533775980,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/shornhelm_base"] = 
        {
            [4] = 
            {
                ["name"] = "Assassin Hunter",
                ["y"] = 0.3113873005,
                ["x"] = 0.5138304830,
                ["preQuest"] = 4945,
                ["giver"] = "Adusa-daro",
                ["otherInfo"] = 
                {
                    ["time"] = 1534735695,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Dream-Walk Into Darkness",
                ["y"] = 0.2087104321,
                ["x"] = 0.5924155712,
                ["preQuest"] = 4902,
                ["giver"] = "High King Emeric",
                ["otherInfo"] = 
                {
                    ["time"] = 1534547100,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "A Spy in Shornhelm",
                ["y"] = 0.3165285885,
                ["x"] = 0.5225196481,
                ["preQuest"] = 4834,
                ["giver"] = "Adusa-daro",
                ["otherInfo"] = 
                {
                    ["time"] = 1534720776,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6325260401,
                ["x"] = 0.4601444602,
                ["name"] = "Children of Yokuda",
                ["giver"] = "Nicolene",
                ["otherInfo"] = 
                {
                    ["time"] = 1534724812,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["auridon/vulkhelguard_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.6363090277,
                ["x"] = 0.2813375592,
                ["name"] = "Provisioner Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6363090277,
                ["x"] = 0.2813375592,
                ["name"] = "Enchanter Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033476,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.6363090277,
                ["x"] = 0.2813375592,
                ["name"] = "Alchemist Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033477,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5947007537,
                ["x"] = 0.2248924077,
                ["name"] = "Clothier Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.5947007537,
                ["x"] = 0.2248924077,
                ["name"] = "Blacksmith Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033532,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["y"] = 0.5947007537,
                ["x"] = 0.2248924077,
                ["name"] = "Woodworker Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.5947007537,
                ["x"] = 0.2248924077,
                ["name"] = "Jewelry Crafting Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534033533,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.6336819530,
                ["x"] = 0.2803492844,
                ["name"] = "Provisioner Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.6336819530,
                ["x"] = 0.2803492844,
                ["name"] = "Enchanter Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196951,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.6336819530,
                ["x"] = 0.2803492844,
                ["name"] = "Alchemist Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196952,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.5952637196,
                ["x"] = 0.2243419737,
                ["name"] = "Clothier Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5952637196,
                ["x"] = 0.2243419737,
                ["name"] = "Blacksmith Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.5952637196,
                ["x"] = 0.2243419737,
                ["name"] = "Woodworker Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214703,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.5952637196,
                ["x"] = 0.2243419737,
                ["name"] = "Jewelry Crafting Writ",
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214704,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.6322933435,
                ["x"] = 0.2811499238,
                ["name"] = "Provisioner Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["y"] = 0.6322933435,
                ["x"] = 0.2811499238,
                ["name"] = "Enchanter Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214741,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.6322933435,
                ["x"] = 0.2811499238,
                ["name"] = "Alchemist Writ",
                ["giver"] = "Consumables Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534214742,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["name"] = "Masterful Leatherwear",
                ["y"] = 0.5761359334,
                ["x"] = 0.3380454481,
                ["preQuest"] = 6228,
                ["giver"] = "Sealed Clothier Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534215666,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["y"] = 0.5761359334,
                ["x"] = 0.3380454481,
                ["name"] = "A Masterful Concoction",
                ["giver"] = "Sealed Alchemy Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534215692,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/rivenspire_base"] = 
        {
            [1] = 
            {
                ["name"] = "Shornhelm Divided",
                ["y"] = 0.7394628525,
                ["x"] = 0.4597792029,
                ["preQuest"] = 4901,
                ["giver"] = "Darien Gautier",
                ["otherInfo"] = 
                {
                    ["time"] = 1534398094,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.6906269193,
                ["x"] = 0.4797356725,
                ["name"] = "Under Siege",
                ["giver"] = "Daribert Hurier",
                ["otherInfo"] = 
                {
                    ["time"] = 1534398418,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5729492903,
                ["x"] = 0.5490812063,
                ["name"] = "A Traitor's Tale",
                ["giver"] = "Scholar Cantier",
                ["otherInfo"] = 
                {
                    ["time"] = 1534458595,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["name"] = "Dearly Departed",
                ["y"] = 0.6188712120,
                ["x"] = 0.4653404057,
                ["preQuest"] = 3286,
                ["giver"] = "Jowan Hinault",
                ["otherInfo"] = 
                {
                    ["time"] = 1534458893,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6888028383,
                ["x"] = 0.3692457676,
                ["name"] = "Rusty Daggers",
                ["giver"] = "Bumnog",
                ["otherInfo"] = 
                {
                    ["time"] = 1534547666,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["name"] = "In the Doghouse",
                ["y"] = 0.6280971169,
                ["x"] = 0.2783106267,
                ["preQuest"] = 5012,
                ["giver"] = "Nathalye Ervine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534553708,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.6459167004,
                ["x"] = 0.2556575239,
                ["name"] = "The Blood-Cursed Town",
                ["giver"] = "Michel Gette",
                ["otherInfo"] = 
                {
                    ["time"] = 1534553764,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["name"] = "The Blood-Splattered Shield",
                ["y"] = 0.4514686763,
                ["x"] = 0.2930417359,
                ["preQuest"] = 4903,
                ["giver"] = "Count Verandis Ravenwatch",
                ["otherInfo"] = 
                {
                    ["time"] = 1534567301,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["name"] = "The Concealing Veil",
                ["y"] = 0.6468122602,
                ["x"] = 0.2146217972,
                ["preQuest"] = 465,
                ["giver"] = "Gwendis",
                ["otherInfo"] = 
                {
                    ["time"] = 1534627281,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.4664203823,
                ["x"] = 0.6914007068,
                ["name"] = "A Change of Heart",
                ["giver"] = "Federic Seychelle",
                ["otherInfo"] = 
                {
                    ["time"] = 1534627498,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["name"] = "Northpoint in Peril",
                ["y"] = 0.4809440672,
                ["x"] = 0.5995568037,
                ["preQuest"] = 4857,
                ["giver"] = "Count Verandis Ravenwatch",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631512,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5149237514,
                ["x"] = 0.5871042013,
                ["name"] = "Archaic Relics",
                ["giver"] = "Alvaren Garoutte",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631587,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.6254729033,
                ["x"] = 0.6284329295,
                ["name"] = "Crimes of the Past",
                ["giver"] = "Marisette",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634478,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.6622117758,
                ["x"] = 0.6064910293,
                ["name"] = "Hope Lost",
                ["giver"] = "Adusa-daro",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634772,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["y"] = 0.5597689748,
                ["x"] = 0.6333553791,
                ["name"] = "The Price of Longevity",
                ["giver"] = "Strange Sapling",
                ["otherInfo"] = 
                {
                    ["time"] = 1534651278,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["name"] = "The Assassin's List",
                ["y"] = 0.4603060186,
                ["x"] = 0.2959030271,
                ["preQuest"] = 4926,
                ["giver"] = "Adusa-daro",
                ["otherInfo"] = 
                {
                    ["time"] = 1534736590,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.6350313425,
                ["x"] = 0.2673034668,
                ["name"] = "The Sanctifying Flames",
                ["giver"] = "Lieutenant Sgugh",
                ["otherInfo"] = 
                {
                    ["time"] = 1534737005,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["name"] = "Threat of Death",
                ["y"] = 0.4686428905,
                ["x"] = 0.2859297097,
                ["preQuest"] = 4927,
                ["giver"] = "Adusa-daro",
                ["otherInfo"] = 
                {
                    ["time"] = 1534737994,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["name"] = "A Dagger to the Heart",
                ["y"] = 0.4693705440,
                ["x"] = 0.2863873839,
                ["preQuest"] = 4928,
                ["giver"] = "Adusa-daro",
                ["otherInfo"] = 
                {
                    ["time"] = 1534738422,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["giver"] = "Constable Agazu",
                ["y"] = 0.4420057237,
                ["x"] = 0.6877788305,
                ["preQuest"] = 4965,
                ["name"] = "Frightened Folk",
                ["otherInfo"] = 
                {
                    ["time"] = 1534742538,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/alcairecastle_base"] = 
        {
            [4] = 
            {
                ["name"] = "Tracking Sir Hughes",
                ["y"] = 0.4368499517,
                ["x"] = 0.4016301334,
                ["preQuest"] = 2567,
                ["giver"] = "Duke Nathaniel",
                ["otherInfo"] = 
                {
                    ["time"] = 1533955857,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Two Sides to Every Coin",
                ["y"] = 0.3651475012,
                ["x"] = 0.4701412022,
                ["preQuest"] = 2552,
                ["giver"] = "Sir Hughes",
                ["otherInfo"] = 
                {
                    ["time"] = 1533950269,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "Life of the Duchess",
                ["y"] = 0.4338193238,
                ["x"] = 0.4061531425,
                ["preQuest"] = 2564,
                ["giver"] = "Duchess Lakana",
                ["otherInfo"] = 
                {
                    ["time"] = 1533951481,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "The Safety of the Kingdom",
                ["y"] = 0.5228102207,
                ["x"] = 0.3367925584,
                ["preQuest"] = 2566,
                ["giver"] = "Sir Hughes",
                ["otherInfo"] = 
                {
                    ["time"] = 1533955422,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/crosswych_base"] = 
        {
            [1] = 
            {
                ["name"] = "The Miners' Lament",
                ["y"] = 0.6053073406,
                ["x"] = 0.6166941524,
                ["preQuest"] = 3337,
                ["giver"] = "Tamien Sellan",
                ["otherInfo"] = 
                {
                    ["time"] = 1533595782,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "Crosswych Reclaimed",
                ["y"] = 0.6034337878,
                ["x"] = 0.6395968795,
                ["preQuest"] = 3302,
                ["giver"] = "Tamien Sellan",
                ["otherInfo"] = 
                {
                    ["time"] = 1533596819,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.5922731757,
                ["x"] = 0.6025131345,
                ["name"] = "The Missing Prophecy",
                ["giver"] = "Alessio Guillon",
                ["otherInfo"] = 
                {
                    ["time"] = 1533608597,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.5522983670,
                ["x"] = 0.5974093080,
                ["name"] = "Anchors from the Harbour",
                ["giver"] = "Bera Moorsmith",
                ["otherInfo"] = 
                {
                    ["time"] = 1533608894,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["y"] = 0.6174532175,
                ["x"] = 0.4721064568,
                ["name"] = "Long Lost Lore",
                ["giver"] = "Adelle Montagne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533609272,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/ilessantower_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.7700323462,
                ["x"] = 0.5450952053,
                ["name"] = "Red Rook Resources",
                ["giver"] = "Red Rook Note",
                ["otherInfo"] = 
                {
                    ["time"] = 1533684860,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/minesofkhuras_base"] = 
        {
            [1] = 
            {
                ["name"] = "A Brush With Death",
                ["y"] = 0.7706518769,
                ["x"] = 0.3869094849,
                ["preQuest"] = 3440,
                ["giver"] = "Guifford Vinielle's Sketchbook",
                ["otherInfo"] = 
                {
                    ["time"] = 1533705261,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/glenumbra_base"] = 
        {
            [1] = 
            {
                ["name"] = "A Dangerous Dream",
                ["y"] = 0.2641271353,
                ["x"] = 0.6233919263,
                ["preQuest"] = 3379,
                ["giver"] = "Recruit Maelle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506571,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2552480102,
                ["x"] = 0.6356987953,
                ["name"] = "Legitimate Interests",
                ["giver"] = "Garmeg the Ironfinder",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506619,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.2836774588,
                ["x"] = 0.6614254117,
                ["name"] = "Vines and Villains",
                ["giver"] = "Provost Piper",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506677,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.2603922486,
                ["x"] = 0.6967237592,
                ["name"] = "Cursed Treasure",
                ["giver"] = "Sir Marley Oris",
                ["otherInfo"] = 
                {
                    ["time"] = 1533506771,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["name"] = "Forgotten Ancestry",
                ["y"] = 0.2198418677,
                ["x"] = 0.7467461228,
                ["preQuest"] = 6227,
                ["giver"] = "Harald Winvale",
                ["otherInfo"] = 
                {
                    ["time"] = 1533526292,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["name"] = "The Jeweled Crown of Anton",
                ["y"] = 0.2978167236,
                ["x"] = 0.7838526368,
                ["preQuest"] = 3509,
                ["giver"] = "Stibbons",
                ["otherInfo"] = 
                {
                    ["time"] = 1533528128,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["name"] = "Servants of Ancient Kings",
                ["y"] = 0.1833901852,
                ["x"] = 0.7397236228,
                ["preQuest"] = 3050,
                ["giver"] = "King Donel Deleyn",
                ["otherInfo"] = 
                {
                    ["time"] = 1533594760,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.2773717642,
                ["x"] = 0.5530404449,
                ["name"] = "The Corpse Horde",
                ["giver"] = "Sir Malik Nasir",
                ["otherInfo"] = 
                {
                    ["time"] = 1533609896,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["name"] = "Farlivere's Gambit",
                ["y"] = 0.7047001719,
                ["x"] = 0.4874128997,
                ["preQuest"] = 3314,
                ["giver"] = "Daggerfall Patroller",
                ["otherInfo"] = 
                {
                    ["time"] = 1533616621,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["name"] = "Disorganized Crime",
                ["y"] = 0.6687227488,
                ["x"] = 0.5088144541,
                ["preQuest"] = 3001,
                ["giver"] = "Lord Arcady Noellaume",
                ["otherInfo"] = 
                {
                    ["time"] = 1533617294,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["y"] = 0.6681137681,
                ["x"] = 0.5077500343,
                ["name"] = "Lady Eloise's Lockbox",
                ["giver"] = "Lady Eloise Noellaume",
                ["otherInfo"] = 
                {
                    ["time"] = 1533617404,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["name"] = "Wicked Trade",
                ["y"] = 0.4949662387,
                ["x"] = 0.5817878842,
                ["preQuest"] = 4335,
                ["giver"] = "Erwan Castille",
                ["otherInfo"] = 
                {
                    ["time"] = 1533670237,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["name"] = "Wyrd and Coven",
                ["y"] = 0.5040016770,
                ["x"] = 0.6777231693,
                ["preQuest"] = 3023,
                ["giver"] = "Guy LeBlanc",
                ["otherInfo"] = 
                {
                    ["time"] = 1533670926,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.4546503127,
                ["x"] = 0.6808248162,
                ["name"] = "Crocodile Bounty",
                ["giver"] = "Mercenary",
                ["otherInfo"] = 
                {
                    ["time"] = 1533671046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["name"] = "Legacy of Baelborne Rock",
                ["y"] = 0.7100141644,
                ["x"] = 0.3761095703,
                ["preQuest"] = 3017,
                ["giver"] = "Athel Baelborne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533679671,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["name"] = "The Dagger's Edge",
                ["y"] = 0.6140681505,
                ["x"] = 0.3377877176,
                ["preQuest"] = 3414,
                ["giver"] = "Lord Alain Diel",
                ["otherInfo"] = 
                {
                    ["time"] = 1533686910,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.4058459699,
                ["x"] = 0.4421305656,
                ["name"] = "The Ghosts of Westtry",
                ["giver"] = "Leon Milielle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533699922,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["name"] = "Memento Mori",
                ["y"] = 0.4247629941,
                ["x"] = 0.3977132440,
                ["preQuest"] = 3019,
                ["giver"] = "Leon Milielle",
                ["otherInfo"] = 
                {
                    ["time"] = 1533701453,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["name"] = "Signals of Dominion",
                ["y"] = 0.3811810613,
                ["x"] = 0.3257557452,
                ["preQuest"] = 3020,
                ["giver"] = "Lieutenant Clarice",
                ["otherInfo"] = 
                {
                    ["time"] = 1533702206,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["y"] = 0.3935525715,
                ["x"] = 0.3128614426,
                ["name"] = "Wayward Scouts",
                ["giver"] = "Scout's Orders",
                ["otherInfo"] = 
                {
                    ["time"] = 1533702234,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/bonesnapruinssecret_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.6375247836,
                ["x"] = 0.6059898734,
                ["name"] = "Lost Lions",
                ["giver"] = "Sir Edgard",
                ["otherInfo"] = 
                {
                    ["time"] = 1533871296,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Repairing the Cage",
                ["y"] = 0.8454304934,
                ["x"] = 0.6948909760,
                ["preQuest"] = 1637,
                ["giver"] = "Battlemage Gaston",
                ["otherInfo"] = 
                {
                    ["time"] = 1533868567,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/wayrest_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.1780604571,
                ["x"] = 0.4391658008,
                ["name"] = "The Debt Collector's Debts",
                ["giver"] = "M'jaddha",
                ["otherInfo"] = 
                {
                    ["time"] = 1534116513,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.1300478876,
                ["x"] = 0.2756144106,
                ["name"] = "The Dreugh Threat",
                ["giver"] = "Sergeant Stegine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534125955,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "They Dragged Him Away",
                ["y"] = 0.0535364039,
                ["x"] = 0.2342794538,
                ["preQuest"] = 2068,
                ["giver"] = "Adiel Charnis",
                ["otherInfo"] = 
                {
                    ["time"] = 1534127126,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["name"] = "Clothier Writ",
                ["y"] = 0.2255538255,
                ["x"] = 0.3749423027,
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["name"] = "Blacksmith Writ",
                ["y"] = 0.2255538255,
                ["x"] = 0.3749423027,
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["name"] = "Woodworker Writ",
                ["y"] = 0.2255538255,
                ["x"] = 0.3749423027,
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196576,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["name"] = "Jewelry Crafting Writ",
                ["y"] = 0.2255538255,
                ["x"] = 0.3749423027,
                ["preQuest"] = 1527,
                ["giver"] = "Equipment Crafting Writs",
                ["otherInfo"] = 
                {
                    ["time"] = 1534196577,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.2736096680,
                ["x"] = 1.0325227976,
                ["name"] = "Old Adventurers",
                ["giver"] = "Janne Marolles",
                ["otherInfo"] = 
                {
                    ["time"] = 1534283292,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["name"] = "To The Clockwork City",
                ["y"] = 0.3309824765,
                ["x"] = 0.6182646751,
                ["preQuest"] = 1615,
                ["giver"] = "Eldrasea Deras",
                ["otherInfo"] = 
                {
                    ["time"] = 1534367222,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["name"] = "Vaermina's Gambit",
                ["y"] = 0.4614630342,
                ["x"] = 0.4303103685,
                ["preQuest"] = 521,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534373250,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["name"] = "The Road to Rivenspire",
                ["y"] = 0.4613187909,
                ["x"] = 0.3795575202,
                ["preQuest"] = 575,
                ["giver"] = "High King Emeric",
                ["otherInfo"] = 
                {
                    ["time"] = 1534374724,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.5017451048,
                ["x"] = 0.1636523604,
                ["name"] = "Pledge: Moon Hunter Keep",
                ["giver"] = "Urgarlag Chief-bane",
                ["otherInfo"] = 
                {
                    ["time"] = 1534387635,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/hoarfrost_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5418079495,
                ["x"] = 0.4679913223,
                ["name"] = "The Wayward Son",
                ["giver"] = "Captain Thayer",
                ["otherInfo"] = 
                {
                    ["time"] = 1534631769,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "The Bandit",
                ["y"] = 0.5901261568,
                ["x"] = 0.3932930827,
                ["preQuest"] = 5020,
                ["giver"] = "Captain Thayer",
                ["otherInfo"] = 
                {
                    ["time"] = 1534634333,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "The Lover",
                ["y"] = 0.5798182487,
                ["x"] = 0.4004475772,
                ["preQuest"] = 5022,
                ["giver"] = "Captain Thayer",
                ["otherInfo"] = 
                {
                    ["time"] = 1534650828,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/cryptwatchfort_base"] = 
        {
            [1] = 
            {
                ["name"] = "Fortune in Failure",
                ["y"] = 0.3049505055,
                ["x"] = 0.3861386180,
                ["preQuest"] = 4080,
                ["giver"] = "Hastily Scribbled Note",
                ["otherInfo"] = 
                {
                    ["time"] = 1533695799,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/badmanscave_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.5939509273,
                ["x"] = 0.6003810167,
                ["name"] = "Can't Take It With Them",
                ["giver"] = "Finvir",
                ["otherInfo"] = 
                {
                    ["time"] = 1533694067,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/portdunwatch_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3056835532,
                ["x"] = 0.4718382061,
                ["name"] = "Do as I Say",
                ["giver"] = "Remy Berard",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943190,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/bearclawmine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.4829317331,
                ["x"] = 0.3204819262,
                ["name"] = "Next of Kin",
                ["giver"] = "Hubert",
                ["otherInfo"] = 
                {
                    ["time"] = 1534364051,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["rivenspire/crestshademine_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3638949394,
                ["x"] = 0.4132508039,
                ["name"] = "Friend of Trolls",
                ["giver"] = "Troll Socialization Research Notes",
                ["otherInfo"] = 
                {
                    ["time"] = 1534624071,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/daggerfall_base"] = 
        {
            [4] = 
            {
                ["name"] = "Back-Alley Murders",
                ["y"] = 0.5736614466,
                ["x"] = 0.5158903599,
                ["preQuest"] = 3011,
                ["giver"] = "Beggar Matthew",
                ["otherInfo"] = 
                {
                    ["time"] = 1533679195,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "Swine Thief",
                ["y"] = 0.3237193525,
                ["x"] = 0.4550656676,
                ["preQuest"] = 3039,
                ["giver"] = "Swineherd Wickton",
                ["otherInfo"] = 
                {
                    ["time"] = 1533677832,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["y"] = 0.2878405750,
                ["x"] = 0.5131012201,
                ["name"] = "One of the Undaunted",
                ["giver"] = "Mighty Mordra",
                ["otherInfo"] = 
                {
                    ["time"] = 1533677886,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["y"] = 0.2740499675,
                ["x"] = 0.4846858084,
                ["name"] = "Room to Spare",
                ["giver"] = "Felande Demarie",
                ["otherInfo"] = 
                {
                    ["time"] = 1533678341,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["grahtwood/eldenrootgroundfloor_base"] = 
        {
            [2] = 
            {
                ["y"] = 0.6416119933,
                ["x"] = 0.7304733396,
                ["name"] = "A Masterful Glyph",
                ["giver"] = "Sealed Enchanting Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534216360,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [1] = 
            {
                ["name"] = "A Masterful Shield",
                ["y"] = 0.6416119933,
                ["x"] = 0.7304733396,
                ["preQuest"] = 6022,
                ["giver"] = "Sealed Woodworking Writ",
                ["otherInfo"] = 
                {
                    ["time"] = 1534216349,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/stormhaven_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.3512257040,
                ["x"] = 0.1734942794,
                ["name"] = "A Family Affair",
                ["giver"] = "Merthyval Lort",
                ["otherInfo"] = 
                {
                    ["time"] = 1533765724,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [2] = 
            {
                ["name"] = "Scamp Invasion",
                ["y"] = 0.3290571570,
                ["x"] = 0.1847085655,
                ["preQuest"] = 2561,
                ["giver"] = "William Nurin",
                ["otherInfo"] = 
                {
                    ["time"] = 1533766855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [3] = 
            {
                ["name"] = "Can't Leave Without Her",
                ["y"] = 0.4067914188,
                ["x"] = 0.2047742903,
                ["preQuest"] = 2578,
                ["giver"] = "Phinis Vanne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533767983,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [4] = 
            {
                ["y"] = 0.3682714403,
                ["x"] = 0.2087714225,
                ["name"] = "The Slumbering Farmer",
                ["giver"] = "Brother Perry",
                ["otherInfo"] = 
                {
                    ["time"] = 1533768092,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [5] = 
            {
                ["name"] = "Rozenn's Dream",
                ["y"] = 0.3650457263,
                ["x"] = 0.2702714205,
                ["preQuest"] = 1678,
                ["giver"] = "Ingride Vanne",
                ["otherInfo"] = 
                {
                    ["time"] = 1533776633,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [6] = 
            {
                ["name"] = "Lighthouse Attack Plans",
                ["y"] = 0.4724285603,
                ["x"] = 0.1770542860,
                ["preQuest"] = 1709,
                ["giver"] = "Attack Plans",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846079,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [7] = 
            {
                ["y"] = 0.5024399757,
                ["x"] = 0.1766742915,
                ["name"] = "Repair Koeglin Lighthouse",
                ["giver"] = "Tyree Marence",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846248,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [8] = 
            {
                ["y"] = 0.5064542890,
                ["x"] = 0.1754028499,
                ["name"] = "Repair Koeglin Lighthouse",
                ["giver"] = "Tyree Marence",
                ["otherInfo"] = 
                {
                    ["time"] = 1533846986,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [9] = 
            {
                ["y"] = 0.4726114273,
                ["x"] = 0.1770028621,
                ["name"] = "Lighthouse Attack Plans",
                ["giver"] = "Attack Plans",
                ["otherInfo"] = 
                {
                    ["time"] = 1533847046,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [10] = 
            {
                ["y"] = 0.5501142740,
                ["x"] = 0.1617742926,
                ["name"] = "Captive Crewmembers",
                ["giver"] = "Captain Albert Marck",
                ["otherInfo"] = 
                {
                    ["time"] = 1533851768,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [11] = 
            {
                ["name"] = "Divert and Deliver",
                ["y"] = 0.5126199722,
                ["x"] = 0.2323114276,
                ["preQuest"] = 728,
                ["giver"] = "First Mate Elvira Derre",
                ["otherInfo"] = 
                {
                    ["time"] = 1533853374,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [12] = 
            {
                ["y"] = 0.3264142871,
                ["x"] = 0.2869457006,
                ["name"] = "False Knights",
                ["giver"] = "Sir Graham",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943284,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [13] = 
            {
                ["y"] = 0.3274685740,
                ["x"] = 0.2859799862,
                ["name"] = "False Knights",
                ["giver"] = "Sir Graham",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943891,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [14] = 
            {
                ["y"] = 0.3046999872,
                ["x"] = 0.2963399887,
                ["name"] = "The Flame of Dissent",
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1533943921,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [15] = 
            {
                ["name"] = "Retaking Firebrand Keep",
                ["y"] = 0.3039971292,
                ["x"] = 0.2970771492,
                ["preQuest"] = 736,
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1533944379,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [16] = 
            {
                ["name"] = "Army at the Gates",
                ["y"] = 0.3003971577,
                ["x"] = 0.3258914351,
                ["preQuest"] = 737,
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1533944995,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [17] = 
            {
                ["y"] = 0.2786599994,
                ["x"] = 0.2456285655,
                ["name"] = "Legacy of the Three",
                ["giver"] = "Weather-Beaten Trunk",
                ["otherInfo"] = 
                {
                    ["time"] = 1533956133,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [18] = 
            {
                ["name"] = "Sir Hughes' Fate",
                ["y"] = 0.3008942902,
                ["x"] = 0.3260971308,
                ["preQuest"] = 2576,
                ["giver"] = "Sir Edmund",
                ["otherInfo"] = 
                {
                    ["time"] = 1534024196,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [19] = 
            {
                ["name"] = "Unanswered Questions",
                ["y"] = 0.2973114252,
                ["x"] = 0.3323028684,
                ["preQuest"] = 467,
                ["giver"] = "Duke Nathaniel",
                ["otherInfo"] = 
                {
                    ["time"] = 1534032366,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [20] = 
            {
                ["name"] = "Fire in the Fields",
                ["y"] = 0.4025200009,
                ["x"] = 0.4674942791,
                ["preQuest"] = 1735,
                ["giver"] = "Brother Zacharie",
                ["otherInfo"] = 
                {
                    ["time"] = 1534035243,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [21] = 
            {
                ["y"] = 0.4018571377,
                ["x"] = 0.4949942827,
                ["name"] = "Dreams to Nightmares",
                ["giver"] = "Brother Perry",
                ["otherInfo"] = 
                {
                    ["time"] = 1534040985,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [22] = 
            {
                ["name"] = "The Gate to Quagmire",
                ["y"] = 0.3202342987,
                ["x"] = 0.5474256873,
                ["preQuest"] = 2046,
                ["giver"] = "Master Muzgu",
                ["otherInfo"] = 
                {
                    ["time"] = 1534041930,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [23] = 
            {
                ["name"] = "Azura's Guardian",
                ["y"] = 0.3711885810,
                ["x"] = 0.4313657284,
                ["preQuest"] = 1536,
                ["giver"] = "Sister Safia",
                ["otherInfo"] = 
                {
                    ["time"] = 1534043081,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [24] = 
            {
                ["name"] = "A Prison of Sleep",
                ["y"] = 0.3937314153,
                ["x"] = 0.4481828511,
                ["preQuest"] = 1529,
                ["giver"] = "Master Altien",
                ["otherInfo"] = 
                {
                    ["time"] = 1534110562,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [25] = 
            {
                ["y"] = 0.3914342821,
                ["x"] = 0.4417657256,
                ["name"] = "Injured Spirit Wardens",
                ["giver"] = "Falice Menoit",
                ["otherInfo"] = 
                {
                    ["time"] = 1534110585,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [26] = 
            {
                ["name"] = "Pursuing the Shard",
                ["y"] = 0.4171828628,
                ["x"] = 0.4508599937,
                ["preQuest"] = 1541,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534115232,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [27] = 
            {
                ["name"] = "The Sower Reaps",
                ["y"] = 0.5928171277,
                ["x"] = 0.4334171414,
                ["preQuest"] = 1485,
                ["giver"] = "Arcady Charnis",
                ["otherInfo"] = 
                {
                    ["time"] = 1534127785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [28] = 
            {
                ["y"] = 0.5902314186,
                ["x"] = 0.4062657058,
                ["name"] = "Abominations from Beyond",
                ["giver"] = "Priestess Pietine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534128064,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [29] = 
            {
                ["y"] = 0.6093199849,
                ["x"] = 0.3788971305,
                ["name"] = "Curse of Skulls",
                ["giver"] = "Cursed Skull",
                ["otherInfo"] = 
                {
                    ["time"] = 1534128145,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [30] = 
            {
                ["name"] = "The Signet Ring",
                ["y"] = 0.6113514304,
                ["x"] = 0.3172799945,
                ["preQuest"] = 499,
                ["giver"] = "Hosni at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534132043,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [31] = 
            {
                ["name"] = "Evidence Against Adima",
                ["y"] = 0.5777771473,
                ["x"] = 0.2957200110,
                ["preQuest"] = 2495,
                ["giver"] = "Lady Sirali at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534132624,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [32] = 
            {
                ["name"] = "Saving Hosni",
                ["y"] = 0.5778542757,
                ["x"] = 0.2950657010,
                ["preQuest"] = 2496,
                ["giver"] = "Lady Sirali at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534133322,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [33] = 
            {
                ["name"] = "The Return of the Dream Shard",
                ["y"] = 0.6140800118,
                ["x"] = 0.3099485636,
                ["preQuest"] = 2497,
                ["giver"] = "Hosni at-Tura",
                ["otherInfo"] = 
                {
                    ["time"] = 1534133785,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [34] = 
            {
                ["name"] = "Another Omen",
                ["y"] = 0.4175542891,
                ["x"] = 0.4502457082,
                ["preQuest"] = 1633,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534134224,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [35] = 
            {
                ["y"] = 0.4397457242,
                ["x"] = 0.5220771432,
                ["name"] = "Blood Revenge",
                ["giver"] = "Watch Captain Rama",
                ["otherInfo"] = 
                {
                    ["time"] = 1534134527,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [36] = 
            {
                ["y"] = 0.4184857011,
                ["x"] = 0.5551342964,
                ["name"] = "Rat in a Trap",
                ["giver"] = "Pierre Lanier",
                ["otherInfo"] = 
                {
                    ["time"] = 1534135047,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [37] = 
            {
                ["name"] = "A Means to an End",
                ["y"] = 0.4466885626,
                ["x"] = 0.5594199896,
                ["preQuest"] = 1554,
                ["giver"] = "Watch Commander Kurt",
                ["otherInfo"] = 
                {
                    ["time"] = 1534135245,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [38] = 
            {
                ["name"] = "Revenge Against Rama",
                ["y"] = 0.4467457235,
                ["x"] = 0.5594199896,
                ["preQuest"] = 1568,
                ["giver"] = "Watch Captain Ernard",
                ["otherInfo"] = 
                {
                    ["time"] = 1534136855,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
            [39] = 
            {
                ["name"] = "Plowshares to Swords",
                ["y"] = 0.5452857018,
                ["x"] = 0.7167114019,
                ["preQuest"] = 1384,
                ["giver"] = "Dro-Dara",
                ["otherInfo"] = 
                {
                    ["time"] = 1534284908,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [40] = 
            {
                ["y"] = 0.4731028676,
                ["x"] = 0.8102228642,
                ["name"] = "Azura's Relics",
                ["giver"] = "Sister Tabakah",
                ["otherInfo"] = 
                {
                    ["time"] = 1534285563,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [41] = 
            {
                ["name"] = "A Predator's Heart",
                ["y"] = 0.5479228497,
                ["x"] = 0.7230571508,
                ["preQuest"] = 2536,
                ["giver"] = "Knarstygg",
                ["otherInfo"] = 
                {
                    ["time"] = 1534289013,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [42] = 
            {
                ["y"] = 0.4852257073,
                ["x"] = 0.7429599762,
                ["name"] = "General Godrun's Orders",
                ["giver"] = "General Godrun",
                ["otherInfo"] = 
                {
                    ["time"] = 1534292650,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [43] = 
            {
                ["y"] = 0.4715114236,
                ["x"] = 0.7367143035,
                ["name"] = "Ogre Teeth",
                ["giver"] = "Captain Dugakh",
                ["otherInfo"] = 
                {
                    ["time"] = 1534292860,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [44] = 
            {
                ["name"] = "Ending the Ogre Threat",
                ["y"] = 0.4308257103,
                ["x"] = 0.7524114251,
                ["preQuest"] = 1437,
                ["giver"] = "General Godrun",
                ["otherInfo"] = 
                {
                    ["time"] = 1534293441,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [45] = 
            {
                ["name"] = "Godrun's Dream",
                ["y"] = 0.4839485586,
                ["x"] = 0.7416971326,
                ["preQuest"] = 1346,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534304400,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [46] = 
            {
                ["name"] = "Azura's Aid",
                ["y"] = 0.4835257232,
                ["x"] = 0.7431628704,
                ["preQuest"] = 3637,
                ["giver"] = "Abbot Durak",
                ["otherInfo"] = 
                {
                    ["time"] = 1534304982,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [47] = 
            {
                ["y"] = 0.4296885729,
                ["x"] = 0.6858485937,
                ["name"] = "A Look in the Mirror",
                ["giver"] = "Mathias Raiment",
                ["otherInfo"] = 
                {
                    ["time"] = 1534365486,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [48] = 
            {
                ["name"] = "Gift from a Suitor",
                ["y"] = 0.4326257110,
                ["x"] = 0.6523114443,
                ["preQuest"] = 614,
                ["giver"] = "Countess Ilise Manteau",
                ["otherInfo"] = 
                {
                    ["time"] = 1534365750,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [49] = 
            {
                ["y"] = 0.4065999985,
                ["x"] = 0.6221686006,
                ["name"] = "The Perfect Burial",
                ["giver"] = "Michel Helomaine",
                ["otherInfo"] = 
                {
                    ["time"] = 1534368712,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [50] = 
            {
                ["name"] = "King Aphren's Sword",
                ["y"] = 0.5167885423,
                ["x"] = 0.6690571308,
                ["preQuest"] = 2538,
                ["giver"] = "Blaise Pamarc",
                ["otherInfo"] = 
                {
                    ["time"] = 1534370713,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [51] = 
            {
                ["y"] = 0.6117914319,
                ["x"] = 0.4425742924,
                ["name"] = "A Ransom for Miranda",
                ["giver"] = "Serge Arcole",
                ["otherInfo"] = 
                {
                    ["time"] = 1534395263,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
            [52] = 
            {
                ["name"] = "A Woman Wronged",
                ["y"] = 0.6594685912,
                ["x"] = 0.4409771562,
                ["preQuest"] = 2451,
                ["giver"] = "Serge Arcole",
                ["otherInfo"] = 
                {
                    ["time"] = 1534396158,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/badmansstart_base"] = 
        {
            [1] = 
            {
                ["name"] = "Season of Harvest",
                ["y"] = 0.6460055113,
                ["x"] = 0.4435261786,
                ["preQuest"] = 4767,
                ["giver"] = "Curator Nicholas",
                ["otherInfo"] = 
                {
                    ["time"] = 1533693555,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
        ["stormhaven/norvulkruins_base"] = 
        {
            [1] = 
            {
                ["y"] = 0.8044354916,
                ["x"] = 0.5907257795,
                ["name"] = "Word from the Dead",
                ["giver"] = "Matys Derone",
                ["otherInfo"] = 
                {
                    ["time"] = 1534368364,
                    ["api"] = 100024,
                    ["lang"] = "en",
                },
            },
        },
        ["glenumbra/aldcroft_base"] = 
        {
            [1] = 
            {
                ["name"] = "Pride of the Lion Guard",
                ["y"] = 0.3413914144,
                ["x"] = 0.5562694669,
                ["preQuest"] = 3004,
                ["giver"] = "Captain Vistra",
                ["otherInfo"] = 
                {
                    ["time"] = 1533669833,
                    ["api"] = 100023,
                    ["lang"] = "en",
                },
            },
        },
    },
    ["questInfo"] = 
    {
        [1536] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5377] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2564] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1541] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2566] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2567] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3337] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [523] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5388] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5389] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3343] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5392] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5394] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5395] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5396] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5400] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4379] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5406] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5407] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [1568] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5409] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5412] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5413] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4902] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4903] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5416] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5417] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [5418] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4401] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4403] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3637] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1591] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1339] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1341] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4926] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [575] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [4928] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4929] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 1,
            },
            ["repeatType"] = 0,
        },
        [1346] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4934] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4937] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6218] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [1615] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4944] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4945] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [6227] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6228] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5973] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [3414] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3416] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4443] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5983] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [1633] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [1637] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [614] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1639] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1384] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4202] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3440] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3192] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4473] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2436] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6022] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [1678] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2450] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2451] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5012] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5014] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1687] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5020] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1437] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5022] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4767] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5027] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4516] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4519] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1709] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4965] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2481] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4927] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4531] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2046] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4533] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2561] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4535] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3379] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [3001] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2578] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3003] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3004] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [521] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2494] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2495] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2496] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2497] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4857] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3011] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2552] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3509] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5171] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1735] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2504] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3017] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5976] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 3,
            },
            ["repeatType"] = 0,
        },
        [3019] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3020] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1485] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [4952] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3023] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [499] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [465] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [6130] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 7,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [467] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 9,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [1554] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4565] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [6102] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5368] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [728] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2068] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2576] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3035] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3412] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4529] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3784] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3039] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [736] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [737] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4834] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2538] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4901] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [1383] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3302] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3285] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2536] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2537] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3050] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4843] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4844] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3783] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2569] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4335] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4080] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3286] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [3314] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [3059] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2558] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2549] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [2550] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1527] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4088] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [1529] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4858] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [5021] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [2556] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
        [4472] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 1,
            },
            ["repeatType"] = 0,
        },
        [5374] = 
        {
            ["rewardTypes"] = 
            {
                [1] = 7,
                [2] = 5,
                [3] = 1,
            },
            ["repeatType"] = 0,
        },
        [2047] = 
        {
            ["rewardTypes"] = 
            {
                [2] = 1,
                [1] = 7,
            },
            ["repeatType"] = 0,
        },
    },
    ["startTime"] = 1533505942,
}
