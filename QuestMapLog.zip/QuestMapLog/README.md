How to
------

1. In the chat window, enter the command `/qmlog` to collect the data, this also reloads the UI!

2. Find the log file "Elder Scrolls Online\XXX\SavedVariables\QuestMapLog.lua"  
   (XXX = "live", "liveeu" or "pts")

3. Send me a PM with a link to the file (e.g. upload it to Dropbox, the file probably will be too long for a PM)

____
[CaptainBlagbird](http://www.esoui.com/forums/member.php?userid=13972)