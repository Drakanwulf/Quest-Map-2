--[[

Quest Map Log
	by Drakanwulf
	
	Improved Quest Map Logging program.
	
	WARNING!!!  Not working yet
	
--]]

-- Defines an empty local saved variables table
local addon = {}

-- Defaults
local defaults = {
	display = "Quest Map Log 2",
	name = "QMLog",
	version = "1.2.0",
}

local player = {			-- Current player information table
	name = "",				-- A player name change resets the completed quests table
	classId = 0,			-- Class identifier
	mapId = 0,				-- The player's current map identifier
}

-- Generic infomation table definition used within player, map, zone, subzone, and quest tables.
local info = {
	globalX = 0,
	globalY = 0,
	name = "",
	mapType = MAPTYPE_NONE,
}

local function GetData()
	-- The numeric values in these two fields are NOT the same!
    local qId				-- completed quests table identifier (key)
	local i					-- completed quests table index

    -- There currently are < 6000 quests, but some can be completed multiple times.
    -- 10000 should be more than enough to get all completed quests and still avoid an endless loop.
    for i=0, 10000 do
        -- Get next completed quest.
        qId = GetNextCompletedQuestId(qId)

		--  If it was the last, break the loop
		if qId == nil then break end

		-- Get all the information that we can about this quest, its maps and zones, and its location
        QML.quests[qId] = {}
        QML.quests[qId].questName, QML.quests[qId].questType = GetCompletedQuestInfo(qId)
        QML.quests[qId].zoneName, QML.quests[qId].objectiveName, QML.quests[qId].zoneIndex, QML.quests[qId].poiIndex = GetCompletedQuestLocationInfo(qId)
--		QML.quests[qId].mapName = {},		-- A quest giver's map, zone, or subzone identification and location info indexed by a completed quest Id
	end
	
    -- Reload ui so the saved variables file gets written
    ReloadUI()
end

-- Event handler function for EVENT_PLAYER_ACTIVATED
local function OnPlayerActivated(eventCode)
    EVENT_MANAGER:UnregisterForEvent(AddonName, EVENT_PLAYER_ACTIVATED)

    -- Get the current player name to determine whether or not to keep or clear the quests information table
	local sv = GetDisplayName( GetUnitName("player") )

	if( sv != QML.current.player ) then
		QML.quests = {}						-- Reset the completed quests information table
	end

	-- Update the current player information
	QML.current.player = sv
	QML.current.mapName = GetMapName()
	QML.current.mapType = GetMapType()
	
	-- Load, or continue loading, the completed quests table
    SLASH_COMMANDS["/qmlog"] = GetData
end

local function OnAddonLoaded( event, addon )
	-- Make sure it's our event
	if( addon ~= addon.name ) then return end;
	
	--Process the event
	EVENT_MANAGER:UnregisterForEvent(addon, EVENT_ADDON_LOADED)
	
    -- Set up SavedVariables table
    QML = ZO_SavedVars:New( "QMLogVars", 1, nil, QML.current )
    
	EVENT_MANAGER:RegisterForEvent(AddonName, EVENT_PLAYER_ACTIVATED, OnPlayerActivated)
end

EVENT_MANAGER:RegisterForEvent(addon, EVENT_ADDON_LOADED, OnAddonLoaded )

-- Transfer the local saved variables to its global variable
QML2 = addon

--[[
    GetMapContentType()
        Returns: number MapContentType mapContentType 

    GetMapFilterType()
        Returns: number MapFilterType mapFilterType 

    GetNumMapLocations()
        Returns: number numMapLocations

	GetMapPlayerPosition(string unitTag)
		Returns: number normalizedX, number normalizedZ, number heading 
	
	     Search on ESOUI Source Code GetCurrentMapIndex()
        Returns: number:nilable index 

    Search on ESOUI Source Code GetMapIndexByZoneId(number zoneId)
        Returns: number:nilable index 

    Search on ESOUI Source Code GetCyrodiilMapIndex()
        Returns: number:nilable index 

    Search on ESOUI Source Code GetImperialCityMapIndex()
        Returns: number:nilable index 

    Search on ESOUI Source Code GetCurrentMapZoneIndex()
        Returns: number zoneIndex 

    Search on ESOUI Source Code GetZoneNameByIndex(number zoneIndex)
        Returns: string zoneName 

    Search on ESOUI Source Code GetMapNameByIndex(number mapIndex)
        Returns: string mapName 

    Search on ESOUI Source Code GetNumMaps()
        Returns: number numMaps
		
MAPTYPE_NONE		0
MAPTYPE_SUBZONE		1
MAPTYPE_ZONE		2
MAPTYPE_WORLD		3
MAPTYPE_ALLIANCE	4
MAPTYPE_COSMIC		5

--]]	
