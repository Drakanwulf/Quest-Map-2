--[[
	QuestMap2 Map Tables Library
		by Drakanwulf and Hawkeye1889

	This library creates and initializes and/or retrieves and updates QuestMap2 Map tables and data for all accounts and
	characters on any one of the ESO megaservers.
--]]

local LIB_NAME = "LibQM2Maps"
-- If LibStub has not been loaded, it is a fatal error, so return a message describing the reason
if not LibStub then
    error( string.format( "[%s] Cannot load this Library without LibStub", LIB_NAME ))
end

-- If LibStub:NewLibrary() returns a nil pointer, the latest Library is already loaded and no upgrades are necessary
local lib = LibStub:NewLibrary( LIB_NAME, 2 )
if not lib then
	return
end

--[[
	Either the Library was NOT loaded before or it must be updated!  We start by building local tables of variables
	and tables to be saved and retrieved from the saved variables table(s) each time this Library is loaded.
--]]

-- Make a local reference to LibGPS2 for speed
local GPS = LibStub:GetLibrary( "LibGPS2", SILENT )
if not GPS then
    error( string.format( "[%s] Cannot run without LibGPS2", LIB_NAME ))
end
 
-- About this Library...
local lib = {}
lib = {
	display = "QuestMap2 Map Tables Library",
	name = LIB_NAME,
	version = "2.0.1",
	release = 2,
}

--[[
	Functions defined within this .lua code are recorded and compiled but are not executed until they are invoked by the
	"OnAddonLoaded" event handler or by one of the public API (eg. "lib:...) functions
--]]

--[[
	Create empty Maps tables. The LoadMapTables() function populates these tables the first time this library is run or 
	whenever the number of maps in the world changes.
--]]
local coordsByIndex = {				-- Map x,y coordinates (topleft corner) by mapIndex
	globalX = 0,
	globalY = 0,
}
local infoByIndex = {				-- Map information by mapIndex
	mapType = 0,
	content = 0,
	description = "",
}
local namesByIndex = {				-- Map names by mapIndex
	mapName = "",
}
local mapToZoneByIndex = {			-- Map Index to Zone Identifier Cross-Reference by mapIndex
	zoneId = 0,
}
	
--[[
	Local functions are private and hidden. They are available only to the public API or to other library functions
--]]
local tmax = GetNumMaps()							-- Get the number of maps in the world 

local function IsValidIndex( mdx: number )			-- Validate the map tables index
	return( mdx and mdx > 0 and mdx <= tmax )
end

local function LoadMapTables()
	local x, y										-- The local x,y coords for the top left corner of any map or zone are 0,0
	local name, mtype, ctype, zid, desc				-- Information about each map. See GetMapInfo()
	local mdx										-- mdx := mapIndex
	GPS:PushCurrentMap()							-- Save wherever we are in the world
	-- Loop through all the maps
	for mdx = 1, tmax do
 		-- Get the general information for each map
		name, mtype, ctype, zid, desc = GetMapInfo( mdx )
		-- Load the Map Names table
		namesByIndex[mdx] = { mapName = name }
		-- Load the map Information table
		infoByIndex[mdx] = { mapType = mtype, content = ctype, description = desc }
		-- If a map has a valid zoneId, add it to the Map to Zone Cross-Reference table
		if zid and zid > 0 then
			mapToZoneByIndex[mdx] = { zoneId = zid }
		end
		-- Load the global x,y coordinates table
		x = 0
		y = 0
		if not GPS:IsMeasuring() then			
			SetMapToMapListIndex( mdx )				-- Change maps to the map for this mdx
			x,y = GPS:LocalToGlobal( 0,0 )			-- Get the global x,y coordinates
		end
		coordsByIndex[mdx] = { globalX = x, globalY = y }
	end
	GPS:PopCurrentMap()								-- Put us back to wherever we were in the world
end

local function UpdateMapTables()
	local x, y										-- The local x,y coords for the top left corner of any map or zone are 0,0
	local name, mtype, ctype, zid, desc				-- Information about each map. See GetMapInfo()
	local mdx										-- mdx := mapIndex
	GPS:PushCurrentMap()							-- Save wherever we are in the world
	-- Loop through all the maps
	for mdx = 1, tmax do
 		if not namesByIndex[mdx]
		or not infoByIndex[mdx]
		or not coordsByIndex[mdx] then
			-- Get the general information for each map
			name, mtype, ctype, zid, desc = GetMapInfo( mdx )
			-- Load the Map Names table
			namesByIndex[mdx] = { mapName = name }
			-- Load the map Information table. mapType should be 3 or higher
			infoByIndex[mdx] = { mapType = mtype, content = ctype, description = desc }
			-- If a map has a valid zoneId, add it to the Map to Zone Cross-Reference table
			if zid and zid > 0 then
				mapToZoneByIndex[mdx] = { zoneId = zid }
			end
			-- Load the global x,y coordinates table
			x = 0
			y = 0
			if not GPS:IsMeasuring() then			
				SetMapToMapListIndex( mdx )				-- Change maps to the map for this mdx
				x,y = GPS:LocalToGlobal( 0,0 )			-- Get the global x,y coordinates
			end
			coordsByIndex[mdx] = { globalX = x, globalY = y }
		end
	end
	GPS:PopCurrentMap()								-- Put us back to wherever we were
end

 --[[
	Although the content of the saved variables files for this Library is unique to each megaserver (eg. EU_, NA_, or PTS_),
	the content is global to all accounts and players on a specific megaserver.
--]]
local function OnAddonLoaded( event, name )
	-- Only process our events
	if name ~= lib.name then
		return
	end
	EVENT_MANAGER:UnregisterForEvent( lib.name, EVENT_ADD_ON_LOADED )

	-- Create megaserver constants and a saved variables names table
	local SERVER_EU = "EU Megaserver" 
	local SERVER_NA = "NA Megaserver"
	local SERVER_PTS = "PTS"

	local SERVER_TO_SAVED_VAR_NAME = {
		[SERVER_EU] = "EU_SavedVars",
		[SERVER_NA] = "NA_SavedVars",
		[SERVER_PTS] = "PTS_SavedVars",
	}	 	
	-- If we cannot map the megaserver name, the default use the PTS saved variables table name
	local savedVarsName = SERVER_TO_SAVED_VAR_NAME[GetWorldName()] or SERVER_TO_SAVED_VAR_NAME[SERVER_PTS]
	
	-- Create an empty saved variables table for the ZO_... saved variables functions
	local defaults = {
		-- Saved Variables version numbers let us upgrade saved variables rather than having to wipe them 
		version = 1,
		-- An APIVersion change means that ESO has released an update so the Maps tables should be reloaded
		apiVersion = 0,
		coords = {},
		info = {},
		names = {},
		xrefs = {},
	}

	-- Load the saved variables table for this megaserver.  Load the defaults if the table cannot be found
	sv = _G[savedVarsName] or defaults 
	-- If the APIVersion has changed, initalize and load the Maps reference tables
	local currentApi = GetAPIVersion()
	if sv.apiVersion ~= currentApi then
		sv = defaults					-- Initialize the saved variables table
		sv.apiVersion = currentApi		-- Update the API version (eg. 100025)
		coordsByIndex = {}				-- Map x,y coordinates (topleft corner) by mapIndex
		infoByIndex = {}				-- Map information by mapIndex
		namesByIndex = {}				-- Map names by mapIndex.
		mapToZoneByIndex = {}			-- Map Index to Zone Identifier Cross-Reference by mapIndex
		LoadMapTables()
	-- Otherwise, update the Maps reference tables to ensure that all maps and data are present
	else
		coordsByIndex = sv.coords
		infoByIndex = sv.info
		namesByIndex = sv.names
		mapToZoneByIndex = sv.xrefs
		UpdateMapTables()
	end
	
	-- Save the loaded or updated Maps reference files
	sv.coords = coordsByIndex
	sv.info = infoByIndex
	sv.names = namesByIndex
	sv.xrefs = mapToZoneByIndex

	_G[savedVarsName] = sv
end

--[[
	API functions are the public interfaces to this library
--]]
function lib:GetMapInfo( mdx: number )
	-- Validate the mapIndex
	if not IsValidIndex( mdx ) then
		return nil
	end

	return infoByIndex[mdx].mapType or nil, infoByIndex[mdx].content or nil, infoByIndex[mdx].description or nil
end

function lib:GetMapName( mdx: number )
	-- Validate the mapIndex
	if not IsValidIndex( mdx ) then
		return nil
	end

	return namesByIndex[mdx].mapName
end

function lib:GetMapTopLeft( mdx: number )
	-- Validate the mapIndex
	if not IsValidIndex( mdx ) then
		return nil
	end

	return coordsByIndex[mdx].globalX, coordsByIndex[mdx].globalY
end

function lib:GetMapZoneId( mdx: number )
	-- Validate the mapIndex
	if not IsValidIndex( mdx ) then
		return nil
	end

	-- Return the Map to Zone Cross-Reference
	return mapToZoneByIndex[mdx].zoneId
end
--[[
	End of the Maps Library tables and function definitions
--]]

--[[
	The Library code stalls here and waits for ESO to trigger an EVENT_ADD_ON_LOADED to restart the code at the
	"OnAddonLoaded" function
--]]
EVENT_MANAGER:RegisterForEvent( lib.name, EVENT_ADD_ON_LOADED, OnAddonLoaded )
