--[[

Quest Map 2
	by Drakanwulf & Hawkeye1889

	Sets of quest giver pin icons for both completed and uncompleted quests
	
--]]

QM2.iconSets = {
    QM2 = { "icons/pinQuestUncompleted.dds", "icons/pinQuestCompleted.dds" },
    ESO = { "/esoui/art/floatingmarkers/quest_available_icon.dds", "/esoui/art/icons/achievements_index/icon_quests_down.dds" },
}