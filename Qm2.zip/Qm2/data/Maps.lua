--[[

Quest Map 2
	by Drakanwulf & Hawkeye1889

General information about the Maps tables:
	Each Map Index (eg. mapIndex) is unique to a specific map.  In other words, each mapIndex is assigned to a specific map
	whose center is located at specific x,y coordinates within its world.

	Each Map Name (eg. mapName) is unique and it identifies a specific map.  In other words, each mapName can be translated
	into any of the languages this addon supports via its $LANG files.

	When you lookup a map's name or a map's global location information by mapIndex, you get the unique name assigned to
	that map or you get the unique, global x,y coordinates for that map.

There are three Maps Cross-Reference Tables
	Map Coordinates (Global Map Location Information} by Map Index
		The LibGPS2 global x,y coordinates for all of the known locations in all of the known maps in the entire game are 
		recorded here along with their equivalent zoneId's.  All maps have equivalent zones; however, subzones are not known
		to have equivalent maps.  Magical mathematics known only to Votan are used to convert local (to a specific map) x,y
		coordinates to their global (World Map) counterparts and back again
		(See the LibGPS2 "LocalToGlobal" and "GlobalToLocal" API documentation for more information)
	Map Information by Map Index
		Names, types, content types, locations, and other general information specific to a map
	Map Hierarchy by Map Index
		The overall parent/child relationships among all the maps.  All maps have a parent except for the topmost (eg. World)
		maps and all maps have one or more children except for the bottommost (eg. floor) maps.  Most maps have equivalent
		Zones which may be larger or smaller than their Map counterparts

API and Private functions are used to Add..., Get..., Set..., Update..., and Validate... table information
	API functions are public.  Use of the "LibQM2:" prefix exports these functions to the QM2 globals table as ESO loads the
	addon's compile units
	Private functions are not for general use.  These functions are embedded within their respective tables so they cannot be
	seen outside of their respective compile units
	(See the QM2.txt and Init.lua files for more information)

--]]

-- Abort if a LibStub library program has not been loaded into the global (_G) variables
local addon = {
	display	= "QM2 Map Tables Library",
	name = "LibQM2Map",
	version = 2, 
}

-- Use LibStub to load this addon and record its version as a library
if ((not LibStub) or LibStub == nil) then
	error( string.format( "[%s] Cannot load any Libraries without LibStub", addon.display ))
end

-- A nil return means that LibStub had already loaded the addon library and that no version upgrade was necessary
local lib = LibStub:NewLibrary( addon.name, addon.version )
if not lib then
    return
end

--[[
	Load the Map tables library code
--]]

local function lib:Init()

-- Load the Quest Map 2 table library addon into LibStub
local MAP = LibStub( "LibQM2Map" ),
if not MAP then
	error( string.format( "[%s] Cannot run without LibQM2Map", addon.display ))
end

if not addon.libraries then
	addon.libraries = {}
end

addon.libraries[map] = MAP

	local libraries = {
		gps = GPS,
		lam = LAM,
		lmw = LMW,
		map = MAP,
		zone = ZONE,
		loc = LOC,
	}

	-- Save our Library address pointers in the global table
	self.libs = libraries

	-- Get the number of maps in the world 
	local tmax = GetNumMaps()

	-- Create new tables if they don't already exist
	if not names or names = {} then
		for i = 1, tmax do
			names[i] = GetMapNameByIndex( i )
		end
	end

	if not locs then
		local locs = {}
	end
	
	for i = 1, tmax do
		local x, y, zoneId, 
		if not coords[i] or coords[i] = {} then 			--This entry is empty
			GetMapInfo(
	end

	
	if not info then		
		local info = {}
	end
	if not tree then		
		local tree = {}
	end

	-- Fill the tables
	for i = 1, tmax do
		local x, y, zoneId, 
		if not coords[i] or coords[i] = {} then 			--This entry is empty
			GetMapInfo(
	end

end
	

-- Maps coordinates entry content. Defaults are set to invalid values
local locInfo = {
	x = 0,			-- These are the x,y coordinates for where this map is located in the World
	y = 0,
}

local locs = {}

--[[
Map type constants
* MAPTYPE_NONE		0
* MAPTYPE_SUBZONE	1
* MAPTYPE_ZONE		2
* MAPTYPE_WORLD		3
* MAPTYPE_ALLIANCE	4
* MAPTYPE_COSMIC	5

MapContentType
* MAP_CONTENT_AVA
* MAP_CONTENT_BATTLEGROUND
* MAP_CONTENT_DUNGEON
* MAP_CONTENT_NONE

SetMapResultCode
* SET_MAP_RESULT_CURRENT_MAP_UNCHANGED
* SET_MAP_RESULT_FAILED
* SET_MAP_RESULT_MAP_CHANGED

Map API calls, params, and returns
* GetNumMapLocations()
** _Returns:_ *integer* _numMapLocations_
* GetNumMaps()
** _Returns:_ *integer* _numMaps_

* GetMapInfo(*luaindex* _index_)
** _Returns:_ *string* _name_, *[UIMapType|#UIMapType]* _mapType_, *[MapContentType|#MapContentType]* _mapContentType_, *integer* _zoneId_, *string* _description_
* GetMapPing(*string* _unitTag_)
** _Returns:_ *number* _normalizedX_, *number* _normalizedY_
* GetMapType()
** _Returns:_ *[UIMapType|#UIMapType]* _mapType_

* GetMapPlayerPosition(*string* _unitTag_)
** _Returns:_ *number* _normalizedX_, *number* _normalizedZ_, *number* _heading_, *bool* _isShownInCurrentMap_
* GetMapPlayerWaypoint()
** _Returns:_ *number* _normalizedX_, *number* _normalizedY_
* GetMapRallyPoint()
** _Returns:_ *number* _normalizedX_, *number* _normalizedY_

* GetCurrentMapIndex()
** _Returns:_ *luaindex:nilable* _index_
* GetMapIndexByZoneId(*integer* _zoneId_)
** _Returns:_ *luaindex:nilable* _index_

* GetCurrentMapZoneIndex()
** _Returns:_ *luaindex* _zoneIndex_
* GetZoneNameByIndex(*luaindex* _zoneIndex_)
** _Returns:_ *string* _zoneName_
* GetMapNameByIndex(*luaindex* _mapIndex_)
** _Returns:_ *string* _mapName_

* GetMapParentCategories(*luaindex* _index_)
** _Uses variable returns..._
** _Returns:_ *string* _categoryName_, *luaindex* _categoryIndex_

* GetMapNumTiles()
** _Returns:_ *integer* _numHorizontalTiles_, *integer* _numVerticalTiles_
* GetMapTileTexture(*luaindex* _tileIndex_)
** _Returns:_ *string* _tileFilename_

* GetMapName()
** _Returns:_ *string* _mapName_
* GetMapType()
** _Returns:_ *[UIMapType|#UIMapType]* _mapType_
* GetMapContentType()
** _Returns:_ *[MapContentType|#MapContentType]* _mapContentType_

* GetMapCustomMaxZoom()
** _Returns:_ *number:nilable* _customMaxZoom_

* GetMapFilterType()
** _Returns:_ *[MapFilterType|#MapFilterType]* _mapFilterType_

* GetMapLocationIcon(*luaindex* _locationIndex_)
** _Returns:_ *string* _icon_, *number* _normalizedX_, *number* _normalizedZ_

* GetMapLocationTooltipHeader(*luaindex* _locationIndex_)
** _Returns:_ *string* _header_
* GetNumMapLocationTooltipLines(*luaindex* _locationIndex_)
** _Returns:_ *integer* _numLines_
* GetMapLocationTooltipLineInfo(*luaindex* _locationIndex_, *luaindex* _tooltipLineIndex_)
** _Returns:_ *textureName* _icon_, *string* _name_, *integer* _grouping_, *string* _categoryName_

* GetMapFloorInfo()
** _Returns:_ *luaindex* _currentFloor_, *integer* _numFloors_

* SetMapFloor(*luaindex* _desiredFloorIndex_)
** _Returns:_ *[SetMapResultCode|#SetMapResultCode]* _setMapResult_
* SetMapToMapListIndex(*luaindex* _index_)
** _Returns:_ *[SetMapResultCode|#SetMapResultCode]* _setMapResult_
* SetMapToPlayerLocation()
** _Returns:_ *[SetMapResultCode|#SetMapResultCode]* _setMapResult_

--]]
