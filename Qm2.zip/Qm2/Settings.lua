--[[

Quest Map
by CaptainBlagbird
https://github.com/CaptainBlagbird

--]]

-- Local variables
local iconUncollectedTexture, iconCollectedTexture
local iconSets = {}

-- Load the quest giver pin icons from the reference file and transfer their keys and icons to the table
for k,v in pairs( QM2.iconSets ) do
	table.insert( iconSets, k )
end

-- Build the LAM settings panel
local panelData = {
    type = "panel",
    name = QM2.name,
    display = "|c70C0DE"..QM2.display.."|r",
    author = "|c70C0DE Drakanwulf & Hawkeye1889|r",
    version = QM2.version,
    slashCommand = "/QM2", --(optional) will register a keybind to open to this panel
    registerForRefresh = true,  --boolean (optional) (will refresh all options controls when a setting is changed and when the panel is shown)
    registerForDefaults = true, --boolean (optional) (will set all options controls back to default values)
	-- And reset the pin filters. The only things left in the saved variables will be the hidden quests (QM2.settings.hiddenQuests)
    ResetFunc = function()
        QM2.settings.pinFilters = QM2.account.pinFilters
        QM2:RefreshPinFilters()
    end,    --function (optional) if registerForDefaults is true, this custom function will run after settings are reset to defaults
}

-- Changes the default Icon display level setting
--local function ChangePinLevel(value)
--    QM2.settings.pinLevel = value
--    QM2:InitPins()
--end

-- Changes the default Icon pins, their size
local optionsTable = {
    {
        type = "dropdown",
        name = GetString(QUESTMAP_MENU_ICON_SET),
        choices = iconSets,
		getFunc = function() return QM2.settings.iconSet end,
		setFunc = function(value)
				QM2.settings.iconSet = value
				QM2:RefreshPinLayout()
				iconUncollectedTexture:SetTexture(QM2.iconSets[QM2.settings.iconSet][1])
				iconCollectedTexture:SetTexture(QM2.iconSets[QM2.settings.iconSet][2])
			end,
        default = QM2.savedVarsDefault.iconSet,
        width = "full",
    },
    {
        type = "slider",
        name = GetString(QUESTMAP_MENU_PIN_SIZE),
        tooltip = GetString(QUESTMAP_MENU_PIN_SIZE_TT),
        min = 5,
        max = 70,
        step = 1,
        getFunc = function() return QM2.settings.pinSize end,
        setFunc = function(value)
                QM2.settings.pinSize = value
                QM2:RefreshPinLayout()
            end,
        width = "full",
        default = QM2.savedVarsDefault.pinSize,
    },
    {
        type = "slider",
        name = GetString(QUESTMAP_MENU_PIN_LVL),
        tooltip = GetString(QUESTMAP_MENU_PIN_LVL_TT),
        min = 10,
        max = 200,
        step = 1,
        getFunc = function() return QM2.settings.pinLevel end,
        setFunc = function(value)
                QM2.settings.pinLevel = value
                QM2:RefreshPinLayout()
            end,
        width = "full",
        default = QM2.savedVarsDefault.pinLevel,
    },
    {
        type = "checkbox",
        name = GetString(QUESTMAP_MENU_DISP_MSG),
        tooltip = GetString(QUESTMAP_MENU_DISP_MSG_TT),
        getFunc = function() return QM2.settings.displayClickMsg end,
        setFunc = function(value) QM2.settings.displayClickMsg = value end,
        default = QM2.savedVarsDefault.displayClickMsg,
        width = "full",
    },
    {
        type = "header",
        name = "",
        width = "full",
    },
    {
        type = "description",
        title = GetString(QUESTMAP_MENU_HIDDEN_QUESTS_T),
        text = GetString(QUESTMAP_MENU_HIDDEN_QUESTS_1),
        width = "full",
    },
    {
        type = "description",
        title = "",
        text = GetString(QUESTMAP_MENU_HIDDEN_QUESTS_2),
        width = "full",
    },
    {
        type = "description",
        title = "",
        text = GetString(QUESTMAP_MENU_HIDDEN_QUESTS_B),
        width = "half",
    },
    {
        type = "button",
        name = GetString(QUESTMAP_MENU_RESET_HIDDEN),
        tooltip = GetString(QUESTMAP_MENU_RESET_HIDDEN_TT),
        func = function()
                QM2.settings.hiddenQuests = {}
                QM2:RefreshPinLayout()
            end,
        width = "half",
        warning = GetString(QUESTMAP_MENU_RESET_HIDDEN_W),
    },
    {
        type = "description",
        title = "",
        text = GetString(QUESTMAP_MENU_RESET_NOTE),
        width = "full",
    },
}

-- Create texture on first load of the Better Rally LAM panel
local function CreateTexture(panel)
    if panel == WINDOW_MANAGER:GetControlByName(QM2.idName, "_Options") then
        -- Create texture control
        iconUncollectedTexture = WINDOW_MANAGER:CreateControl(QM2.idName.."_Options_UncollectedTexture", panel.controlsToRefresh[1], CT_TEXTURE)
        iconUncollectedTexture:SetAnchor(CENTER, panel.controlsToRefresh[1].dropdown:GetControl(), LEFT, -60, 0)
        iconUncollectedTexture:SetTexture(QM2.iconSets[QM2.settings.iconSet][1])
        iconUncollectedTexture:SetDimensions(28, 28)
        iconCollectedTexture = WINDOW_MANAGER:CreateControl(QM2.idName.."_Options_CollectedTexture", panel.controlsToRefresh[1], CT_TEXTURE)
        iconCollectedTexture:SetAnchor(CENTER, panel.controlsToRefresh[1].dropdown:GetControl(), LEFT, -30, 0)
        iconCollectedTexture:SetTexture(QM2.iconSets[QM2.settings.iconSet][2])
        iconCollectedTexture:SetDimensions(28, 28)
        
        CALLBACK_MANAGER:UnregisterCallback("LAM-PanelControlsCreated", CreateTexture)
    end
end

CALLBACK_MANAGER:RegisterCallback("LAM-PanelControlsCreated", CreateTexture)

-- Wait on player to ensure that all addons and data modules are loaded
local function OnPlayerActivated(event)
    if LibStub ~= nil then
        local LAM = LibStub("LibAddonMenu-2.0")

        LAM:RegisterAddonPanel(QM2.idName.."_Options", panelData)
        LAM:RegisterOptionControls(QM2.idName.."_Options", optionsTable)
    end

    EVENT_MANAGER:UnregisterForEvent( QM2.idName.."_Options", EVENT_PLAYER_ACTIVATED )
end
EVENT_MANAGER:RegisterForEvent( QM2.idName.."_Options", EVENT_PLAYER_ACTIVATED, OnPlayerActivated )

--[[

Pin types for Quest states (levels?)

* MAP_PIN_TYPE_QUEST_COMPLETE
* MAP_PIN_TYPE_QUEST_CONDITION
* MAP_PIN_TYPE_QUEST_ENDING
* MAP_PIN_TYPE_QUEST_GIVE_ITEM
* MAP_PIN_TYPE_QUEST_INTERACT
* MAP_PIN_TYPE_QUEST_OFFER
* MAP_PIN_TYPE_QUEST_OFFER_REPEATABLE
* MAP_PIN_TYPE_QUEST_OPTIONAL_CONDITION
* MAP_PIN_TYPE_QUEST_REPEATABLE_CONDITION
* MAP_PIN_TYPE_QUEST_REPEATABLE_ENDING
* MAP_PIN_TYPE_QUEST_REPEATABLE_OPTIONAL_CONDITION
* MAP_PIN_TYPE_QUEST_TALK_TO

--]]
