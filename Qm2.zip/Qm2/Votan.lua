--[[
	Votan's example program to display pins on a map, subzone, or zone.
		This is a minimal code for map pins:
		There are a fictional table of your pins and a function to get the coords from it, that you need to write, before this
		example will work.

--]]

local gps = LibStub("LibGPS2")
 
local pinTypeId = nil
local pinType = "YourUniqueNameofPinType"
 
local layout = {
	level = 40,
	size = 25,
	insetX = 0,
	insetY = 0,
	texture = "esoui/art/buttons/pointsplus_highlight.dds",
--  tint = function( pin )
--      local _, tag = pin:GetPinTypeAndTag()
--      if tag then
--          return tag:GetColor()
--      end
--  end,
}

-- callback function is invoked from "ZO_WorldMap_AddCustomPin" whenever any part of the World Map changes.
local function LayoutPins( pinManager )
	pinManager:RemovePins(pinType)										-- Clear all the pins in this area
	local mapZone = GetZoneId(GetCurrentMapZoneIndex())					-- Get the zoneId of the new area
	if gps:IsMeasuring() or mapZone < 1 or mapZone > 2147483647 then	-- (2**31)-1 is 2147483647; 2**32 = 2147483648 or -0 
		return end
		
	local x, y, pinTag
	for i = 1, #YourListOfPins do
		x, y = AFunctionToReadTheGlobalCoords( YourListOfPins[i] )
		x, y = gps:GlobalToLocal( x, y )
		
		if x > 0 and x < 1 and y > 0 and y < 1 then
		-- what you need to know. e.g. the index within the YourListOfPins table
			pinTag = { i }
			pinManager:CreatePin( pinTypeId, pinTag, x, y )
		end
	end
end

SLASH_COMMANDS["/testpins"] = function()
	if not pinTypeId then
		-- This create a global Variable named as pinType with the id
		ZO_WorldMap_AddCustomPin(pinType, LayoutPins, nil, layout, nil)
		-- Get this id
		pinTypeId = _G[pinType]
	end
	-- Enable the pins
	ZO_WorldMap_SetCustomPinEnabled( pinTypeId, true )
	-- Force redraw in the current map.
	ZO_WorldMap_RefreshCustomPinsOfType( pinTypeId )
end

--[[
	Garkin's callback function code from his CustomCompassPins addon to create "pinManager" pin lists
--]]

--sample data
local pinData = {
   ["auridon"] = {      --Auridon, Khenarthi's Roost
	  ["skywatch_base"] = {
		 { 0.5, 0.6 },
	  },      
   },
   ["main"] = {         --Main quest maps
	  ["hallsoftorment1_base"] = {
		 { 0.256, 0.361 },
	  },
   },
}
 
--callback function
local function CompassPinCallback( pinManager )
   if (GetMapType() > MAPTYPE_ZONE) then return end        --create pins only for: dungeon maps (0), subzone maps (1) and zone maps (2)
 
   local textureName = GetMapTileTexture() 
   textureName = string.lower(textureName)
   local _,_,_,zone,subzone = string.find(textureName, "(maps/)([%w%-]+)/([%w%-]+_%w+)")
   local pins
 
   if pinData[zone] then
	  if pinData[zone][subzone] ~= nil then					-- Note the use of multiple keys to map the table entries
		 pins = pinData[zone][subzone]						-- And retrieve the pin location data from a table of tables
	  else
		 return												--return if no data
	  end
   end 
 
   for _, pin in ipairs(pins) do
	  -- :CreatePin( pinType, pinTag, locX, locY )
	  pinManager:CreatePin( "My unique name for compass pin type", pin, pin[1], pin[2] )
   end
end
