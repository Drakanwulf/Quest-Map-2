--[[

Quest Map
by CaptainBlagbird
https://github.com/CaptainBlagbird

--]]

QuestMap.iconSets = {
    QuestMap = {"QuestMap/icons/pinQuestUncompleted.dds", "QuestMap/icons/pinQuestCompleted.dds"},
    ESO = {"/esoui/art/floatingmarkers/quest_available_icon.dds", "/esoui/art/icons/achievements_indexicon_quests_down.dds"},
}